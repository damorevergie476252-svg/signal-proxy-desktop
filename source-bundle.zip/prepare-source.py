"""Three-way merge a reviewed overlay. Any conflict prevents a successful build."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import re
import shutil
import subprocess


def child(root, name):
    relative = PurePosixPath(name)
    if relative.is_absolute() or '..' in relative.parts or '\\' in name or ':' in name:
        raise ValueError('Unsafe overlay path: ' + name)
    target = root.joinpath(*relative.parts).resolve()
    if not target.is_relative_to(root.resolve()):
        raise ValueError('Overlay path escapes source tree: ' + name)
    return target


def read_checked(path, expected):
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError('Overlay integrity check failed: ' + str(path))
    return data


def prepare(kit, upstream, output, expected_version, date, revision, epoch, channel=None):
    kit, upstream, output = kit.resolve(), upstream.resolve(), output.resolve()
    if output.exists() or output == upstream or output.is_relative_to(upstream):
        raise ValueError('Output must be a new directory outside the upstream tree')
    if not re.fullmatch(r'\d+\.\d+\.\d+', expected_version):
        raise ValueError('Only stable upstream versions are accepted')
    if not re.fullmatch(r'\d{8}', date) or revision < 1 or epoch <= 0:
        raise ValueError('Invalid build date, revision or official commit timestamp')
    package = json.loads((upstream / 'package.json').read_text(encoding='utf8'))
    if package['version'] != expected_version or package['name'] != 'signal-desktop':
        raise ValueError('Upstream source does not match the requested official version')
    manifest = json.loads((kit / 'overlay.json').read_text(encoding='utf8'))
    if manifest['appId'] != 'local.signal.desktop.proxy.sgpx' or manifest['storageProfile'] != 'Proxy-SGPX':
        raise ValueError('The overlay changed application identity or storage profile')
    if channel is not None:
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9-]{0,38}/[A-Za-z0-9][A-Za-z0-9._-]{0,99}', channel['repository']):
            raise ValueError('Invalid update repository')
        if not re.fullmatch(r'05[0-9a-f]{64}', channel['publicKey']):
            raise ValueError('Invalid update public key')
    shutil.copytree(upstream, output, ignore=shutil.ignore_patterns('.git', 'node_modules'))
    for row in manifest['files']:
        name = row['path']
        ours = child(kit / 'ours', name)
        data = read_checked(ours, row['oursSha256'])
        target = child(output, name)
        target.parent.mkdir(parents=True, exist_ok=True)
        if row['baseSha256'] is None:
            if target.exists() and target.read_bytes().replace(b'\r\n', b'\n') != data:
                raise ValueError('A custom file now exists upstream and needs review: ' + name)
            target.write_bytes(data)
        else:
            baseline = child(kit / 'base', name)
            read_checked(baseline, row['baseSha256'])
            if not target.is_file():
                raise ValueError('Upstream removed a customized file: ' + name)
            target.write_bytes(target.read_bytes().replace(b'\r\n', b'\n'))
            result = subprocess.run(['git', 'merge-file', '--diff3', '-p', str(target), str(baseline), str(ours)], capture_output=True)
            if result.returncode:
                raise ValueError('Merge conflict or error; do not publish: ' + name)
            target.write_bytes(result.stdout)
    package.update(name='signal-desktop-proxy', productName='Signal Proxy', version=f'{expected_version}-adhoc.{date}.r.{revision}.sgpx')
    package['build']['appId'] = manifest['appId']
    package['build']['win']['signtoolOptions'] = {'sign': 'scripts/sign-windows.mjs'}
    for extra in ['conversation.html', 'local-lock.html']:
        if extra not in package['build']['files']:
            package['build']['files'].append(extra)
    package['scripts'].update(manifest['scripts'])
    child(output, 'package.json').write_text(json.dumps(package, indent=2) + '\n', encoding='utf8')
    config = {'buildCreation': epoch * 1000, 'buildExpiration': epoch * 1000 + 30 * 86400000, 'storageProfile': manifest['storageProfile'], 'updatesEnabled': channel is not None}
    if channel is not None:
        config['proxyUpdates'] = channel
    child(output, 'config/local-production.json').write_text(json.dumps(config) + '\n', encoding='utf8')
    return {'officialVersion': expected_version, 'version': package['version'], 'customFiles': len(manifest['files']), 'updatesConfigured': channel is not None}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('upstream', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--official-version', required=True)
    parser.add_argument('--date', required=True)
    parser.add_argument('--revision', type=int, required=True)
    parser.add_argument('--official-epoch', type=int, required=True)
    parser.add_argument('--channel', type=Path)
    args = parser.parse_args()
    channel = json.loads(args.channel.read_text(encoding='utf8')) if args.channel else None
    print(json.dumps(prepare(Path(__file__).parent, args.upstream, args.output, args.official_version, args.date, args.revision, args.official_epoch, channel)))
