# 此源码副本的 Signal TLS 代理改动

默认代理分享链接：`https://signal.tube/#sgpx.toomore.net`。
内部连接地址：`org.signal.tls://sgpx.toomore.net:443`。

这是在官方 Signal Desktop v8.22.0 源码上作出的本地修改，不是 Signal 官方发行版本。原始提取文件、原始官方源码和 `SignalSetup.exe` 均保留。

## 已加入的行为

- `config/production.json` 新增 `signalTlsProxyUrl`，打包的生产版本默认读取该地址。
- 主进程和更新请求共用 `getProxyUrl()`；显式设置的 `HTTPS_PROXY` / `https_proxy` 优先，继续支持已有 HTTP/SOCKS 配置。
- `signal.tube` 分享链接、裸主机名和 `org.signal.tls://` 地址在一个函数中规范化；拒绝额外路径、查询参数、账号密码等无效配置。
- JavaScript 请求层加入 TLS 内嵌 TLS 连接；不会向这个专用代理发送普通 HTTP CONNECT。它复用已有 `https-proxy-agent` 的请求和连接池管理，无新增生产依赖。
- 原生 libsignal 使用已有的 `setProxyFromUrl()` 接口接收相同地址。
- 外层验证代理的公开证书，内层保留 Signal 目标服务的证书验证；没有关闭证书检查。配置无效时不再静默退回直连。
- 两层握手各有 15 秒超时；取消请求会关闭尚未完成的握手。

## 测试及构建

工程指定 Node.js `24.17.0`、pnpm `11.5.2`。完整安装及 Windows 编译环境要求见原项目 `CONTRIBUTING.md`。

在准备好原项目依赖后，针对性测试命令为：

```powershell
pnpm run test-signal-tls-proxy
```

开发模式默认不会加载生产配置。开发运行时可显式指定：

```powershell
$env:HTTPS_PROXY = 'org.signal.tls://sgpx.toomore.net:443'
pnpm start
```

要替换生产默认地址，编辑 `config/production.json` 的 `signalTlsProxyUrl` 后重新生成、编译；将其设为空字符串可取消该默认值。通常使用原工程的 `pnpm run generate`、`pnpm run build` 流程。

2026-10-25 已安装锁定的构建依赖，重新编译整个应用和贴纸工具，并生成 x64 便携版和安装包。构建版本为 `8.22.0-adhoc.20261025.1-sgpx`，名称为 `Signal Proxy`，使用独立的 `Signal-Proxy-SGPX` 数据目录；未接管原版 URL 协议处理器。沿用项目 adhoc 规则关闭自动更新，并设置 30 天构建有效期（至 2026-11-24）。所有新生成的 EXE 均为未签名的本地自定义版本。

其中 ringrtc 2.70.2 和 windows-ucv 1.0.1 复用原始安装包内同版本的原生模块；其余源码和资源已重新构建。构建工具、原生模块来源和输出校验记录位于同级 `build-tools/`、`build-logs/` 和 `dist-proxy/`。

## 本次验证结果

- 10 项本地测试通过：地址解析、实际生产配置、环境变量优先级、非法地址拒绝、TLS 内嵌 TLS、内外层证书验证、明文/端口拒绝及取消连接。
- 整个应用源码通过项目的 `tsgo --noEmit` 类型检查；代理测试也已在完整依赖环境下通过。
- 使用普通 HTTPS CONNECT 替代新传输的负对照会失败，证明连接测试能识别协议接错的情况。
- 通过 `sgpx.toomore.net:443` 对 `https://chat.signal.org/` 作无账号的实际请求，约 1.15 秒收到 HTTP 404，目标 TLS 证书验证成功。404 是根路径的 HTTP 响应，说明代理与目标的 TLS 通路已经建立，不代表登录、收发消息或通话经过验证。测试时间与原始结果另存于交付目录的 `proxy-validation/live-probe.json`。

便携版已实际运行，应用日志确认原生 libsignal 通过 TLS 代理建立 provisioning 和未登录聊天连接。窗口保留默认防截屏保护，因此自动截图没有用于确认二维码图像。尚未绑定账号，也未验证收发消息、附件和通话。该 TLS 代理只转发服务器允许的目标，不能当作通用网页代理或系统 VPN；外部链接预览和语音/视频媒体不保证可经此路径工作。远端可用性也可能变化。

`test/fixtures/signal-tls-proxy/` 下的证书和私钥仅用于本机测试，未加入系统信任，也不用于真实网络连接。

## 协议参考

- [Signal 官方代理说明](https://support.signal.org/hc/en-us/articles/360056052052-Proxy-Support)
- [官方 TLS 终止配置](https://github.com/signalapp/Signal-TLS-Proxy/blob/main/data/nginx-terminate/nginx.conf)
- [官方按内部 SNI 转发的配置](https://github.com/signalapp/Signal-TLS-Proxy/blob/main/data/nginx-relay/nginx.conf)

这里增加的是本地源码支持；官方支持页面仍说明桌面端不能直接导入手机代理链接。
