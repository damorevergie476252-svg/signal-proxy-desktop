// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import http from 'node:http';
import https from 'node:https';
import net from 'node:net';
import tls from 'node:tls';
import { once } from 'node:events';
import { test } from 'node:test';

import { SignalTlsProxyAgent } from '../ts/util/SignalTlsProxyAgent.node.ts';
import { getProxyUrl } from '../ts/util/getProxyUrl.node.ts';
import { normalizeSignalTlsProxyUrl } from '../ts/util/signalTlsProxyUrl.std.ts';

const fixture = new URL('../test/fixtures/signal-tls-proxy/', import.meta.url);
const [outerCa, innerCa, proxyCert, proxyKey, targetCert, targetKey] =
  await Promise.all(
    [
      'outer-ca.pem',
      'inner-ca.pem',
      'proxy-cert.pem',
      'proxy-key.pem',
      'target-cert.pem',
      'target-key.pem',
    ].map(name => readFile(new URL(name, fixture), 'utf8'))
  );
const production = JSON.parse(
  await readFile(new URL('../config/production.json', import.meta.url), 'utf8')
);
const config = {
  has: key => Object.hasOwn(production, key),
  get: key => production[key],
};

test('sharing URL and raw host select the requested Signal TLS endpoint', () => {
  for (const value of [
    'https://signal.tube/#sgpx.toomore.net',
    'sgpx.toomore.net',
    'org.signal.tls://sgpx.toomore.net:443',
  ]) {
    assert.equal(
      normalizeSignalTlsProxyUrl(value),
      'org.signal.tls://sgpx.toomore.net:443'
    );
  }
  assert.equal(
    getProxyUrl(config, {}),
    'org.signal.tls://sgpx.toomore.net:443'
  );
});

test('explicit HTTP/SOCKS environment overrides retain their priority', () => {
  assert.equal(
    getProxyUrl(config, { HTTPS_PROXY: 'socks5://localhost:7890' }),
    'socks5://localhost:7890'
  );
  assert.equal(
    getProxyUrl(config, { https_proxy: 'http://localhost:7890' }),
    'http://localhost:7890'
  );
  assert.equal(
    getProxyUrl({ has: () => false, get: () => undefined }, {}),
    undefined
  );
});

test('malformed proxy configuration fails instead of selecting a direct route', () => {
  for (const value of [
    '',
    'https://example.org/#sgpx.toomore.net',
    'https://signal.tube/',
    'https://signal.tube/#user:password@sgpx.toomore.net',
    'org.signal.tls://sgpx.toomore.net/path',
    'org.signal.tls://sgpx.toomore.net?query=1',
    'org.signal.tls://sgpx.toomore.net:0',
    'socks5://sgpx.toomore.net',
  ]) {
    assert.throws(() => normalizeSignalTlsProxyUrl(value));
  }
  assert.throws(() =>
    getProxyUrl({ has: () => true, get: () => 'bad host/path' }, {})
  );
});

async function listen(server) {
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  return server.address().port;
}

function responseThrough(url, agent, options = {}) {
  return new Promise((resolve, reject) => {
    const transport = url.startsWith('https:') ? https : http;
    const request = transport.get(url, { agent, ...options }, response => {
      const chunks = [];
      response.on('data', chunk => chunks.push(chunk));
      response.on('error', reject);
      response.on('end', () =>
        resolve({
          status: response.statusCode,
          body: Buffer.concat(chunks).toString(),
        })
      );
    });
    request.on('error', reject);
  });
}

test('TLS inside TLS reaches the origin and verifies both independent certificates', async t => {
  const originalRoots = tls.getCACertificates('default');
  tls.setDefaultCACertificates([...originalRoots, outerCa]);
  const sockets = new Set();
  const firstBytes = [];
  const proxyNames = [];
  const destinationNames = [];
  let originRequests = 0;
  const track = socket => {
    sockets.add(socket);
    socket.on('error', () => {});
    socket.once('close', () => sockets.delete(socket));
    return socket;
  };
  const origin = https.createServer(
    { cert: targetCert, key: targetKey },
    (request, response) => {
      originRequests += 1;
      response.end('via-signal-tls-proxy');
    }
  );
  origin.on('connection', track);
  origin.on('secureConnection', socket =>
    destinationNames.push(socket.servername)
  );
  origin.on('tlsClientError', () => {});
  const originPort = await listen(origin);
  const proxy = tls.createServer({ cert: proxyCert, key: proxyKey }, socket => {
    track(socket);
    proxyNames.push(socket.servername);
    socket.once('data', first => {
      socket.pause();
      firstBytes.push(first[0]);
      const upstream = track(
        net.connect({ host: '127.0.0.1', port: originPort })
      );
      upstream.once('connect', () => {
        upstream.write(first);
        socket.pipe(upstream);
        upstream.pipe(socket);
        socket.resume();
      });
      socket.once('close', () => upstream.destroy());
      upstream.once('close', () => socket.destroy());
    });
  });
  proxy.on('connection', track);
  proxy.on('tlsClientError', () => {});
  const proxyPort = await listen(proxy);
  const agent = new SignalTlsProxyAgent(
    `org.signal.tls://localhost:${proxyPort}`
  );
  t.after(async () => {
    agent.destroy();
    for (const socket of sockets) {
      socket.destroy();
    }
    await Promise.all([
      new Promise(resolve => origin.close(resolve)),
      new Promise(resolve => proxy.close(resolve)),
    ]);
    tls.setDefaultCACertificates(originalRoots);
  });

  await t.test(
    'uses an inner TLS ClientHello, never an HTTP CONNECT header',
    async () => {
      assert.deepEqual(
        await responseThrough('https://signal-destination.test/', agent, {
          ca: innerCa,
        }),
        {
          status: 200,
          body: 'via-signal-tls-proxy',
        }
      );
      assert.equal(firstBytes[0], 0x16);
      assert.equal(proxyNames[0], 'localhost');
      assert.equal(destinationNames[0], 'signal-destination.test');
    }
  );

  await t.test(
    'rejects an incorrect destination certificate name',
    async () => {
      await assert.rejects(
        responseThrough('https://wrong-destination.test/', agent, {
          ca: innerCa,
        }),
        {
          code: 'ERR_TLS_CERT_ALTNAME_INVALID',
        }
      );
    }
  );

  await t.test('rejects an untrusted destination certificate', async () => {
    await assert.rejects(
      responseThrough('https://signal-destination.test/', agent, {
        ca: outerCa,
      })
    );
  });

  await t.test(
    'target CA cannot authorize an incorrect proxy certificate name',
    async () => {
      const wrongProxy = new SignalTlsProxyAgent(
        `org.signal.tls://127.0.0.1:${proxyPort}`
      );
      try {
        await assert.rejects(
          responseThrough('https://signal-destination.test/', wrongProxy, {
            ca: innerCa,
          }),
          {
            code: 'ERR_TLS_CERT_ALTNAME_INVALID',
          }
        );
      } finally {
        wrongProxy.destroy();
      }
    }
  );

  await t.test(
    'rejects plaintext and unsupported destination ports without sending requests',
    async () => {
      await assert.rejects(
        responseThrough('http://signal-destination.test/', agent),
        /HTTPS destination on 443/
      );
      await assert.rejects(
        responseThrough('https://signal-destination.test:8443/', agent, {
          ca: innerCa,
        }),
        /HTTPS destination on 443/
      );
      assert.equal(originRequests, 1);
    }
  );
});

test(
  'cancelling a request closes an incomplete proxy handshake',
  { timeout: 5_000 },
  async t => {
    const sockets = new Set();
    const server = net.createServer(socket => {
      sockets.add(socket);
      socket.on('data', () => {});
      socket.on('error', () => {});
      socket.once('close', () => sockets.delete(socket));
    });
    const port = await listen(server);
    const agent = new SignalTlsProxyAgent(`org.signal.tls://localhost:${port}`);
    t.after(async () => {
      agent.destroy();
      for (const socket of sockets) {
        socket.destroy();
      }
      await new Promise(resolve => server.close(resolve));
    });
    const started = Date.now();
    await assert.rejects(
      new Promise((resolve, reject) => {
        const request = https.get('https://signal-destination.test/', {
          agent,
        });
        request.on('error', reject);
        setTimeout(() => request.destroy(new Error('cancelled by test')), 100);
      }),
      { name: 'AbortError' }
    );
    assert.ok(
      Date.now() - started < 2_000,
      'cancellation must not wait for the handshake timeout'
    );
    const deadline = Date.now() + 2_000;
    while (sockets.size && Date.now() < deadline) {
      await new Promise(resolve => setTimeout(resolve, 10));
    }
    assert.equal(sockets.size, 0);
  }
);
