import assert from 'node:assert/strict';
import {test,after} from 'node:test';
import {mkdtemp,readFile,rm,access} from 'node:fs/promises';
import {Readable} from 'node:stream';
import {join} from 'node:path';
import {writeAttachmentWithAttributes} from '../ts/util/writeAttachmentWithAttributes.node.ts';
const root=await mkdtemp(join(process.cwd(),'.stream-attachment-test-'));
after(()=>rm(root,{recursive:true,force:true}));
test('stream attachments preserve every chunk and byte before opening or saving',async()=>{
 const file=join(root,'example.xlsx'),pieces=[Buffer.alloc(65536,65),Buffer.alloc(8192,66)];
 await writeAttachmentWithAttributes(file,Readable.from(pieces));assert.deepEqual(await readFile(file),Buffer.concat(pieces));
});
test('a failing attachment stream removes the incomplete file and reports the error',async()=>{
 const file=join(root,'failed.xlsx');
 const input=Readable.from((async function*(){yield Buffer.alloc(8192,65);throw new Error('synthetic stream failure');})());
 await assert.rejects(writeAttachmentWithAttributes(file,input),/synthetic stream failure/);await assert.rejects(access(file));
});
