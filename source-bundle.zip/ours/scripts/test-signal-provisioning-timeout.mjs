// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createRequire } from 'node:module';

// tsx loads this CommonJS application's imports through require as in Electron.
const { LibSignalErrorBase } = createRequire(import.meta.url)(
  '@signalapp/libsignal-client'
);

globalThis.window = {
  SignalContext: { timers: { setTimeout, clearTimeout } },
};
const { SocketManager } =
  await import('../ts/textsecure/SocketManager.preload.ts');
const { ConnectTimeoutError } = await import('../ts/textsecure/Errors.std.ts');
const listener = {
  onReceivedAddress() {},
  onReceivedEnvelope() {},
  onConnectionInterrupted() {},
};

test('native cancellation caused by our deadline is a retryable connect timeout', async () => {
  let aborted = false;
  const manager = new SocketManager({
    connectProvisioning: (_listener, { abortSignal }) =>
      new Promise((_resolve, reject) => {
        abortSignal.addEventListener(
          'abort',
          () => {
            aborted = true;
            reject(
              new LibSignalErrorBase(
                'Promise cancelled',
                'Cancelled',
                'connect'
              )
            );
          },
          { once: true }
        );
      }),
  });
  await assert.rejects(
    manager.getProvisioningConnection(listener, 20),
    ConnectTimeoutError
  );
  assert.equal(aborted, true);
});

test('successful provisioning returns the connection and clears the deadline', async () => {
  const connection = {};
  let signal;
  const manager = new SocketManager({
    connectProvisioning: async (_listener, options) => {
      signal = options.abortSignal;
      return connection;
    },
  });
  assert.equal(
    await manager.getProvisioningConnection(listener, 20),
    connection
  );
  await new Promise(resolve => setTimeout(resolve, 40));
  assert.equal(signal.aborted, false);
});

for (const name of ['IoError', 'Cancelled']) {
  test(`${name} before the deadline retains its original error`, async () => {
    const error = new LibSignalErrorBase('original error', name, 'connect');
    const manager = new SocketManager({
      connectProvisioning: async () => {
        throw error;
      },
    });
    await assert.rejects(
      manager.getProvisioningConnection(listener, 100),
      actual => actual === error
    );
  });
}
