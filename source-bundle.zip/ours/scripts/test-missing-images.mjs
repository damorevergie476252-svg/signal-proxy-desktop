import test from 'node:test';
import assert from 'node:assert/strict';
import { repairMissingVisualAttachments } from '../ts/util/repairMissingVisualAttachments.std.ts';

const image = {
  contentType: 'image/png',
  size: 50,
  path: 'old/image',
  localKey: 'local-secret',
  key: 'remote-secret',
  digest: 'digest',
  plaintextHash: 'hash',
  cdnKey: 'cdn',
  cdnNumber: 3,
  localBackupPath: 'local-backup',
  thumbnail: { contentType: 'image/png', size: 10, path: 'old/thumb' },
};
test('missing image and thumbnail become downloadable while all recovery metadata is retained', async () => {
  const original = structuredClone(image);
  const result = await repairMissingVisualAttachments(
    { attachments: [image] },
    async () => false
  );
  assert.equal(result.attachments[0].path, undefined);
  assert.equal(result.attachments[0].thumbnail, undefined);
  for (const name of [
    'localKey',
    'key',
    'digest',
    'plaintextHash',
    'cdnKey',
    'cdnNumber',
    'localBackupPath',
  ])
    assert.equal(result.attachments[0][name], image[name]);
  assert.deepEqual(image, original);
});
test('existing images are left unchanged', async () => {
  assert.equal(
    await repairMissingVisualAttachments(
      { attachments: [image] },
      async () => true
    ),
    undefined
  );
});
test('missing thumbnail falls back to an intact full-size image without a new download', async () => {
  const result = await repairMissingVisualAttachments(
    { attachments: [image] },
    async path => path === 'old/image'
  );
  assert.equal(result.attachments[0].path, 'old/image');
  assert.equal(result.attachments[0].thumbnail, undefined);
});
test('edit history copies and previews cannot put stale image paths back into the queue', async () => {
  const result = await repairMissingVisualAttachments(
    {
      attachments: [image],
      editHistory: [
        {
          attachments: [image],
          timestamp: 123,
          received_at: 456,
          body: 'preserved',
        },
      ],
      preview: [{ url: 'https://example.org', image }],
    },
    async () => false
  );
  assert.equal(result.editHistory[0].attachments[0].path, undefined);
  assert.equal(result.preview[0].image.path, undefined);
  assert.equal(result.editHistory[0].timestamp, 123);
  assert.equal(result.editHistory[0].body, 'preserved');
});
test('documents and undownloaded images are unchanged', async () => {
  const { path, thumbnail, ...notDownloaded } = image;
  assert.equal(
    await repairMissingVisualAttachments(
      {
        attachments: [
          { ...image, contentType: 'application/pdf' },
          notDownloaded,
        ],
      },
      async () => false
    ),
    undefined
  );
});
test('file access failures preserve records instead of clearing a path without proof', async () => {
  await assert.rejects(
    repairMissingVisualAttachments({ attachments: [image] }, async () => {
      throw new Error('access denied');
    }),
    /access denied/
  );
  assert.equal(image.path, 'old/image');
});
