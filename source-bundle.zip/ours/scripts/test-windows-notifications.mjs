import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { LocalWindowsNotifications } from '../app/localWindowsNotifications.main.ts';
import { renderWindowsToast } from '../app/renderWindowsToast.std.tsx';
import { dispatchWindowsNotification } from '../ts/util/dispatchWindowsNotification.std.ts';
import { NotificationType } from '../ts/types/notifications.std.ts';

const target = {
  conversationId: 'chat-b',
  messageId: 'message-b',
  storyId: undefined,
};
const data = {
  heading: 'Local fixture',
  body: 'Synthetic notification',
  token: 'opaque-token',
  type: NotificationType.Message,
  target,
};
class FakeNotification extends EventEmitter {
  constructor(options) {
    super();
    this.options = options;
    this.shown = false;
    this.closed = false;
  }
  show() {
    this.shown = true;
  }
  close() {
    this.closed = true;
  }
}
function fixture() {
  const created = [],
    activated = [],
    failed = [];
  const manager = new LocalWindowsNotifications({
    create: options => {
      const n = new FakeNotification(options);
      created.push(n);
      return n;
    },
    activate: value => activated.push(value),
    failed: value => failed.push(value),
  });
  return { manager, created, activated, failed };
}
test('proxy toast activation stays inside the running application', () => {
  const f = fixture();
  f.manager.show(data);
  const n = f.created[0];
  assert.equal(n.shown, true);
  assert.match(n.options.toastXml, /activationType="foreground"/);
  assert.doesNotMatch(
    n.options.toastXml,
    /sgnl:\/\/|activationType="protocol"/
  );
  n.emit('click');
  assert.deepEqual(f.activated, [data]);
  assert.equal(n.closed, true);
});
test('a notification captures its original chat and message even if source data changes', () => {
  const f = fixture(),
    value = structuredClone(data);
  f.manager.show(value);
  value.target.conversationId = 'chat-a';
  value.target.messageId = 'message-a';
  f.created[0].emit('click');
  assert.deepEqual(f.activated[0].target, target);
});
test('replaced and cleared notifications cannot navigate to an old chat', () => {
  const f = fixture();
  f.manager.show(data);
  f.manager.show({ ...data, target: { ...target, conversationId: 'chat-c' } });
  f.created[0].emit('click');
  assert.equal(f.activated.length, 0);
  assert.equal(f.created[0].closed, true);
  f.manager.clear();
  f.created[1].emit('click');
  assert.equal(f.activated.length, 0);
});
test('clicking one notification twice navigates once and failed display is reported', () => {
  const f = fixture();
  f.manager.show(data);
  f.created[0].emit('failed', {}, 'display failed');
  assert.deepEqual(f.failed, ['display failed']);
  f.created[0].emit('click');
  f.created[0].emit('click');
  assert.equal(f.activated.length, 1);
});
test('Action Center activation and a duplicate popup callback navigate exactly once', () => {
  const f = fixture();
  f.manager.show(data);
  f.manager.activate(data.token);
  f.created[0].emit('click');
  f.manager.activate(data.token);
  assert.deepEqual(f.activated, [data]);
  assert.equal(f.created[0].closed, true);
});
test('unrelated and obsolete Action Center tokens cannot open a conversation', () => {
  const f = fixture();
  f.manager.show(data);
  f.manager.activate('unknown-token');
  assert.equal(f.activated.length, 0);
  f.manager.show({ ...data, token: 'new-token' });
  f.manager.activate(data.token);
  assert.equal(f.activated.length, 0);
  f.manager.clear();
  f.manager.activate('new-token');
  assert.equal(f.activated.length, 0);
});
test('message and reaction clicks preserve conversation, message and story destinations', () => {
  for (const type of [NotificationType.Message, NotificationType.Reaction, NotificationType.UnreadReminder]) {
    const calls = [];
    const story = { ...target, storyId: 'story-b' };
    dispatchWindowsNotification(
      { ...data, type, target: story },
      {
        showConversation: value => calls.push(value),
        openInbox: () => assert.fail('must not lose destination'),
        startCallLobby: () => assert.fail(),
        cancelPresenting: () => assert.fail(),
      }
    );
    assert.deepEqual(calls, [story]);
  }
});
test('group calls, incoming calls and presenting retain their separate actions', () => {
  const calls = [];
  const actions = {
    showConversation: () => assert.fail(),
    openInbox: () => assert.fail(),
    startCallLobby: id => calls.push(id),
    cancelPresenting: () => calls.push('cancel'),
  };
  dispatchWindowsNotification(
    { ...data, type: NotificationType.IncomingGroupCall },
    actions
  );
  dispatchWindowsNotification(
    { ...data, type: NotificationType.IncomingCall },
    actions
  );
  dispatchWindowsNotification(
    { ...data, type: NotificationType.IsPresenting },
    actions
  );
  assert.deepEqual(calls, ['chat-b', 'cancel']);
});
test('default toast output retains the original protocol contract and escapes XML text', () => {
  const xml = renderWindowsToast({
    ...data,
    heading: '<Alice & Bob>',
    body: '"test" & <text>',
  });
  assert.match(xml, /sgnl:\/\/show-conversation\?token=opaque-token/);
  assert.match(xml, /activationType="protocol"/);
  assert.match(xml, /&lt;Alice &amp; Bob&gt;/);
  assert.doesNotMatch(xml, /<Alice/);
});
