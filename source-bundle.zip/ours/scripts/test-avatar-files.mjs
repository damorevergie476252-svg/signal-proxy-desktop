import assert from 'node:assert/strict';
import { test } from 'node:test';
import { repairMissingAvatarFiles } from '../ts/util/repairMissingAvatarFiles.std.ts';

test('existing avatars are checked without a profile refresh', async () => {
  let refreshed = 0;
  const result = await repairMissingAvatarFiles(
    [
      {
        getPaths: () => ['existing'],
        repair: async () => {
          refreshed++;
        },
      },
    ],
    async () => true
  );
  assert.equal(refreshed, 0);
  assert.equal(result.missing, 0);
});
test('a missing reference is refreshed and the new path is verified', async () => {
  let path = 'missing';
  const result = await repairMissingAvatarFiles(
    [
      {
        getPaths: () => [path],
        repair: async () => {
          path = 'restored';
        },
      },
    ],
    async name => name === 'restored'
  );
  assert.deepEqual(result, {
    checked: 1,
    missing: 1,
    repaired: 1,
    unresolved: 0,
  });
});
test('offline and unsuccessful refreshes remain unresolved without aborting other contacts', async () => {
  let second = 'missing';
  const result = await repairMissingAvatarFiles(
    [
      {
        getPaths: () => ['missing'],
        repair: async () => {
          throw new Error('offline');
        },
      },
      { getPaths: () => ['missing'], repair: async () => {} },
      {
        getPaths: () => [second],
        repair: async () => {
          second = 'restored';
        },
      },
    ],
    async path => path === 'restored'
  );
  assert.deepEqual(result, {
    checked: 3,
    missing: 3,
    repaired: 1,
    unresolved: 2,
  });
});
test('contacts without an avatar do not trigger a refresh', async () => {
  let refreshed = false;
  await repairMissingAvatarFiles(
    [
      {
        getPaths: () => [],
        repair: async () => {
          refreshed = true;
        },
      },
    ],
    async () => false
  );
  assert.equal(refreshed, false);
});
