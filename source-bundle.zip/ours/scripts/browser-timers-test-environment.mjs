// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

// Electron preloads run with browser timer globals: setTimeout/setInterval
// return numeric handles, not the Timeout objects used by plain Node tests.
import * as timers from 'node:timers';

let nextHandle = 1;
const handles = new Map();
function clearHandle(id) {
  const handle = handles.get(id);
  timers.clearTimeout(handle);
  timers.clearInterval(handle);
  handles.delete(id);
}
globalThis.setTimeout = (callback, delay, ...args) => {
  const id = nextHandle++;
  const handle = timers.setTimeout(() => {
    handles.delete(id);
    callback(...args);
  }, delay);
  handles.set(id, handle);
  return id;
};
globalThis.clearTimeout = clearHandle;
globalThis.setInterval = (callback, delay, ...args) => {
  const id = nextHandle++;
  handles.set(id, timers.setInterval(callback, delay, ...args));
  return id;
};
globalThis.clearInterval = clearHandle;
