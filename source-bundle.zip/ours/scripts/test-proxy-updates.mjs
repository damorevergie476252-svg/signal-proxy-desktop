// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import assert from 'node:assert/strict';
import { test } from 'node:test';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { runInThisContext } from 'node:vm';
import ts from 'typescript';
import { PrivateKey } from '@signalapp/libsignal-client';
import {
  assertProxyInstaller,
  getProxyUpdateChannel,
  isNewerProxyVersion,
} from '../ts/updater/proxyChannel.std.ts';
import {
  writeSignature,
  verifySignature,
} from '../ts/updater/signature.node.ts';

const current = '8.36.0-adhoc.20261126.1-sgpx';
const newer = '8.37.0-adhoc.20261127.1-sgpx';
const publicKey = Buffer.from(
  PrivateKey.generate().getPublicKey().serialize()
).toString('hex');
const channel = { repository: 'example/signal-proxy', publicKey };
const proxyName = 'signal-desktop-proxy';
const fileName = 'Signal-Proxy-8.37.0-x64-Setup-20261127.1.exe';
const makeConfig = data => ({
  has: key => Object.hasOwn(data, key),
  get: key => data[key],
});

function loadActualModule(relative, mocks) {
  const url = new URL(relative, import.meta.url);
  const require = createRequire(url);
  const source = readFileSync(url, 'utf8');
  const { outputText } = ts.transpileModule(source, {
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.CommonJS,
      esModuleInterop: true,
    },
  });
  const module = { exports: {} };
  const evaluate = runInThisContext(
    `(function(require,module,exports){${outputText}\n})`,
    { filename: url.pathname }
  );
  evaluate(
    name => (Object.hasOwn(mocks, name) ? mocks[name] : require(name)),
    module,
    module.exports
  );
  return module.exports;
}

test('only configured proxy distributions use a fixed HTTPS release channel', () => {
  assert.equal(
    getProxyUpdateChannel(
      makeConfig({ proxyUpdates: channel }),
      'signal-desktop'
    ),
    undefined
  );
  assert.equal(getProxyUpdateChannel(makeConfig({}), proxyName), undefined);
  assert.deepEqual(
    getProxyUpdateChannel(makeConfig({ proxyUpdates: channel }), proxyName),
    {
      baseUrl:
        'https://github.com/example/signal-proxy/releases/latest/download',
      publicKey,
    }
  );
  for (const bad of [
    null,
    {},
    { ...channel, repository: '../bad' },
    { ...channel, repository: 'https://attacker/repo' },
    { ...channel, publicKey: '05' },
    { ...channel, publicKey: `04${'00'.repeat(32)}` },
  ]) {
    assert.throws(() =>
      getProxyUpdateChannel(makeConfig({ proxyUpdates: bad }), proxyName)
    );
  }
});

test('official, equal, older and malformed versions cannot replace the custom build', () => {
  for (const candidate of [
    '8.37.0',
    '8.37.0-beta.1',
    current,
    '8.35.0-adhoc.20261127.1-sgpx',
    'invalid',
    '8.37.0-adhoc.20261127.1-other',
  ]) {
    assert.equal(isNewerProxyVersion(candidate, current), false, candidate);
  }
  assert.equal(isNewerProxyVersion(newer, current), true);
  assert.equal(
    isNewerProxyVersion('8.36.0-adhoc.20261126.2-sgpx', current),
    true
  );
  assert.equal(
    isNewerProxyVersion('8.36.0-adhoc.20261126.r.1.sgpx', current),
    true
  );
  assert.equal(
    isNewerProxyVersion(
      '8.36.0-adhoc.20261126.r.10.sgpx',
      '8.36.0-adhoc.20261126.r.9.sgpx'
    ),
    true
  );
});

test('portable, foreign, unsafe and wrong-architecture installers are refused', () => {
  assertProxyInstaller(fileName, 'x64');
  for (const name of [
    'Signal-Proxy-8.37.0-x64-Portable-Fix17.exe',
    'signal-desktop-win-x64-8.37.0.exe',
    '../' + fileName,
    fileName + '.cmd',
  ]) {
    assert.throws(() => assertProxyInstaller(name, 'x64'));
  }
  assert.throws(() => assertProxyInstaller(fileName, 'arm64'));
});

test('the existing signature scheme detects changed contents, version and key', async () => {
  const folder = await mkdtemp(join(tmpdir(), 'signal-update-signature-'));
  try {
    const key = PrivateKey.generate();
    const file = join(folder, fileName);
    const privateFile = join(folder, 'test-only-key');
    await writeFile(file, 'synthetic update package');
    await writeFile(privateFile, Buffer.from(key.serialize()).toString('hex'));
    const signature = await writeSignature(file, newer, privateFile);
    assert.equal(
      await verifySignature(
        file,
        newer,
        signature,
        key.getPublicKey().serialize()
      ),
      true
    );
    assert.equal(
      await verifySignature(
        file,
        current,
        signature,
        key.getPublicKey().serialize()
      ),
      false
    );
    assert.equal(
      await verifySignature(
        file,
        newer,
        signature,
        PrivateKey.generate().getPublicKey().serialize()
      ),
      false
    );
    await writeFile(file, 'tampered update package');
    assert.equal(
      await verifySignature(
        file,
        newer,
        signature,
        key.getPublicKey().serialize()
      ),
      false
    );
    assert.ok((await readFile(file + '.sig', 'utf8')).length > 0);
  } finally {
    await rm(folder, { recursive: true, force: true });
  }
});

test('GitHub update requests keep TLS validation and do not use the Signal TLS relay or CA', async () => {
  const optionsModule = loadActualModule('../ts/updater/got.main.ts', {
    config: makeConfig({
      proxyUpdates: channel,
      certificateAuthority: 'signal-private-ca',
      signalTlsProxyUrl: 'org.signal.tls://proxy.invalid',
    }),
    '../util/packageJson.main.ts': {
      packageJson: { name: proxyName, version: current },
    },
    '../util/createHTTPSAgent.node.ts': {
      createHTTPSAgent: () => 'public-https-agent',
    },
    '../util/createProxyAgent.node.ts': {
      createProxyAgent: async url => ({ url }),
    },
    '../util/getProxyUrl.node.ts': {
      getProxyUrl: () => 'org.signal.tls://signal-relay.invalid',
    },
  });
  const saved = {
    HTTPS_PROXY: process.env.HTTPS_PROXY,
    https_proxy: process.env.https_proxy,
  };
  try {
    delete process.env.HTTPS_PROXY;
    delete process.env.https_proxy;
    const direct = await optionsModule.getGotOptions({ forUpdate: true });
    assert.equal(direct.https.certificateAuthority, undefined);
    assert.notEqual(direct.https.rejectUnauthorized, false);
    assert.equal(direct.agent.https, 'public-https-agent');
    const resources = await optionsModule.getGotOptions();
    assert.equal(resources.https.certificateAuthority, 'signal-private-ca');
    assert.deepEqual(resources.agent.https, {
      url: 'org.signal.tls://signal-relay.invalid',
    });
    process.env.HTTPS_PROXY = 'http://127.0.0.1:3128';
    assert.deepEqual(
      (await optionsModule.getGotOptions({ forUpdate: true })).agent.https,
      {
        url: process.env.HTTPS_PROXY,
      }
    );
  } finally {
    for (const [key, value] of Object.entries(saved)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }
});

async function updaterFixture(overrides = {}) {
  const folder = await mkdtemp(join(tmpdir(), 'signal-updater-flow-'));
  const handlers = new Map();
  const urls = [],
    dialogs = [],
    installs = [];
  const metadata = {
    version: newer,
    path: fileName,
    files: [{ url: fileName, sha512: 'synthetic-sha512', size: 100 }],
    releaseDate: new Date().toISOString(),
    ...overrides.metadata,
  };
  const got = url => {
    urls.push(url);
    return {
      text: async () => {
        if (overrides.networkError) throw new Error('fixture offline');
        return JSON.stringify(metadata);
      },
    };
  };
  const { Updater, NoUpdateAvailableError } = loadActualModule(
    '../ts/updater/common.main.ts',
    {
      config: makeConfig(overrides.config ?? { proxyUpdates: channel }),
      got,
      electron: {
        app: { getVersion: () => current, getPath: () => folder },
        ipcMain: {
          handle: (key, value) => handlers.set(key, value),
          handleOnce: (key, value) => handlers.set(key, value),
          removeHandler: key => handlers.delete(key),
        },
      },
      '../util/packageJson.main.ts': {
        packageJson: { name: proxyName, version: current },
      },
      '../../app/attachments.node.ts': {
        getTempPath: () => join(folder, 'temp'),
        getUpdateCachePath: () => join(folder, 'cache'),
      },
      '../../app/window_state.std.ts': {
        markShouldQuit() {},
        markShouldNotQuit() {},
      },
      './got.main.ts': { getGotOptions: async () => ({}) },
      './differential.main.ts': {
        getBlockMapFileName: file => file + '.blockmap',
      },
    }
  );
  class TestUpdater extends Updater {
    deletePreviousInstallers() {
      return Promise.resolve();
    }
    handleUpdateFromThirdParty() {
      return false;
    }
    installUpdate(...args) {
      installs.push(args);
      throw new Error('A synthetic package must never be installed');
    }
  }
  const updater = new TestUpdater({
    canRunSilently: async () => false,
    getMainWindow: () => ({
      webContents: { send: (...args) => dialogs.push(args) },
    }),
    logger: { info() {}, warn() {}, error() {} },
    sql: { sqlRead: async () => ({ value: false }) },
  });
  return {
    updater,
    NoUpdateAvailableError,
    urls,
    dialogs,
    installs,
    cleanup: () => rm(folder, { recursive: true, force: true }),
  };
}

test('the actual updater offers a newer custom build from proxy.yml', async () => {
  const fixture = await updaterFixture();
  try {
    await fixture.updater.forceCheck();
    assert.deepEqual(fixture.urls, [
      'https://github.com/example/signal-proxy/releases/latest/download/proxy.yml',
    ]);
    assert.equal(fixture.dialogs.at(-1)[2].version, newer);
    assert.equal(fixture.installs.length, 0);
  } finally {
    await fixture.cleanup();
  }
});

for (const version of [current, '8.35.0-adhoc.20261127.1-sgpx', '8.99.0']) {
  test(`the actual force-download path refuses ${version}`, async () => {
    const fixture = await updaterFixture({ metadata: { version } });
    try {
      await fixture.updater.force();
      assert.equal(fixture.dialogs.length, 0);
      assert.equal(fixture.installs.length, 0);
      await assert.rejects(
        fixture.updater.forceCheck(),
        fixture.NoUpdateAvailableError
      );
    } finally {
      await fixture.cleanup();
    }
  });
}

test('an unconfigured custom build never falls back to the official update server', async () => {
  const fixture = await updaterFixture({ config: {} });
  try {
    await assert.rejects(fixture.updater.forceCheck(), /not configured/);
    assert.equal(fixture.urls.length, 0);
    assert.equal(fixture.installs.length, 0);
  } finally {
    await fixture.cleanup();
  }
});

test('offline checks report an error without offering or installing an update', async () => {
  const fixture = await updaterFixture({ networkError: true });
  try {
    await assert.rejects(fixture.updater.forceCheck(), /fixture offline/);
    assert.equal(fixture.dialogs.length, 0);
    assert.equal(fixture.installs.length, 0);
  } finally {
    await fixture.cleanup();
  }
});
