// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import { dirname, join, toNamespacedPath } from 'node:path';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { runInThisContext } from 'node:vm';
import ts from 'typescript';
import { fileURLToPath } from 'node:url';
import {
  openDocumentAttachment,
  normalizePathForShell,
} from '../ts/util/openDocumentAttachment.node.ts';
import { isOpenableDocumentFileName } from '../ts/util/isOpenableDocumentFileName.std.ts';

globalThis.window = { SignalContext: { timers: { setTimeout, clearTimeout } } };
// Keep the production method private. Bind its actual JSX click callback only
// in this test's in-memory module, preserving the real private-field brand and
// the complete componentDidUpdate implementation used by download completion.
const messageUrl = new URL(
  '../ts/components/conversation/Message.dom.tsx',
  import.meta.url
);
const messagePath = fileURLToPath(messageUrl);
const messageSource = readFileSync(messagePath, 'utf8');
const parsedMessage = ts.createSourceFile(
  messagePath,
  messageSource,
  ts.ScriptTarget.Latest,
  true,
  ts.ScriptKind.TSX
);
assert.equal(
  parsedMessage.parseDiagnostics.length,
  0,
  'Message source must parse'
);
const messageClass = parsedMessage.statements.find(
  node => ts.isClassDeclaration(node) && node.name?.text === 'Message'
);
assert.ok(messageClass, 'Current Message class must be present');
assert.ok(
  messageClass.members.some(
    member =>
      member.name &&
      ts.isPrivateIdentifier(member.name) &&
      member.name.text === '#openGenericAttachment'
  ),
  'Production open method must remain private'
);
const handlers = [];
function callsPrivateDocumentMethod(node) {
  let found = false;
  function visit(child) {
    if (
      ts.isCallExpression(child) &&
      ts.isPropertyAccessExpression(child.expression) &&
      child.expression.expression.kind === ts.SyntaxKind.ThisKeyword &&
      ts.isPrivateIdentifier(child.expression.name) &&
      child.expression.name.text === '#openGenericAttachment'
    )
      found = true;
    ts.forEachChild(child, visit);
  }
  visit(node);
  return found;
}
function findDocumentClick(node) {
  if (
    ts.isJsxAttribute(node) &&
    node.name.getText(parsedMessage) === 'onClick' &&
    node.initializer &&
    ts.isJsxExpression(node.initializer)
  ) {
    const handler = node.initializer.expression;
    if (
      handler &&
      ts.isArrowFunction(handler) &&
      callsPrivateDocumentMethod(handler)
    )
      handlers.push(handler);
  }
  ts.forEachChild(node, findDocumentClick);
}
findDocumentClick(messageClass);
assert.equal(
  handlers.length,
  1,
  'Expected the actual document attachment JSX click binding'
);
const injection = `\n  __documentClickForTest = ${handlers[0].getText(parsedMessage)};\n`;
const instrumentedSource =
  messageSource.slice(0, messageClass.end - 1) +
  injection +
  messageSource.slice(messageClass.end - 1);
let compiledMessageSource = instrumentedSource;
if (process.env.SIGNAL_DOCUMENT_OPEN_NEGATIVE === '1') {
  // Test-only violation: opening a downloaded document loses direct-open intent.
  compiledMessageSource = instrumentedSource.replace(
    'saveAttachment(firstAttachment, timestamp, 0, true);',
    'saveAttachment(firstAttachment, timestamp);'
  );
  assert.notEqual(
    compiledMessageSource,
    instrumentedSource,
    'Negative control must change the actual click method'
  );
}
const transformedMessage = ts.transpileModule(compiledMessageSource, {
  fileName: messagePath,
  reportDiagnostics: true,
  compilerOptions: {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.CommonJS,
    jsx: ts.JsxEmit.ReactJSX,
    useDefineForClassFields: true,
  },
});
assert.equal(
  transformedMessage.diagnostics?.filter(
    item => item.category === ts.DiagnosticCategory.Error
  ).length ?? 0,
  0,
  'Current Message module must transpile'
);
const testMessageModule = { exports: {} };
const evaluateMessage = runInThisContext(
  `(function(require, module, exports, __filename, __dirname) {${transformedMessage.outputText}\n})`,
  { filename: messagePath }
);
evaluateMessage(
  createRequire(messageUrl),
  testMessageModule,
  testMessageModule.exports,
  messagePath,
  dirname(messagePath)
);
const { Message } = testMessageModule.exports;
assert.equal(
  typeof Message,
  'function',
  'Must compile the current Message class'
);
const { createElement } = await import('react');
const { renderToStaticMarkup } = await import('react-dom/server');
const { MediaGallery } =
  await import('../ts/components/conversation/media-gallery/MediaGallery.dom.tsx');

const project = dirname(dirname(fileURLToPath(import.meta.url)));
const root = await mkdtemp(join(project, '.xlsx-open-test-'));
after(() => rm(root, { recursive: true, force: true }));
const data = new Uint8Array(Buffer.from('LOCAL XLSX OPEN TEST'));

test('only supported document filenames can use automatic opening', () => {
  for (const name of [
    'report.xlsx',
    '账目.XLSX',
    '业绩明细.xls',
    'REPORT.XLS',
    '说明.txt',
    '报告.PDF',
    '文档.docx',
  ])
    assert.equal(isOpenableDocumentFileName(name), true);
  for (const name of [
    null,
    '',
    '../report.xlsx',
    'C:\\report.xlsx',
    'a.xlsx.exe',
    'a.xlsm',
    'a.docm',
    'a.zip',
    'a.ps1',
    'a.bat',
    'a.xlsx:payload.xlsx',
    'a.xlsx\u0000',
    'a.xlsx ',
  ]) {
    assert.equal(isOpenableDocumentFileName(name), false, String(name));
  }
});

for (const extension of ['xlsx', 'xls', 'txt', 'zip']) {
  test(`rendered document gallery click uses the correct action for ${extension}`, () => {
    const calls = [];
    const document = {
      type: 'document',
      index: 0,
      attachment: {
        fileName: `report.${extension}`,
        path: 'encrypted-local-file',
      },
      message: { id: 'gallery-test', sentAt: 123, receivedAt: 123 },
    };
    let onItemClick;
    renderToStaticMarkup(
      createElement(MediaGallery, {
        conversationId: 'local-conversation',
        haveOldestMedia: true,
        haveOldestAudio: true,
        haveOldestLink: true,
        haveOldestDocument: true,
        i18n: key => key,
        initialLoad() {},
        loading: false,
        loadMore() {},
        media: [],
        audio: [],
        links: [],
        documents: [document],
        tab: 'documents',
        sortOrder: 'size',
        saveAttachment: (...args) => calls.push(args),
        pushPanelForConversation() {},
        kickOffAttachmentDownload() {},
        cancelAttachmentDownload() {},
        playAudio() {},
        showLightbox() {},
        renderMediaItem: props => {
          onItemClick = props.onItemClick;
          return createElement('span', null, 'document');
        },
      })
    );
    assert.equal(typeof onItemClick, 'function');
    onItemClick({ state: 'ReadyToShow', mediaItem: document });
    assert.equal(calls.length, 1);
    if (extension === 'zip') assert.equal(calls[0].length, 2);
    else assert.equal(calls[0][3], true);
  });
}

test('writes a temporary copy before opening it, preserving contents and extension', async () => {
  let calls = 0;
  await openDocumentAttachment({
    name: '账目.XLSX',
    data,
    tempPath: join(root, 'open'),
    openPath: async filePath => {
      calls += 1;
      assert.equal(filePath.endsWith('账目.XLSX'), true);
      assert.deepEqual(new Uint8Array(await readFile(filePath)), data);
      if (process.platform === 'win32') {
        assert.match(
          await readFile(`${filePath}:Zone.Identifier`, 'utf8'),
          /ZoneId=3/
        );
      }
      return '';
    },
  });
  assert.equal(calls, 1);
});

test('same-name attachments never overwrite each other', async () => {
  const paths = [];
  for (const value of ['first', 'second']) {
    await openDocumentAttachment({
      name: 'report.xlsx',
      data: new Uint8Array(Buffer.from(value)),
      tempPath: join(root, 'same-name'),
      openPath: async filePath => {
        paths.push(filePath);
        return '';
      },
    });
  }
  assert.notEqual(paths[0], paths[1]);
  assert.equal(await readFile(paths[0], 'utf8'), 'first');
  assert.equal(await readFile(paths[1], 'utf8'), 'second');
});

test('unsupported filenames fail before any application launch', async () => {
  for (const name of [
    '../../outside.xlsx',
    'payload.exe',
    'a.xlsm',
    'a.xlsx:bad.xlsx',
  ]) {
    await assert.rejects(
      openDocumentAttachment({
        name,
        data,
        tempPath: join(root, 'reject'),
        openPath: async () => assert.fail('must not launch'),
      }),
      /Invalid document/
    );
  }
});

test('OS opening errors are reported and the failed temporary copy is removed', async () => {
  const tempPath = join(root, 'failed-open');
  await assert.rejects(
    openDocumentAttachment({
      name: 'report.xlsx',
      data,
      tempPath,
      openPath: async () => 'No application registered',
    }),
    /No application registered/
  );
  assert.deepEqual(await readdir(tempPath), []);
});

function messageFor(attachment) {
  const calls = { save: [], download: [], cancel: [] };
  const message = new Message({
    id: 'local-test-message',
    timestamp: 123,
    attachments: [attachment],
    saveAttachment: (...args) => calls.save.push(args),
    kickOffAttachmentDownload: options => calls.download.push(options),
    cancelAttachmentDownload: options => calls.cancel.push(options),
  });
  return { message, calls };
}
function clickDocument(message) {
  let stopped = false;
  let prevented = false;
  message.__documentClickForTest({
    stopPropagation() {
      stopped = true;
    },
    preventDefault() {
      prevented = true;
    },
  });
  assert.equal(stopped, true, 'Actual JSX click must stop propagation');
  assert.equal(
    prevented,
    true,
    'Actual JSX click must prevent the default action'
  );
}
function updateAttachment(message, attachment) {
  const previous = message.props;
  message.props = { ...previous, attachments: [attachment] };
  message.componentDidUpdate(previous);
}

test('actual message click selects direct opening for downloaded XLSX', () => {
  const { message, calls } = messageFor({
    fileName: 'report.xlsx',
    path: 'encrypted-local-file',
  });
  clickDocument(message);
  assert.equal(calls.save.length, 1);
  assert.equal(calls.save[0][3], true);
  assert.equal(calls.download.length, 0);
});

test('actual message click downloads XLSX and opens it exactly once when ready', () => {
  const attachment = { fileName: 'report.xlsx' };
  const { message, calls } = messageFor(attachment);
  clickDocument(message);
  assert.equal(calls.download.length, 1);
  assert.equal(calls.save.length, 0);
  updateAttachment(message, { ...attachment, pending: true });
  updateAttachment(message, {
    ...attachment,
    path: 'encrypted-local-file',
    pending: false,
  });
  updateAttachment(message, {
    ...attachment,
    path: 'encrypted-local-file',
    pending: false,
  });
  assert.equal(calls.save.length, 1);
  assert.equal(calls.save[0][3], true);
});

test('cancelling a pending download cancels the intent to open', () => {
  const attachment = { fileName: 'report.xlsx' };
  const { message, calls } = messageFor(attachment);
  clickDocument(message);
  updateAttachment(message, { ...attachment, pending: true });
  clickDocument(message);
  updateAttachment(message, {
    ...attachment,
    path: 'encrypted-local-file',
    pending: false,
  });
  assert.equal(calls.cancel.length, 1);
  assert.equal(calls.save.length, 0);
});

test('failed downloads do not launch an application after a later background retry', () => {
  const attachment = { fileName: 'report.xlsx' };
  const { message, calls } = messageFor(attachment);
  clickDocument(message);
  updateAttachment(message, { ...attachment, pending: true });
  updateAttachment(message, { ...attachment, pending: false, error: true });
  updateAttachment(message, { ...attachment, path: 'encrypted-local-file' });
  assert.equal(calls.save.length, 0);
});

test('clicking unsupported files keeps the existing save behavior', () => {
  const { message, calls } = messageFor({
    fileName: 'archive.zip',
    path: 'encrypted-local-file',
  });
  clickDocument(message);
  assert.equal(calls.save.length, 1);
  assert.equal(calls.save[0].length, 2);
});

test('legacy XLS attachments select direct opening too', async () => {
  const { message, calls } = messageFor({
    fileName: '业绩明细.xls',
    path: 'encrypted-local-file',
  });
  clickDocument(message);
  assert.equal(calls.save[0][3], true);
  let opened = false;
  await openDocumentAttachment({
    name: '业绩明细.xls',
    data,
    tempPath: join(root, 'legacy'),
    openPath: async filePath => {
      opened = filePath.endsWith('.xls');
      return '';
    },
  });
  assert.equal(opened, true);
});

test(
  'Windows namespaced temporary paths are normalized before calling the external app',
  { skip: process.platform !== 'win32' },
  async () => {
    await openDocumentAttachment({
      name: 'report.xlsx',
      data,
      tempPath: toNamespacedPath(join(root, 'namespaced')),
      openPath: async filePath => {
        assert.equal(filePath.startsWith('\\\\?\\'), false);
        assert.deepEqual(new Uint8Array(await readFile(filePath)), data);
        return '';
      },
    });
  }
);

test('shell paths preserve local and UNC locations while removing namespace prefixes', () => {
  assert.equal(
    normalizePathForShell('\\\\?\\C:\\Users\\test\\report.xlsx'),
    'C:\\Users\\test\\report.xlsx'
  );
  assert.equal(
    normalizePathForShell('\\\\?\\UNC\\server\\share\\report.xls'),
    '\\\\server\\share\\report.xls'
  );
  assert.equal(
    normalizePathForShell('C:\\Users\\test\\report.xlsx'),
    'C:\\Users\\test\\report.xlsx'
  );
  assert.equal(normalizePathForShell('/tmp/report.xlsx'), '/tmp/report.xlsx');
});

test('common document attachments select direct opening instead of Save As', () => {
  for (const extension of [
    'txt',
    'csv',
    'tsv',
    'pdf',
    'rtf',
    'doc',
    'docx',
    'xls',
    'xlsx',
    'ppt',
    'pptx',
    'odt',
    'ods',
    'odp',
  ]) {
    const { message, calls } = messageFor({
      fileName: 'document.' + extension,
      path: 'encrypted-local-file',
    });
    clickDocument(message);
    assert.equal(calls.save[0][3], true, extension);
  }
});
