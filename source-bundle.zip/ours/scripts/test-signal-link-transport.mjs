// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { once } from 'node:events';
import https from 'node:https';
import net from 'node:net';
import tls from 'node:tls';
import fetch from 'node-fetch';
import { SignalTlsProxyAgent } from '../ts/util/SignalTlsProxyAgent.node.ts';

const fixture = new URL('../test/fixtures/signal-tls-proxy/', import.meta.url);
const load = name => readFile(new URL(name, fixture), 'utf8');
const [outerCa, innerCa, proxyCert, proxyKey, targetCert, targetKey] =
  await Promise.all(
    [
      'outer-ca.pem',
      'inner-ca.pem',
      'proxy-cert.pem',
      'proxy-key.pem',
      'target-cert.pem',
      'target-key.pem',
    ].map(load)
  );
const roots = tls.getCACertificates('default');
tls.setDefaultCACertificates([...roots, outerCa]);
const sockets = new Set();
const track = socket => {
  sockets.add(socket);
  socket.on('error', () => {});
  socket.once('close', () => sockets.delete(socket));
};
const body = JSON.stringify({
  verificationCode: 'LOCAL-TEST-ONLY',
  data: 'x'.repeat(64 * 1024),
});
const backup = Buffer.alloc(256 * 1024, 0x5a);
const origin = https.createServer(
  { key: targetKey, cert: targetCert },
  (request, response) => {
    if (
      request.method === 'GET' &&
      request.url === '/attachments/local-test-backup'
    ) {
      assert.equal(request.headers.range, 'bytes=128-');
      response.writeHead(206, {
        'content-type': 'application/octet-stream',
        'content-range': `bytes 128-${backup.length - 1}/${backup.length}`,
        'content-length': backup.length - 128,
      });
      response.end(backup.subarray(128));
      return;
    }
    const chunks = [];
    request.on('data', chunk => chunks.push(chunk));
    request.on('end', () => {
      response.setHeader('content-type', 'application/json');
      response.end(
        JSON.stringify({
          method: request.method,
          path: request.url,
          authorization: request.headers.authorization,
          body: Buffer.concat(chunks).toString(),
        })
      );
    });
  }
);
origin.on('connection', track);
origin.listen(0, '127.0.0.1');
await once(origin, 'listening');
const proxy = tls.createServer({ key: proxyKey, cert: proxyCert }, socket => {
  track(socket);
  const upstream = net.connect({
    host: '127.0.0.1',
    port: origin.address().port,
  });
  track(upstream);
  socket.pipe(upstream).pipe(socket);
  socket.once('close', () => upstream.destroy());
  upstream.once('close', () => socket.destroy());
});
proxy.on('connection', track);
proxy.listen(0, '127.0.0.1');
await once(proxy, 'listening');
const agent = new SignalTlsProxyAgent(
  `org.signal.tls://localhost:${proxy.address().port}`
);
try {
  const response = await fetch(
    'https://signal-destination.test/v1/devices/link',
    {
      method: 'PUT',
      agent,
      ca: innerCa,
      headers: {
        authorization: 'Basic LOCAL-TEST-ONLY',
        'content-type': 'application/json',
      },
      body,
      signal: AbortSignal.timeout(5_000),
    }
  );
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), {
    method: 'PUT',
    path: '/v1/devices/link',
    authorization: 'Basic LOCAL-TEST-ONLY',
    body,
  });
  const download = await fetch(
    'https://signal-destination.test/attachments/local-test-backup',
    {
      agent,
      ca: innerCa,
      headers: { range: 'bytes=128-' },
      signal: AbortSignal.timeout(5_000),
    }
  );
  assert.equal(download.status, 206);
  assert.equal(
    download.headers.get('content-range'),
    `bytes 128-${backup.length - 1}/${backup.length}`
  );
  const chunks = [];
  for await (const chunk of download.body) chunks.push(chunk);
  assert.deepEqual(Buffer.concat(chunks), backup.subarray(128));
  console.log(
    'PASS: patched node-fetch PUT binding transport and streamed/ranged GET backup download, independent target CA, double TLS and browser timer globals (loopback only; no real account linked)'
  );
} finally {
  agent.destroy();
  for (const socket of sockets) socket.destroy();
  await Promise.all([
    new Promise(resolve => origin.close(resolve)),
    new Promise(resolve => proxy.close(resolve)),
  ]);
  tls.setDefaultCACertificates(roots);
}
