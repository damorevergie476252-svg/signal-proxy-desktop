// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { gt, valid } from 'semver';

type Config = Readonly<{
  has(key: string): boolean;
  get<T>(key: string): T;
}>;

export type ProxyUpdateChannel = Readonly<{
  baseUrl: string;
  publicKey: string;
}>;

export function isProxyDistribution(packageName: string): boolean {
  return packageName === 'signal-desktop-proxy';
}

export function getProxyUpdateChannel(
  config: Config,
  packageName: string
): ProxyUpdateChannel | undefined {
  if (!isProxyDistribution(packageName) || !config.has('proxyUpdates')) {
    return undefined;
  }

  const channel = config.get<unknown>('proxyUpdates');
  if (typeof channel !== 'object' || channel === null) {
    throw new Error('Invalid proxy update channel');
  }
  const { repository, publicKey } = channel as Record<string, unknown>;
  if (
    typeof repository !== 'string' ||
    !/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})\/[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/.test(
      repository
    ) ||
    typeof publicKey !== 'string' ||
    !/^05[0-9a-f]{64}$/.test(publicKey)
  ) {
    throw new Error('Invalid proxy update repository or public key');
  }

  return {
    baseUrl: `https://github.com/${repository}/releases/latest/download`,
    publicKey,
  };
}

export function isNewerProxyVersion(
  candidate: string,
  current: string
): boolean {
  return (
    /^\d+\.\d+\.\d+-adhoc\.\d{8}\.(?:\d+-sgpx|r\.\d+\.sgpx)$/.test(candidate) &&
    valid(candidate) !== null &&
    valid(current) !== null &&
    gt(candidate, current)
  );
}

export function assertProxyInstaller(fileName: string, arch: string): void {
  if (
    arch !== 'x64' ||
    !/^Signal-Proxy-\d+\.\d+\.\d+-x64-Setup-[A-Za-z0-9._-]+\.exe$/.test(
      fileName
    )
  ) {
    throw new Error('The proxy update must be an x64 Signal Proxy installer');
  }
}
