// Copyright 2019 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only

import config from 'config';
import { app } from 'electron';
import type { Updater, UpdaterOptionsType } from './common.main.ts';
import { MacOSUpdater } from './macos.main.ts';
import { WindowsUpdater } from './windows.main.ts';
import { LinuxAppImageUpdater } from './linuxAppImage.main.ts';
import { initLinux } from './linux.main.ts';
import { NoUpdateAvailableError } from './common.main.ts';
import { packageJson } from '../util/packageJson.main.ts';
import {
  getProxyUpdateChannel,
  isProxyDistribution,
} from './proxyChannel.std.ts';

let initialized = false;

let updater: Updater | undefined;

export async function start(options: UpdaterOptionsType): Promise<void> {
  const { platform } = process;
  const { logger } = options;

  if (initialized) {
    throw new Error('updater/start: Updates have already been initialized!');
  }
  initialized = true;

  if (!logger) {
    throw new Error('updater/start: Must provide logger!');
  }

  if (autoUpdateDisabled()) {
    logger.info(
      'updater/start: Updates disabled - not starting new version checks'
    );

    return;
  }

  if (platform === 'win32') {
    updater = new WindowsUpdater(options);
  } else if (platform === 'darwin') {
    updater = new MacOSUpdater(options);
  } else if (platform === 'linux') {
    if (process.env.APPIMAGE != null) {
      updater = new LinuxAppImageUpdater(options);
    } else {
      initLinux(options);
    }
  } else {
    throw new Error(`updater/start: Unsupported platform ${platform}`);
  }

  await updater?.start();
}

export async function force(): Promise<void> {
  if (!initialized) {
    throw new Error("updater/force: Updates haven't been initialized!");
  }

  if (updater) {
    await updater.force();
  }
}

export async function check(): Promise<'offered' | 'up-to-date'> {
  if (!updater) {
    throw new Error('The update service is not available');
  }
  try {
    await updater.forceCheck();
    return 'offered';
  } catch (error) {
    if (error instanceof NoUpdateAvailableError) {
      return 'up-to-date';
    }
    throw error;
  }
}

export function onRestartCanceled(): void {
  if (updater) {
    updater.onRestartCanceled();
  }
}

function autoUpdateDisabled() {
  if (isProxyDistribution(packageJson.name)) {
    return (
      process.platform !== 'win32' ||
      process.arch !== 'x64' ||
      Boolean(process.env.PORTABLE_EXECUTABLE_FILE) ||
      !getProxyUpdateChannel(config, packageJson.name) ||
      !app.isPackaged ||
      !config.get('updatesEnabled')
    );
  }
  return !app.isPackaged || !config.get('updatesEnabled');
}
