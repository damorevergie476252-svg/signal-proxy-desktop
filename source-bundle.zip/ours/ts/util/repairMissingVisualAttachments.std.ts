// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import type { AttachmentType } from '../types/Attachment.std.ts';
import type { MessageAttributesType } from '../model-types.std.ts';

// Retain all download keys and locators. Only invalidate local files proved missing.
export async function repairMissingVisualAttachments(
  message: Pick<
    MessageAttributesType,
    'attachments' | 'preview' | 'editHistory'
  >,
  exists: (path: string) => Promise<boolean>
): Promise<
  | Pick<MessageAttributesType, 'attachments' | 'preview' | 'editHistory'>
  | undefined
> {
  let changed = false;
  async function repair(attachment: AttachmentType): Promise<AttachmentType> {
    if (!attachment.contentType.startsWith('image/')) return attachment;
    const missing = attachment.path && !(await exists(attachment.path));
    const thumbnailMissing =
      attachment.thumbnail?.path && !(await exists(attachment.thumbnail.path));
    const backupThumbnailMissing =
      attachment.thumbnailFromBackup?.path &&
      !(await exists(attachment.thumbnailFromBackup.path));
    if (!missing && !thumbnailMissing && !backupThumbnailMissing)
      return attachment;
    changed = true;
    return {
      ...attachment,
      ...(missing
        ? {
            path: undefined,
            pending: false,
            error: undefined,
            totalDownloaded: undefined,
          }
        : {}),
      ...(thumbnailMissing ? { thumbnail: undefined } : {}),
      ...(backupThumbnailMissing ? { thumbnailFromBackup: undefined } : {}),
    };
  }
  async function repairEntry<
    T extends Pick<MessageAttributesType, 'attachments' | 'preview'>,
  >(entry: T): Promise<T> {
    return {
      ...entry,
      attachments:
        entry.attachments && (await Promise.all(entry.attachments.map(repair))),
      preview:
        entry.preview &&
        (await Promise.all(
          entry.preview.map(async item => ({
            ...item,
            image: item.image && (await repair(item.image)),
          }))
        )),
    };
  }
  const root = await repairEntry(message);
  const editHistory =
    message.editHistory &&
    (await Promise.all(message.editHistory.map(repairEntry)));
  return changed
    ? { attachments: root.attachments, preview: root.preview, editHistory }
    : undefined;
}
