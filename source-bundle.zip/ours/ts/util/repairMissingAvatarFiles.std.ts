// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

export type AvatarRepairTarget = Readonly<{
  getPaths: () => ReadonlyArray<string>;
  repair: () => Promise<void>;
}>;

export async function repairMissingAvatarFiles(
  targets: ReadonlyArray<AvatarRepairTarget>,
  exists: (path: string) => Promise<boolean>
): Promise<{
  checked: number;
  missing: number;
  repaired: number;
  unresolved: number;
}> {
  const result = { checked: 0, missing: 0, repaired: 0, unresolved: 0 };
  for (const target of targets) {
    result.checked += 1;
    const paths = target.getPaths();
    if (!paths.length || (await Promise.all(paths.map(exists))).every(Boolean))
      continue;
    result.missing += 1;
    try {
      await target.repair();
      if ((await Promise.all(target.getPaths().map(exists))).every(Boolean)) {
        result.repaired += 1;
      } else {
        result.unresolved += 1;
      }
    } catch {
      result.unresolved += 1;
    }
  }
  return result;
}
