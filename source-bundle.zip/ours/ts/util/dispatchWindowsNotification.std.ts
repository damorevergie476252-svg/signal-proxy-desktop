// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import type {
  NotificationClickData,
  WindowsNotificationData,
} from '../services/notifications.preload.ts';
import { NotificationType } from '../types/notifications.std.ts';

export function dispatchWindowsNotification(
  data: WindowsNotificationData,
  actions: {
    showConversation: (target: NotificationClickData) => void;
    openInbox: () => void;
    startCallLobby: (conversationId: string) => void;
    cancelPresenting: () => void;
  }
): void {
  switch (data.type) {
    case NotificationType.Message:
    case NotificationType.Reaction:
    case NotificationType.UnreadReminder:
      if (data.target) actions.showConversation(data.target);
      else actions.openInbox();
      return;
    case NotificationType.IncomingGroupCall:
      if (data.target) actions.startCallLobby(data.target.conversationId);
      return;
    case NotificationType.IsPresenting:
      actions.cancelPresenting();
      return;
    case NotificationType.IncomingCall:
      return;
    default:
      throw new Error('Unknown Windows notification type');
  }
}
