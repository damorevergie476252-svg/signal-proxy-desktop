// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { mkdir, mkdtemp, rm } from 'node:fs/promises';
import { realpath } from 'node:fs';
import { join } from 'node:path';
import { promisify } from 'node:util';

import { isOpenableDocumentFileName } from './isOpenableDocumentFileName.std.ts';
import { writeAttachmentWithAttributes } from './writeAttachmentWithAttributes.node.ts';

const nativeRealpath = promisify(realpath.native);

export function normalizePathForShell(filePath: string): string {
  const prefix = '\\\\?\\';
  if (filePath.startsWith(prefix + 'UNC\\')) {
    return '\\\\' + filePath.slice(prefix.length + 4);
  }
  return filePath.startsWith(prefix) ? filePath.slice(prefix.length) : filePath;
}

export async function openDocumentAttachment({
  name,
  data,
  tempPath,
  openPath,
}: {
  name: string;
  data: Uint8Array<ArrayBuffer>;
  tempPath: string;
  openPath: (filePath: string) => Promise<string>;
}): Promise<void> {
  if (!isOpenableDocumentFileName(name) || !(data instanceof Uint8Array)) {
    throw new Error('Invalid document attachment');
  }

  await mkdir(tempPath, { recursive: true });
  // A separate directory preserves the filename without collisions or overwrites.
  // Signal clears this existing temporary-file area at its next startup.
  const directory = await mkdtemp(join(tempPath, 'open-document-'));
  try {
    const filePath = join(directory, name);
    await writeAttachmentWithAttributes(filePath, data);
    // External applications do not share MSIX filesystem redirection, and many
    // shell handlers reject the extended-length prefix accepted by Node's fs.
    const externalPath = normalizePathForShell(await nativeRealpath(filePath));
    const error = await openPath(externalPath);
    if (error) {
      throw new Error(`Could not open document attachment: ${error}`);
    }
  } catch (error) {
    await rm(directory, { recursive: true, force: true });
    throw error;
  }
}
