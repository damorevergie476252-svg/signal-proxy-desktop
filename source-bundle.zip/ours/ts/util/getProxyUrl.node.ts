// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { normalizeSignalTlsProxyUrl } from './signalTlsProxyUrl.std.ts';

type ProxyConfig = {
  has(key: string): boolean;
  get<T>(key: string): T;
};

// The caller owns node-config initialization. Do not load or mutate it here.
export function getProxyUrl(
  config: ProxyConfig,
  env: Readonly<Record<string, string | undefined>> = process.env
): string | undefined {
  const override = env.HTTPS_PROXY || env.https_proxy;
  if (override) {
    return override;
  }
  if (!config.has('signalTlsProxyUrl')) {
    return undefined;
  }
  const configured = config.get<string>('signalTlsProxyUrl');
  return configured ? normalizeSignalTlsProxyUrl(configured) : undefined;
}
