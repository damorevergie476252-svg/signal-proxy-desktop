// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import type { ClientRequest } from 'node:http';
import { isIP } from 'node:net';
import {
  setTimeout,
  clearTimeout,
  setInterval,
  clearInterval,
} from 'node:timers';
import tls from 'node:tls';
import { HttpsProxyAgent } from 'https-proxy-agent';

import { normalizeSignalTlsProxyUrl } from './signalTlsProxyUrl.std.ts';

type ConnectOptions = Parameters<HttpsProxyAgent<'https:'>['connect']>[1];
const HANDSHAKE_TIMEOUT = 15_000;

function waitForTls(
  socket: tls.TLSSocket,
  request: ClientRequest
): Promise<tls.TLSSocket> {
  return new Promise((resolve, reject) => {
    function cleanup(): void {
      clearTimeout(timer);
      clearInterval(cancellationCheck);
      socket.removeListener('secureConnect', onConnect);
      socket.removeListener('error', onError);
      socket.removeListener('close', onClose);
      request.removeListener('close', onRequestClose);
    }
    function onError(error: Error): void {
      cleanup();
      socket.destroy();
      reject(error);
    }
    function onClose(): void {
      onError(new Error('Signal TLS proxy closed during handshake'));
    }
    function onRequestClose(): void {
      const error = new Error(
        'Request closed during Signal TLS proxy handshake'
      );
      error.name = 'AbortError';
      onError(error);
    }
    function onConnect(): void {
      cleanup();
      resolve(socket);
    }
    const timer = setTimeout(() => {
      onError(new Error('Signal TLS proxy handshake timed out'));
    }, HANDSHAKE_TIMEOUT);
    timer.unref();
    // ClientRequest defers its close event while an async Agent is obtaining
    // a socket. Observe its public destroyed flag during that bounded phase.
    const cancellationCheck = setInterval(() => {
      if (request.destroyed) {
        onRequestClose();
      }
    }, 100);
    cancellationCheck.unref();
    socket.once('secureConnect', onConnect);
    socket.once('error', onError);
    socket.once('close', onClose);
    request.once('close', onRequestClose);
    if (request.destroyed) {
      onRequestClose();
    }
  });
}

// Reuse agent-base's HTTP/WebSocket pooling and request ownership through the
// existing dependency. Replace only CONNECT with Signal's TLS-inside-TLS wire
// protocol. Both certificates are verified against their respective hostname.
export class SignalTlsProxyAgent extends HttpsProxyAgent<'https:'> {
  constructor(proxyUrl: string) {
    const proxy = new URL(normalizeSignalTlsProxyUrl(proxyUrl));
    super(new URL(`https://${proxy.host}`));
  }

  override async connect(
    request: ClientRequest,
    options: ConnectOptions
  ): Promise<tls.TLSSocket> {
    if (
      !options.secureEndpoint ||
      Number(options.port) !== 443 ||
      !options.host
    ) {
      throw new Error('Signal TLS proxies require an HTTPS destination on 443');
    }

    const host = this.proxy.hostname.replace(/^\[|\]$/g, '');
    // The target's private CA, client certificate and TLS options must never
    // affect verification of the public proxy's outer TLS connection.
    const outer = tls.connect({
      host,
      port: Number(this.proxy.port || 443),
      servername: isIP(host) ? undefined : host,
      rejectUnauthorized: true,
    });
    try {
      await waitForTls(outer, request);
      const {
        host: targetHost,
        port: _port,
        path: _path,
        ...targetOptions
      } = options;
      const inner = tls.connect({
        ...targetOptions,
        socket: outer,
        servername: options.servername || targetHost,
        rejectUnauthorized: true,
      });
      try {
        return await waitForTls(inner, request);
      } catch (error) {
        inner.destroy();
        throw error;
      }
    } catch (error) {
      outer.destroy();
      throw error;
    }
  }
}
