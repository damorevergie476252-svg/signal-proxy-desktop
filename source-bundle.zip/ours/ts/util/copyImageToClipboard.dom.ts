// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

export function isCopyableImageUrl(value: string | undefined): value is string {
  if (!value) {
    return false;
  }
  try {
    const url = new URL(value);
    return (
      url.protocol === 'attachment:' &&
      (url.hostname === 'v1' || url.hostname === 'v2') &&
      (!url.searchParams.has('disposition') ||
        url.searchParams.get('disposition') === 'attachment')
    );
  } catch {
    return false;
  }
}

export async function copyImageToClipboard(url: string): Promise<void> {
  if (!isCopyableImageUrl(url)) {
    throw new Error('Only regular local image attachments can be copied');
  }
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error('Could not read the image attachment');
  }
  // Decode the full attachment, including formats NativeImage cannot read.
  const image = await createImageBitmap(await response.blob());
  try {
    const canvas = new OffscreenCanvas(image.width, image.height);
    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Could not decode the image attachment');
    }
    context.drawImage(image, 0, 0);
    const png = await canvas.convertToBlob({ type: 'image/png' });
    await window.IPC.copyImage(new Uint8Array(await png.arrayBuffer()));
  } finally {
    image.close();
  }
}
