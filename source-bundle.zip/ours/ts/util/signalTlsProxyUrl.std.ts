// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

export const SIGNAL_TLS_PROXY_PROTOCOL = 'org.signal.tls:';

// Signal's sharing URL is configuration data, not an HTTPS CONNECT endpoint.
export function normalizeSignalTlsProxyUrl(value: string): string {
  let address = value.trim();
  if (address.startsWith('https://')) {
    const link = new URL(address);
    if (
      link.hostname !== 'signal.tube' ||
      link.port ||
      link.username ||
      link.password ||
      link.pathname !== '/' ||
      link.search ||
      !link.hash
    ) {
      throw new Error('Expected a https://signal.tube/#host proxy link');
    }
    address = decodeURIComponent(link.hash.slice(1));
  }

  const proxy = new URL(
    address.includes('://')
      ? address
      : `${SIGNAL_TLS_PROXY_PROTOCOL}//${address}`
  );
  if (
    proxy.protocol !== SIGNAL_TLS_PROXY_PROTOCOL ||
    !proxy.hostname ||
    proxy.username ||
    proxy.password ||
    (proxy.pathname !== '' && proxy.pathname !== '/') ||
    proxy.search ||
    proxy.hash ||
    proxy.port === '0'
  ) {
    throw new Error('Invalid Signal TLS proxy address');
  }

  return `${SIGNAL_TLS_PROXY_PROTOCOL}//${proxy.hostname}:${proxy.port || 443}`;
}
