// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

export function isOpenableDocumentFileName(
  name: string | null | undefined
): boolean {
  return (
    typeof name === 'string' &&
    name.length <= 255 &&
    /^[^<>:"/\\|?*\u0000-\u001f]+\.(txt|csv|tsv|pdf|rtf|docx?|xlsx?|pptx?|odt|ods|odp)$/i.test(
      name
    )
  );
}
