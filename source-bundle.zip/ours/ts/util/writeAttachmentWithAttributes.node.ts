// Copyright 2018 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only

import { writeFile, unlink } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { v4 as getGuid } from 'uuid';

import { writeWindowsZoneIdentifier } from './windowsZoneIdentifier.node.ts';
import OS from './os/osMain.node.ts';
import { createLogger } from '../logging/log.std.ts';

const log = createLogger('attachments');

export async function writeAttachmentWithAttributes(
  target: string,
  data: Uint8Array<ArrayBuffer> | Readable
): Promise<void> {
  if (data instanceof Readable) {
    try {
      const output = createWriteStream(target);
      await pipeline(data, output);
    } catch (error) {
      await unlink(target).catch(() => {});
      throw error;
    }
  } else {
    await writeFile(target, data);
  }

  if (process.platform === 'darwin') {
    const xattr = await import('fs-xattr');
    // kLSQuarantineTypeInstantMessageAttachment
    const timestamp = Math.trunc(Date.now() / 1000).toString(16);
    await xattr.setAttribute(
      target,
      'com.apple.quarantine',
      `0003;${timestamp};Signal;${getGuid()}`
    );
  } else if (OS.isWindows()) {
    try {
      await writeWindowsZoneIdentifier(target);
    } catch {
      log.error('Failed to write Windows Zone.Identifier file; continuing');
    }
  }
}
