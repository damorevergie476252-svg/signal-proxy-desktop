// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only
export {};

type LockState = {
  enabled: boolean;
  locked: boolean;
  broken: boolean;
  mode: string;
  retryAfter: number;
};
const api = (
  window as unknown as {
    SignalLocalLock: {
      status: () => Promise<LockState>;
      submit: (
        value: unknown
      ) => Promise<Partial<LockState> & { error?: string; saved?: boolean }>;
    };
  }
).SignalLocalLock;
const form = document.querySelector<HTMLFormElement>('form')!;
const code = document.querySelector<HTMLInputElement>('#code')!;
const next = document.querySelector<HTMLInputElement>('#next')!;
const confirm = document.querySelector<HTMLInputElement>('#confirm')!;
const message = document.querySelector<HTMLParagraphElement>('#message')!;
const disable = document.querySelector<HTMLButtonElement>('#disable')!;
let state: LockState;

function render(): void {
  const settings = state.mode === 'settings';
  document.querySelector('#title')!.textContent = settings
    ? '本机锁定码'
    : 'Signal Proxy 已锁定';
  document.querySelector('#intro')!.textContent = settings
    ? '设置后，启动、Windows 锁屏和闲置 5 分钟时自动锁定。'
    : '输入本机锁定码，继续查看聊天。';
  document.querySelector<HTMLElement>('#current')!.hidden =
    settings && !state.enabled;
  document.querySelector('#code-label')!.textContent = settings
    ? '原锁定码'
    : '锁定码';
  document.querySelector<HTMLElement>('#new-code')!.hidden = !settings;
  document.querySelector<HTMLButtonElement>('#submit')!.textContent = settings
    ? '保存锁定码'
    : '解锁';
  disable.hidden = !settings || !state.enabled;
  if (state.broken)
    message.textContent =
      '本机锁定配置无法读取，请恢复该配置的备份后重试。聊天资料未被重置。';
  (settings && !state.enabled ? next : code).focus();
}

async function submit(remove: boolean): Promise<void> {
  message.textContent = '';
  if (state.mode === 'settings' && !remove && next.value !== confirm.value) {
    message.textContent = '两次输入的锁定码不一致。';
    confirm.focus();
    return;
  }
  const buttons = [...document.querySelectorAll('button')];
  buttons.forEach(button => {
    button.disabled = true;
  });
  try {
    const result = await api.submit({
      action: state.mode === 'settings' ? 'configure' : 'unlock',
      code: code.value,
      newCode: remove ? null : next.value,
    });
    code.value = '';
    next.value = '';
    confirm.value = '';
    if (result.error) message.textContent = result.error;
    else if (result.saved) {
      state = await api.status();
      render();
      message.textContent = state.enabled
        ? '锁定码已保存。可按 Ctrl+Shift+L 立即锁定。'
        : '本机锁定码已关闭。';
    }
  } catch {
    message.textContent = '操作未完成，请重新打开锁定窗口后重试。';
  } finally {
    buttons.forEach(button => {
      button.disabled = false;
    });
  }
}

form.addEventListener('submit', event => {
  event.preventDefault();
  void submit(false);
});
disable.addEventListener('click', () => {
  void submit(true);
});
void api
  .status()
  .then(value => {
    state = value;
    render();
  })
  .catch(() => {
    message.textContent = '无法读取本机锁定状态，请重启程序。';
  });
