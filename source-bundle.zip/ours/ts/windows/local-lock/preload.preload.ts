// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only
import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('SignalLocalLock', {
  status: () => ipcRenderer.invoke('local-lock:status'),
  submit: (value: unknown) => ipcRenderer.invoke('local-lock:submit', value),
});
