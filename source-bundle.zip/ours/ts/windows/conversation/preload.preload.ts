// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { contextBridge, ipcRenderer } from 'electron';
import type { DetachedConversationAPI } from '../../types/DetachedConversation.std.ts';

const api: DetachedConversationAPI = {
  request: command =>
    ipcRenderer.invoke('conversation-window:request', command),
  subscribe: listener => {
    const handler: Parameters<typeof ipcRenderer.on>[1] = (_event, snapshot) =>
      listener(snapshot);
    ipcRenderer.on('conversation-window:update', handler);
    return () =>
      ipcRenderer.removeListener('conversation-window:update', handler);
  },
};
contextBridge.exposeInMainWorld('SignalConversationWindow', api);
contextBridge.exposeInMainWorld('IPC', {
  copyImage: (data: Uint8Array<ArrayBuffer>) =>
    ipcRenderer.invoke('copy-image', data),
});
