// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
} from 'react';
import { createRoot } from 'react-dom/client';
import type { JSX } from 'react';
import type {
  DetachedConversationSnapshot,
  DetachedMessage,
} from '../../types/DetachedConversation.std.ts';
import { copyImageToClipboard } from '../../util/copyImageToClipboard.dom.ts';
import { ConversationAvatar } from './Avatar.dom.tsx';

export function DetachedConversation(): JSX.Element {
  const api = window.SignalConversationWindow;
  const [snapshot, setSnapshot] = useState<DetachedConversationSnapshot>();
  const [body, setBody] = useState('');
  const [files, setFiles] = useState<ReadonlyArray<File>>([]);
  const [busy, setBusy] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [error, setError] = useState('');
  const [preview, setPreview] = useState<string>();
  const [imageMenu, setImageMenu] = useState<{
    url: string;
    x: number;
    y: number;
  }>();
  const timeline = useRef<HTMLElement>(null);
  const current = useRef(snapshot);
  const nearBottom = useRef(true);
  const prependPosition = useRef<{ height: number; top: number } | undefined>(
    undefined
  );
  const lastRead = useRef<string | undefined>(undefined);
  const sending = useRef(false);
  const imageRepairs = useRef(new Set<string>());
  const clientId = useRef(crypto.randomUUID());
  const pendingAttachment = useRef<{ id: string; index: number } | undefined>(
    undefined
  );
  current.current = snapshot;

  const acceptSnapshot = useCallback((next: DetachedConversationSnapshot) => {
    setSnapshot(previous =>
      !previous || next.version > previous.version ? next : previous
    );
  }, []);
  const showError = useCallback((reason: unknown) => {
    setError(reason instanceof Error ? reason.message : '操作失败，请重试。');
  }, []);
  useEffect(() => {
    const unsubscribe = api.subscribe(acceptSnapshot);
    void api
      .request({ type: 'snapshot' })
      .then(
        value => acceptSnapshot(value as DetachedConversationSnapshot),
        showError
      );
    return unsubscribe;
  }, [api, acceptSnapshot, showError]);

  const markVisibleRead = useCallback(() => {
    const latest = current.current?.messages.at(-1);
    if (
      !document.hasFocus() ||
      !nearBottom.current ||
      !latest ||
      lastRead.current === latest.id
    )
      return;
    lastRead.current = latest.id;
    void api.request({ type: 'mark-read', messageId: latest.id }).then(
      result => {
        if (result === false) lastRead.current = undefined;
      },
      () => {
        lastRead.current = undefined;
      }
    );
  }, [api]);
  useEffect(() => {
    window.addEventListener('focus', markVisibleRead);
    return () => window.removeEventListener('focus', markVisibleRead);
  }, [markVisibleRead]);
  useLayoutEffect(() => {
    const element = timeline.current;
    if (!element) return;
    if (prependPosition.current) {
      element.scrollTop =
        prependPosition.current.top +
        element.scrollHeight -
        prependPosition.current.height;
      prependPosition.current = undefined;
    } else if (nearBottom.current) {
      element.scrollTop = element.scrollHeight;
    }
    markVisibleRead();
  }, [snapshot, markVisibleRead]);

  async function openAttachment(
    message: DetachedMessage,
    index: number
  ): Promise<void> {
    const attachment = message.attachments[index];
    if (!attachment) return;
    setError('');
    if (attachment.url && attachment.contentType.startsWith('image/')) {
      setPreview(attachment.url);
      return;
    }
    try {
      const result = await api.request({
        type: 'attachment',
        messageId: message.id,
        index,
      });
      pendingAttachment.current =
        result === 'downloading' ? { id: message.id, index } : undefined;
    } catch (reason) {
      showError(reason);
    }
  }
  useEffect(() => {
    const pending = pendingAttachment.current;
    if (!pending || !snapshot) return;
    const message = snapshot.messages.find(item => item.id === pending.id);
    if (message?.attachments[pending.index]?.url) {
      pendingAttachment.current = undefined;
      void openAttachment(message, pending.index);
    }
  }, [snapshot]);
  useEffect(() => {
    if (
      preview &&
      snapshot &&
      !snapshot.messages.some(message =>
        message.attachments.some(attachment => attachment.url === preview)
      )
    ) {
      setPreview(undefined);
    }
  }, [snapshot, preview]);

  async function send(): Promise<void> {
    if (
      sending.current ||
      (!body.trim() && files.length === 0) ||
      !snapshot?.canSend
    )
      return;
    sending.current = true;
    setBusy(true);
    setError('');
    try {
      const attachments = await Promise.all(
        files.map(async file => ({
          name: file.name,
          type: file.type,
          data: new Uint8Array(await file.arrayBuffer()),
        }))
      );
      await api.request({
        type: 'send',
        clientId: clientId.current,
        body,
        files: attachments,
      });
      setBody('');
      setFiles([]);
      clientId.current = crypto.randomUUID();
      nearBottom.current = true;
    } catch (reason) {
      showError(reason);
    } finally {
      sending.current = false;
      setBusy(false);
    }
  }
  async function loadOlder(): Promise<void> {
    if (loadingOlder || !timeline.current) return;
    setLoadingOlder(true);
    const position = {
      height: timeline.current.scrollHeight,
      top: timeline.current.scrollTop,
    };
    try {
      const next = await api.request({ type: 'older' });
      prependPosition.current = position;
      acceptSnapshot(next as DetachedConversationSnapshot);
    } catch (reason) {
      showError(reason);
    } finally {
      setLoadingOlder(false);
    }
  }
  function stageFiles(next: ReadonlyArray<File>): void {
    if (sending.current) return;
    setFiles(previous => [...previous, ...next]);
    clientId.current = crypto.randomUUID();
  }
  const formatTime = (timestamp: number) =>
    new Date(timestamp).toLocaleString();
  return (
    <main
      className="detached-chat"
      onClick={() => setImageMenu(undefined)}
      onDragOver={event => event.preventDefault()}
      onDrop={event => {
        event.preventDefault();
        stageFiles([...event.dataTransfer.files]);
      }}
    >
      <header>
        <ConversationAvatar
          url={snapshot?.avatarUrl}
          title={snapshot?.title ?? ''}
          isGroup={snapshot?.isGroup}
        />
        <div>
          <h1>{snapshot?.title ?? '正在打开聊天…'}</h1>
          <span>Signal Proxy</span>
        </div>
      </header>
      <section
        className="detached-chat__messages"
        aria-label="聊天记录"
        ref={timeline}
        onScroll={() => {
          const element = timeline.current;
          if (element)
            nearBottom.current =
              element.scrollHeight - element.scrollTop - element.clientHeight <
              80;
          markVisibleRead();
        }}
      >
        {snapshot?.hasMore && (
          <button
            className="detached-chat__older"
            disabled={loadingOlder}
            onClick={() => {
              void loadOlder();
            }}
          >
            {loadingOlder ? '正在加载…' : '加载更早的消息'}
          </button>
        )}
        {snapshot?.messages.map(message => (
          <article
            key={message.id}
            data-message-id={message.id}
            className={
              message.system
                ? 'detached-chat__system'
                : `detached-chat__message ${message.outgoing ? 'outgoing' : 'incoming'}`
            }
          >
            {!message.system && (
              <div className="detached-chat__identity">
                {!message.outgoing && (
                  <ConversationAvatar
                    url={message.authorAvatarUrl}
                    title={message.author}
                  />
                )}
                <div className="detached-chat__author">
                  {message.outgoing ? '我' : message.author}
                </div>
              </div>
            )}
            {message.body && (
              <div className="detached-chat__body">{message.body}</div>
            )}
            {message.attachments.map((attachment, index) => (
              <div key={index} className="detached-chat__attachment">
                {attachment.url &&
                attachment.contentType.startsWith('image/') ? (
                  <button
                    className="detached-chat__image"
                    onClick={() => {
                      void openAttachment(message, index);
                    }}
                  >
                    <img
                      src={attachment.url}
                      alt={attachment.name}
                      onError={() => {
                        const key = `${message.id}:${index}`;
                        if (imageRepairs.current.has(key)) return;
                        imageRepairs.current.add(key);
                        void api
                          .request({
                            type: 'attachment',
                            messageId: message.id,
                            index,
                            repairMissing: true,
                          })
                          .catch(showError);
                      }}
                      onContextMenu={event => {
                        event.preventDefault();
                        event.stopPropagation();
                        setImageMenu({
                          url: attachment.url ?? '',
                          x: Math.min(event.clientX, window.innerWidth - 160),
                          y: Math.min(event.clientY, window.innerHeight - 60),
                        });
                      }}
                    />
                  </button>
                ) : attachment.url &&
                  /^(audio|video)\//.test(attachment.contentType) ? (
                  attachment.contentType.startsWith('audio/') ? (
                    <audio src={attachment.url} controls preload="none" />
                  ) : (
                    <video src={attachment.url} controls preload="metadata" />
                  )
                ) : (
                  <button
                    disabled={attachment.pending}
                    onClick={() => {
                      void openAttachment(message, index);
                    }}
                  >
                    {attachment.pending
                      ? '正在下载…'
                      : attachment.url
                        ? attachment.name
                        : `下载 ${attachment.name}`}
                  </button>
                )}
              </div>
            ))}
            <div className="detached-chat__time">
              <time dateTime={new Date(message.sentAt).toISOString()}>
                {formatTime(message.sentAt)}
              </time>
              {message.status && <span> · {message.status}</span>}
            </div>
          </article>
        ))}
        {snapshot && snapshot.messages.length === 0 && (
          <p className="detached-chat__empty">暂无消息</p>
        )}
      </section>
      {error && (
        <div role="alert" className="detached-chat__error">
          {error}
        </div>
      )}
      {snapshot && !snapshot.canSend && (
        <div className="detached-chat__notice">
          此会话暂时无法发送，请在主窗口查看。
        </div>
      )}
      <footer>
        {files.length > 0 && (
          <ul aria-label="待发送附件">
            {files.map((file, index) => (
              <li key={index}>
                {file.name}
                <button
                  disabled={busy}
                  aria-label={`移除 ${file.name}`}
                  onClick={() => {
                    setFiles(previous =>
                      previous.filter((_, itemIndex) => itemIndex !== index)
                    );
                    clientId.current = crypto.randomUUID();
                  }}
                >
                  ×
                </button>
              </li>
            ))}
          </ul>
        )}
        <textarea
          aria-label="消息"
          placeholder="输入消息…"
          value={body}
          maxLength={65536}
          disabled={busy || !snapshot?.canSend}
          onChange={event => {
            setBody(event.target.value);
            clientId.current = crypto.randomUUID();
          }}
          onPaste={event => {
            const pasted = [...event.clipboardData.files];
            if (pasted.length) {
              event.preventDefault();
              stageFiles(pasted);
            }
          }}
          onKeyDown={event => {
            if (
              event.key === 'Enter' &&
              !event.shiftKey &&
              !event.nativeEvent.isComposing
            ) {
              event.preventDefault();
              void send();
            }
          }}
        />
        <div className="detached-chat__tools">
          <span>Enter 发送 · Shift+Enter 换行</span>
          <button
            className="detached-chat__send"
            disabled={
              busy || !snapshot?.canSend || (!body.trim() && files.length === 0)
            }
            onClick={() => {
              void send();
            }}
          >
            {busy ? '正在发送…' : '发送'}
          </button>
        </div>
      </footer>
      {imageMenu && (
        <div
          role="menu"
          className="detached-chat__image-menu"
          style={{ left: imageMenu.x, top: imageMenu.y }}
        >
          <button
            role="menuitem"
            onClick={() => {
              void copyImageToClipboard(imageMenu.url).catch(showError);
            }}
          >
            复制图片
          </button>
        </div>
      )}
      {preview && (
        <div
          role="dialog"
          aria-label="图片预览"
          className="detached-chat__preview"
          onClick={() => setPreview(undefined)}
        >
          <button
            aria-label="关闭图片预览"
            onClick={() => setPreview(undefined)}
          >
            ×
          </button>
          <img src={preview} alt="图片预览" />
        </div>
      )}
    </main>
  );
}

const container = document.getElementById('conversation-root');
if (container) createRoot(container).render(<DetachedConversation />);
