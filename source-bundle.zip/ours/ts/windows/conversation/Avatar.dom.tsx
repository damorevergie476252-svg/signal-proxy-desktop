// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { useState } from 'react';
import type { JSX } from 'react';
import { getInitials } from '../../util/getInitials.std.ts';

export function ConversationAvatar({
  url,
  title,
  isGroup = false,
}: Readonly<{
  url?: string;
  title: string;
  isGroup?: boolean;
}>): JSX.Element {
  const [failedUrl, setFailedUrl] = useState<string>();
  return (
    <span
      className="detached-chat__avatar"
      role="img"
      aria-label={`${title}的头像`}
      data-avatar-kind={isGroup ? 'group' : 'direct'}
    >
      {url && failedUrl !== url ? (
        <img src={url} alt="" onError={() => setFailedUrl(url)} />
      ) : isGroup ? (
        <svg viewBox="0 0 32 32" aria-hidden="true">
          <circle cx="12" cy="12" r="5" />
          <circle cx="23" cy="13" r="4" />
          <path d="M2 29v-4c0-6 20-6 20 0v4zm22 0v-4c0-3-1-5-3-6 6-1 10 2 10 6v4z" />
        </svg>
      ) : (
        <span aria-hidden="true">{getInitials(title) ?? '•'}</span>
      )}
    </span>
  );
}
