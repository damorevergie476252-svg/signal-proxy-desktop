// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

export type DetachedFile = Readonly<{
  name: string;
  type: string;
  data: Uint8Array<ArrayBuffer>;
}>;

export type DetachedConversationCommand =
  | { type: 'snapshot' }
  | { type: 'older' }
  | {
      type: 'send';
      clientId: string;
      body: string;
      files: ReadonlyArray<DetachedFile>;
    }
  | {
      type: 'attachment';
      messageId: string;
      index: number;
      repairMissing?: boolean;
    }
  | { type: 'mark-read'; messageId: string };

export type DetachedMessage = Readonly<{
  id: string;
  sentAt: number;
  receivedAt: number;
  author: string;
  authorId?: string;
  authorAvatarUrl?: string;
  outgoing: boolean;
  system: boolean;
  body: string;
  status: string;
  attachments: ReadonlyArray<{
    name: string;
    contentType: string;
    url?: string;
    pending: boolean;
  }>;
}>;

export type DetachedConversationSnapshot = Readonly<{
  version: number;
  title: string;
  avatarUrl?: string;
  isGroup: boolean;
  canSend: boolean;
  hasMore: boolean;
  messages: ReadonlyArray<DetachedMessage>;
}>;

export type DetachedConversationAPI = Readonly<{
  request: (command: DetachedConversationCommand) => Promise<unknown>;
  subscribe: (
    listener: (snapshot: DetachedConversationSnapshot) => void
  ) => () => void;
}>;
