// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { repairMissingAvatarFiles } from '../util/repairMissingAvatarFiles.std.ts';
import { doesAttachmentExist } from '../util/migrations.preload.ts';
import { isConversationAccepted } from '../util/isConversationAccepted.preload.ts';
import { isBlocked } from '../util/isBlocked.preload.ts';
import {
  isGroupV2,
  isDirectConversation,
} from '../util/whatTypeOfConversation.dom.ts';
import { applyNewAvatar } from '../groups.preload.ts';
import { DataWriter } from '../sql/Client.preload.ts';
import { createLogger } from '../logging/log.std.ts';

const log = createLogger('avatarRepair');

// Run after authentication; process sequentially through the existing proxy/services.
export async function repairConversationAvatars(): Promise<void> {
  const conversations = window.ConversationController.getAll().filter(
    conversation =>
      !window.ConversationController.isSignalConversationId(conversation.id) &&
      isConversationAccepted(conversation.attributes) &&
      !isBlocked(conversation.attributes)
  );
  const result = await repairMissingAvatarFiles(
    conversations.map(conversation => ({
      getPaths: () =>
        [
          conversation.get('avatar')?.path,
          conversation.get('profileAvatar')?.path,
        ].filter((path): path is string => Boolean(path)),
      repair: async () => {
        if (isGroupV2(conversation.attributes)) {
          await conversation.queueJob('repairMissingAvatar', async () => {
            const avatar = conversation.get('avatar');
            const url = conversation.get('remoteAvatarUrl') ?? avatar?.url;
            if (
              !url ||
              (avatar?.path && (await doesAttachmentExist(avatar.path)))
            )
              return;
            const patch = await applyNewAvatar({
              newAvatarUrl: url,
              attributes: conversation.attributes,
              logId: 'repairMissingAvatar',
            });
            // Keep the previous reference if the download failed.
            if (
              patch.avatar?.path &&
              (await doesAttachmentExist(patch.avatar.path))
            ) {
              conversation.set(patch);
              await DataWriter.updateConversation(conversation.attributes);
            }
          });
        } else if (isDirectConversation(conversation.attributes)) {
          await conversation.getProfiles();
        }
      },
    })),
    doesAttachmentExist
  );
  log.info('Missing avatar repair complete', result);
}
