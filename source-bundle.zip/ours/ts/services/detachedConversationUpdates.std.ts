// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import type { UnknownAction } from 'redux';

const listeners = new Set<(action: UnknownAction) => void>();
const relevantActions = new Set([
  'MESSAGE_CHANGED',
  'MESSAGE_DELETED',
  'MESSAGES_ADDED',
  'CONVERSATIONS_UPDATED',
]);

export function notifyDetachedConversationChange(action: UnknownAction): void {
  if (relevantActions.has(action.type)) {
    for (const listener of listeners) {
      listener(action);
    }
  }
}

export function subscribeDetachedConversationChanges(
  listener: (action: UnknownAction) => void
): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
