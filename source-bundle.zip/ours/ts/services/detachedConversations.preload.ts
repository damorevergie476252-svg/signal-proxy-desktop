// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { ipcRenderer as ipc } from 'electron';
import { setTimeout, clearTimeout } from 'node:timers';
import { DataReader } from '../sql/Client.preload.ts';
import type { ReadonlyMessageAttributesType } from '../model-types.std.ts';
import type {
  DetachedConversationCommand,
  DetachedConversationSnapshot,
  DetachedMessage,
} from '../types/DetachedConversation.std.ts';
import { getLocalAttachmentUrl } from '../util/getLocalAttachmentUrl.std.ts';
import { getNotificationTextForMessage } from '../util/getNotificationTextForMessage.preload.ts';
import { getAuthorId } from '../messages/sources.preload.ts';
import { getMessageById } from '../messages/getMessageById.preload.ts';
import {
  readAttachmentData,
  doesAttachmentExist,
} from '../util/migrations.preload.ts';
import { isOpenableDocumentFileName } from '../util/isOpenableDocumentFileName.std.ts';
import { isConversationAccepted } from '../util/isConversationAccepted.preload.ts';
import { shouldShowInvalidMessageToast } from '../util/shouldShowInvalidMessageToast.preload.ts';
import { areWeAdmin } from '../util/areWeAdmin.preload.ts';
import { sendDetachedConversationMessage } from '../state/ducks/composer.preload.ts';
import { subscribeDetachedConversationChanges } from './detachedConversationUpdates.std.ts';
import { createLogger } from '../logging/log.std.ts';
import { strictAssert } from '../util/assert.std.ts';
import { getLocalAvatarUrl } from '../util/avatarUtils.preload.ts';

const log = createLogger('detachedConversations');
const PAGE_SIZE = 100;
const SEND_STATUS_LABELS: Readonly<Record<string, string>> = {
  Pending: '待发送',
  Sent: '已发送',
  Delivered: '已送达',
  Read: '已读',
  Viewed: '已查看',
  Failed: '发送失败',
  Skipped: '已跳过',
};
type Session = {
  id: string;
  version: number;
  hasMore: boolean;
  messages: Map<string, DetachedMessage>;
  deleted: Set<string>;
  active: boolean;
  timer?: ReturnType<typeof setTimeout>;
};

function projectMessage(
  attributes: ReadonlyMessageAttributesType
): DetachedMessage | undefined {
  if (
    attributes.storyId ||
    attributes.type === 'story' ||
    (attributes.expirationStartTimestamp &&
      attributes.expireTimer &&
      attributes.expirationStartTimestamp + attributes.expireTimer * 1000 <=
        Date.now())
  ) {
    return undefined;
  }
  const conversation = window.ConversationController.get(
    attributes.conversationId
  );
  strictAssert(conversation, 'Conversation missing');
  const accepted = isConversationAccepted(conversation.attributes);
  const hidden =
    attributes.isViewOnce || attributes.deletedForEveryone || !accepted;
  const authorId = getAuthorId(attributes);
  const author = authorId
    ? window.ConversationController.get(authorId)
    : undefined;
  return {
    id: attributes.id,
    sentAt: attributes.sent_at,
    receivedAt: attributes.received_at,
    author: author?.getTitle() ?? '',
    authorId,
    authorAvatarUrl: author ? getLocalAvatarUrl(author.attributes) : undefined,
    outgoing: attributes.type === 'outgoing',
    system: attributes.type !== 'incoming' && attributes.type !== 'outgoing',
    body: attributes.isViewOnce
      ? '一次性消息，请在主窗口查看'
      : attributes.deletedForEveryone
        ? '消息已删除'
        : getNotificationTextForMessage(attributes),
    status: attributes.errors?.length
      ? '发送失败，请在主窗口重试'
      : attributes.type === 'outgoing'
        ? [
            ...new Set(
              Object.values(attributes.sendStateByConversationId ?? {}).map(
                item => SEND_STATUS_LABELS[item.status] ?? item.status
              )
            ),
          ].join(' / ')
        : '',
    attachments: hidden
      ? []
      : (attributes.attachments ?? []).map(attachment => ({
          name: attachment.fileName ?? '附件',
          contentType: attachment.contentType ?? 'application/octet-stream',
          url: attachment.path ? getLocalAttachmentUrl(attachment) : undefined,
          pending: Boolean(attachment.pending),
        })),
  };
}

export function initializeDetachedConversations(): void {
  const sessions = new Map<string, Promise<Session>>();
  const sends = new Map<string, Promise<unknown>>();
  async function load(session: Session, older = false): Promise<void> {
    const first = older
      ? [...session.messages.values()].sort(
          (a, b) => a.receivedAt - b.receivedAt || a.sentAt - b.sentAt
        )[0]
      : undefined;
    const rows = await DataReader.getOlderMessagesByConversation({
      conversationId: session.id,
      includeStoryReplies: false,
      storyId: undefined,
      limit: PAGE_SIZE,
      ...(first
        ? {
            messageId: first.id,
            receivedAt: first.receivedAt,
            sentAt: first.sentAt,
          }
        : {}),
    });
    if (older || session.messages.size === 0)
      session.hasMore = rows.length === PAGE_SIZE;
    for (const row of rows) {
      const message = projectMessage(
        window.MessageCache.getById(row.id)?.attributes ?? row
      );
      if (message && !session.deleted.has(message.id))
        session.messages.set(message.id, message);
    }
  }
  async function getSession(id: string): Promise<Session> {
    let pending = sessions.get(id);
    if (!pending) {
      pending = (async () => {
        strictAssert(
          window.ConversationController.get(id),
          'Conversation missing'
        );
        const session: Session = {
          id,
          version: 0,
          hasMore: true,
          messages: new Map(),
          deleted: new Set(),
          active: true,
        };
        await load(session);
        return session;
      })();
      sessions.set(id, pending);
      void pending.catch(() => sessions.delete(id));
    }
    return pending;
  }
  function snapshot(session: Session): DetachedConversationSnapshot {
    const conversation = window.ConversationController.get(session.id);
    strictAssert(conversation, 'Conversation missing');
    return {
      version: ++session.version,
      title: conversation.getTitle(),
      avatarUrl: getLocalAvatarUrl(conversation.attributes),
      isGroup: conversation.get('type') === 'group',
      hasMore: session.hasMore,
      canSend:
        isConversationAccepted(conversation.attributes) &&
        !shouldShowInvalidMessageToast(conversation.attributes) &&
        !conversation.isGroupV1AndDisabled() &&
        !(
          conversation.get('announcementsOnly') &&
          !areWeAdmin(conversation.attributes)
        ),
      messages: [...session.messages.values()].sort(
        (a, b) => a.receivedAt - b.receivedAt || a.sentAt - b.sentAt
      ),
    };
  }
  function publish(session: Session): void {
    if (!session.active || session.timer) return;
    session.timer = setTimeout(() => {
      session.timer = undefined;
      if (session.active)
        ipc.send('conversation-window:update', session.id, snapshot(session));
    }, 100);
  }
  subscribeDetachedConversationChanges(action => {
    if (sessions.size === 0) return;
    const payload = action.payload as {
      conversationId?: string;
      id?: string;
      data?: ReadonlyMessageAttributesType | ReadonlyArray<{ id: string }>;
      messages?: ReadonlyArray<ReadonlyMessageAttributesType>;
    };
    for (const [id, pending] of sessions) {
      const affectsSession =
        action.type === 'CONVERSATIONS_UPDATED'
          ? Array.isArray(payload.data)
          : payload.conversationId === id;
      if (!affectsSession) continue;
      void pending
        .then(async session => {
          const changedConversations = new Set(
            Array.isArray(payload.data) ? payload.data.map(item => item.id) : []
          );
          if (
            action.type === 'CONVERSATIONS_UPDATED' &&
            !changedConversations.has(id) &&
            ![...session.messages.values()].some(
              message =>
                message.authorId && changedConversations.has(message.authorId)
            )
          )
            return;
          if (action.type === 'MESSAGE_DELETED' && payload.id) {
            session.messages.delete(payload.id);
            session.deleted.add(payload.id);
          }
          if (
            action.type === 'MESSAGE_CHANGED' &&
            payload.data &&
            !Array.isArray(payload.data)
          ) {
            const data = payload.data as ReadonlyMessageAttributesType;
            const message = projectMessage(data);
            if (session.messages.has(data.id)) {
              if (message) session.messages.set(data.id, message);
              else session.messages.delete(data.id);
            }
          }
          if (action.type === 'MESSAGES_ADDED') {
            for (const attributes of payload.messages ?? []) {
              const message = projectMessage(attributes);
              if (message && !session.deleted.has(message.id))
                session.messages.set(message.id, message);
            }
          }
          if (action.type === 'CONVERSATIONS_UPDATED') {
            for (const [messageId, message] of session.messages) {
              if (
                Array.isArray(payload.data) &&
                payload.data.some(item => item.id === message.authorId)
              ) {
                const author = message.authorId
                  ? window.ConversationController.get(message.authorId)
                  : undefined;
                session.messages.set(messageId, {
                  ...message,
                  author: author?.getTitle() ?? message.author,
                  authorAvatarUrl: author
                    ? getLocalAvatarUrl(author.attributes)
                    : undefined,
                });
              }
            }
            if (changedConversations.has(id)) await load(session);
          }
          publish(session);
        })
        .catch(error =>
          log.error('Could not update conversation window', error)
        );
    }
  });
  ipc.on('conversation-window:closed', (_event, id: string) => {
    const pending = sessions.get(id);
    sessions.delete(id);
    void pending?.then(
      session => {
        if (session.timer) clearTimeout(session.timer);
        session.active = false;
      },
      () => undefined
    );
  });
  async function handle(
    id: string,
    command: DetachedConversationCommand
  ): Promise<unknown> {
    const session = await getSession(id);
    if (command.type === 'snapshot') return snapshot(session);
    if (command.type === 'older') {
      await load(session, true);
      return snapshot(session);
    }
    if (command.type === 'send') {
      const key = `${id}:${command.clientId}`;
      let pending = sends.get(key);
      if (!pending) {
        pending = (async () => {
          const sent = await sendDetachedConversationMessage(
            id,
            command.body,
            command.files
          );
          if (!sent)
            throw new Error('尚未发送。请在主窗口确认提示；输入内容已保留。');
          const message = projectMessage(sent);
          if (message) session.messages.set(message.id, message);
          publish(session);
          return true;
        })();
        sends.set(key, pending);
        void pending.catch(() => sends.delete(key));
        if (sends.size > 256) sends.delete(sends.keys().next().value ?? '');
      }
      return pending;
    }
    const message = await getMessageById(command.messageId);
    strictAssert(
      message?.get('conversationId') === id,
      'Message does not belong to this conversation'
    );
    if (command.type === 'mark-read') {
      const conversation = window.ConversationController.get(id);
      if (conversation && isConversationAccepted(conversation.attributes)) {
        await conversation.markRead(message.attributes, {
          sendReadReceipts: true,
        });
      }
      return true;
    }
    strictAssert(
      !message.get('isViewOnce') && !message.get('deletedForEveryone'),
      'Attachment unavailable'
    );
    const conversation = window.ConversationController.get(id);
    strictAssert(
      conversation && isConversationAccepted(conversation.attributes),
      'Conversation not accepted'
    );
    const attachment = message.get('attachments')?.[command.index];
    strictAssert(attachment, 'Attachment missing');
    if (
      command.repairMissing ||
      !attachment.path ||
      !(await doesAttachmentExist(attachment.path))
    ) {
      window.reduxActions.conversations.kickOffAttachmentDownload({
        messageId: message.id,
        repairMissing: true,
      });
      return 'downloading';
    }
    if (isOpenableDocumentFileName(attachment.fileName)) {
      await ipc.invoke('open-document-attachment', {
        name: attachment.fileName,
        data: await readAttachmentData(attachment),
      });
    } else {
      window.IPC.showWindow();
      await window.reduxActions.conversations.saveAttachment(
        attachment,
        message.get('sent_at'),
        command.index
      );
    }
    return true;
  }
  ipc.on(
    'conversation-window:command',
    (
      _event,
      request: {
        requestId: string;
        conversationId: string;
        command: DetachedConversationCommand;
      }
    ) => {
      void handle(request.conversationId, request.command).then(
        value =>
          ipc.send('conversation-window:response', {
            requestId: request.requestId,
            value,
          }),
        error => {
          if (request.command.type === 'send') window.IPC.showWindow();
          ipc.send('conversation-window:response', {
            requestId: request.requestId,
            error: error instanceof Error ? error.message : '操作失败，请重试',
          });
        }
      );
    }
  );
}
