// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { clipboard, ClipboardItem, nativeImage } from 'electron';

export async function copyImage(data: Uint8Array<ArrayBuffer>): Promise<void> {
  if (!(data instanceof Uint8Array) || data.byteLength === 0) {
    throw new Error('Missing image data');
  }
  const image = nativeImage.createFromBuffer(Buffer.from(data));
  if (image.isEmpty()) {
    throw new Error('Invalid image data');
  }
  await clipboard.write([
    new ClipboardItem({
      'image/png': new Blob([new Uint8Array(image.toPNG())], {
        type: 'image/png',
      }),
    }),
  ]);
}
