// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { BrowserWindow, ipcMain } from 'electron';
import type { WebContents } from 'electron';
import { randomUUID } from 'node:crypto';
import { join } from 'node:path';
import z from 'zod';
import type { DetachedConversationSnapshot } from '../ts/types/DetachedConversation.std.ts';

const messageId = z.string().min(1).max(100);
const commandSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('snapshot') }),
  z.object({ type: z.literal('older') }),
  z.object({
    type: z.literal('send'),
    clientId: z.string().uuid(),
    body: z.string().max(65536),
    files: z
      .array(
        z.object({
          name: z.string().min(1).max(255),
          type: z.string().max(255),
          data: z.instanceof(Uint8Array),
        })
      )
      .max(32),
  }),
  z.object({
    type: z.literal('attachment'),
    messageId,
    index: z.number().int().min(0).max(31),
    repairMissing: z.boolean().optional(),
  }),
  z.object({ type: z.literal('mark-read'), messageId }),
]);

// The main renderer remains the only account/session and send-queue owner.
export class ConversationWindows {
  readonly #windows = new Map<string, BrowserWindow>();
  readonly #pending = new Map<
    string,
    {
      owner: WebContents;
      resolve: (value: unknown) => void;
      reject: (error: Error) => void;
      timer: ReturnType<typeof setTimeout>;
    }
  >();

  constructor(
    readonly options: {
      rootDir: string;
      getMainWindow: () => BrowserWindow | undefined;
      configureWindow: (window: BrowserWindow) => Promise<void>;
      assertUnlocked?: () => void;
    }
  ) {
    ipcMain.handle('open-conversation-window', async (event, id, title) => {
      this.#requireMain(event.sender);
      if (
        typeof id !== 'string' ||
        !/^[\w-]{1,100}$/.test(id) ||
        typeof title !== 'string'
      ) {
        throw new Error('Invalid conversation');
      }
      await this.open(id, title.slice(0, 200));
    });
    ipcMain.handle('conversation-window:request', (event, rawCommand) => {
      this.options.assertUnlocked?.();
      const binding = [...this.#windows].find(
        ([, window]) => window.webContents === event.sender
      );
      if (!binding) {
        throw new Error('Unknown conversation window');
      }
      const [conversationId, window] = binding;
      const command = commandSchema.parse(rawCommand);
      if (
        command.type === 'mark-read' &&
        (!window.isFocused() || window.isMinimized())
      ) {
        return false;
      }
      return new Promise((resolve, reject) => {
        const requestId = randomUUID();
        const timer = setTimeout(
          () => {
            this.#pending.delete(requestId);
            reject(new Error('主窗口响应超时，请先在主窗口确认会话状态。'));
          },
          5 * 60 * 1000
        );
        this.#pending.set(requestId, {
          owner: event.sender,
          resolve,
          reject,
          timer,
        });
        try {
          const main = this.options.getMainWindow();
          if (!main || main.isDestroyed()) {
            throw new Error('Main window unavailable');
          }
          main.webContents.send('conversation-window:command', {
            requestId,
            conversationId,
            command,
          });
        } catch (error) {
          clearTimeout(timer);
          this.#pending.delete(requestId);
          reject(error);
        }
      });
    });
    ipcMain.on('conversation-window:response', (event, result) => {
      if (event.sender !== this.options.getMainWindow()?.webContents) return;
      const pending = this.#pending.get(result?.requestId);
      if (!pending) {
        return;
      }
      clearTimeout(pending.timer);
      this.#pending.delete(result.requestId);
      if (result.error) {
        pending.reject(new Error(String(result.error)));
      } else {
        pending.resolve(result.value);
      }
    });
    ipcMain.on(
      'conversation-window:update',
      (event, id: string, snapshot: DetachedConversationSnapshot) => {
        if (event.sender !== this.options.getMainWindow()?.webContents) return;
        const window = this.#windows.get(id);
        if (window && !window.isDestroyed()) {
          window.setTitle(`${snapshot.title} - Signal Proxy`);
          window.webContents.send('conversation-window:update', snapshot);
        }
      }
    );
  }

  #requireMain(sender: WebContents): void {
    if (sender !== this.options.getMainWindow()?.webContents) {
      throw new Error('Only the main window may manage conversation windows');
    }
  }

  owns(contents: WebContents): boolean {
    return [...this.#windows.values()].some(
      window => window.webContents === contents
    );
  }

  async open(id: string, title: string): Promise<BrowserWindow> {
    this.options.assertUnlocked?.();
    const existing = this.#windows.get(id);
    if (existing && !existing.isDestroyed()) {
      if (existing.isMinimized()) existing.restore();
      existing.show();
      existing.focus();
      return existing;
    }
    const window = new BrowserWindow({
      width: 660,
      height: 780,
      minWidth: 400,
      minHeight: 440,
      show: false,
      autoHideMenuBar: true,
      title: `${title} - Signal Proxy`,
      webPreferences: {
        nodeIntegration: false,
        sandbox: true,
        contextIsolation: true,
        preload: join(this.options.rootDir, 'bundles/preload/conversation.js'),
      },
    });
    this.#windows.set(id, window);
    const contents = window.webContents;
    window.setMenu(null);
    window.on('closed', () => {
      this.#windows.delete(id);
      const main = this.options.getMainWindow();
      if (main && !main.isDestroyed())
        main.webContents.send('conversation-window:closed', id);
      for (const [requestId, pending] of this.#pending) {
        if (pending.owner === contents) {
          clearTimeout(pending.timer);
          pending.reject(new Error('Conversation window closed'));
          this.#pending.delete(requestId);
        }
      }
    });
    window.once('ready-to-show', () => window.show());
    try {
      await this.options.configureWindow(window);
      await window.loadFile(join(this.options.rootDir, 'conversation.html'));
    } catch (error) {
      window.destroy();
      throw error;
    }
    return window;
  }

  closeAll(): void {
    for (const window of [...this.#windows.values()]) {
      window.destroy();
    }
  }
}
