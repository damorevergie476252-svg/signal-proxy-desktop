// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { readFile, writeFile, rename } from 'node:fs/promises';
import { z } from 'zod';

const credentialSchema = z.object({
  salt: z.string().regex(/^[a-f0-9]{32}$/),
  hash: z.string().regex(/^[a-f0-9]{64}$/),
});
const recordSchema = z.object({
  version: z.literal(1),
  credential: credentialSchema.nullable(),
  failures: z.number().int().min(0).max(1000000),
  retryAt: z.number().finite().nonnegative(),
});
type RecordType = z.infer<typeof recordSchema>;

function derive(code: string, salt: string): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scrypt(
      code,
      Buffer.from(salt, 'hex'),
      32,
      { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 },
      (error, key) => {
        if (error) reject(error);
        else resolve(key);
      }
    );
  });
}

export class LocalLockStore {
  #record: RecordType = {
    version: 1,
    credential: null,
    failures: 0,
    retryAt: 0,
  };
  #broken = false;
  #busy = false;

  constructor(
    readonly file: string,
    readonly now: () => number = Date.now
  ) {}

  get enabled(): boolean {
    return this.#broken || this.#record.credential !== null;
  }
  get broken(): boolean {
    return this.#broken;
  }
  get retryAfter(): number {
    return Math.max(0, Math.ceil((this.#record.retryAt - this.now()) / 1000));
  }

  async load(): Promise<void> {
    try {
      this.#record = recordSchema.parse(
        JSON.parse(await readFile(this.file, 'utf8'))
      );
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT')
        this.#broken = true;
    }
  }

  async #save(record: RecordType): Promise<void> {
    const temporary = `${this.file}.${randomBytes(8).toString('hex')}.tmp`;
    await writeFile(temporary, JSON.stringify(record), {
      mode: 0o600,
      flag: 'wx',
    });
    await rename(temporary, this.file);
    this.#record = record;
  }

  async #verify(code: string): Promise<boolean> {
    const credential = this.#record.credential;
    if (!credential || typeof code !== 'string' || code.length > 128)
      return false;
    if (this.retryAfter)
      throw new Error(`请等待 ${this.retryAfter} 秒后重试。`);
    const key = await derive(code, credential.salt);
    const valid = timingSafeEqual(key, Buffer.from(credential.hash, 'hex'));
    key.fill(0);
    const failures = valid ? 0 : Math.min(this.#record.failures + 1, 1000000);
    await this.#save({
      ...this.#record,
      failures,
      retryAt: valid
        ? 0
        : this.now() +
          (failures < 5
            ? 1000
            : Math.min(300000, 30000 * 2 ** Math.min(failures - 5, 4))),
    });
    return valid;
  }

  async #exclusive<T>(action: () => Promise<T>): Promise<T> {
    if (this.#broken)
      throw new Error(
        '本机锁定配置无法读取，请恢复该配置的备份后重试。聊天资料未被重置。'
      );
    if (this.#busy) throw new Error('正在验证，请稍候。');
    this.#busy = true;
    try {
      return await action();
    } finally {
      this.#busy = false;
    }
  }

  verify(code: string): Promise<boolean> {
    return this.#exclusive(() => this.#verify(code));
  }

  configure(
    oldCode: string,
    newCode: string | null,
    canCommit: () => boolean = () => true
  ): Promise<void> {
    return this.#exclusive(async () => {
      if (
        newCode !== null &&
        (typeof newCode !== 'string' ||
          newCode.length < 6 ||
          newCode.length > 128)
      )
        throw new Error('锁定码需为 6–128 个字符，可使用数字或文字。');
      if (this.enabled && !(await this.#verify(oldCode)))
        throw new Error('原锁定码不正确。');
      const salt = randomBytes(16).toString('hex');
      const key = newCode === null ? undefined : await derive(newCode, salt);
      try {
        if (!canCommit()) throw new Error('电脑已锁定，请解锁后重新设置。');
        const previous = this.#record;
        await this.#save({
          version: 1,
          credential: key ? { salt, hash: key.toString('hex') } : null,
          failures: 0,
          retryAt: 0,
        });
        if (!canCommit()) {
          try {
            await this.#save(previous);
          } catch {
            this.#broken = true;
          }
          throw new Error('电脑已锁定，设置未完成，请解锁后重试。');
        }
      } finally {
        key?.fill(0);
      }
    });
  }
}
