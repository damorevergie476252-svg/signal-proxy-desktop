// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import type { Notification, NotificationConstructorOptions } from 'electron';
import type { WindowsNotificationData } from '../ts/services/notifications.preload.ts';
import { renderWindowsToast } from './renderWindowsToast.std.tsx';

// Keep activation inside this process; sgnl:// belongs to the original Signal.
export class LocalWindowsNotifications {
  #current?: {
    notification: Notification;
    data: WindowsNotificationData;
  };
  constructor(
    readonly options: {
      create: (options: NotificationConstructorOptions) => Notification;
      activate: (data: WindowsNotificationData) => void;
      failed: (error: string) => void;
    }
  ) {}

  show(data: WindowsNotificationData): void {
    this.clear();
    const captured = { ...data, target: data.target && { ...data.target } };
    const notification = this.options.create({
      title: data.heading,
      body: data.body,
      toastXml: renderWindowsToast(data, 'foreground'),
    });
    this.#current = { notification, data: captured };
    notification.once('click', () => {
      if (this.#current?.notification !== notification) return;
      this.activate(captured.token);
    });
    notification.on('failed', (_event, error) => this.options.failed(error));
    notification.show();
  }

  // Action Center uses Electron's global activation handler for custom toast XML.
  // Match only the current opaque token; never interpret activation text as a URL.
  activate(token: string): boolean {
    const current = this.#current;
    if (!current || current.data.token !== token) return false;
    this.clear();
    this.options.activate(current.data);
    return true;
  }

  clear(): void {
    const previous = this.#current;
    this.#current = undefined;
    previous?.notification.close();
  }
}
