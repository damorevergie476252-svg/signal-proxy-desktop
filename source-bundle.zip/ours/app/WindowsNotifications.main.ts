// Copyright 2017 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only

import { ipcMain as ipc, Notification } from 'electron';
import type { BrowserWindow, IpcMainInvokeEvent } from 'electron';

import {
  Notifier,
  sendDummyKeystroke,
} from '@indutny/simple-windows-notifications';

import { createLogger } from '../ts/logging/log.std.ts';
import { AUMID } from './startup_config.main.ts';
import type { WindowsNotificationData } from '../ts/services/notifications.preload.ts';
import OS from '../ts/util/os/osMain.node.ts';
import { renderWindowsToast } from './renderWindowsToast.std.tsx';
import { LocalWindowsNotifications } from './localWindowsNotifications.main.ts';
import { packageJson } from '../ts/util/packageJson.main.ts';
import { NotificationType } from '../ts/types/notifications.std.ts';
import type { LocalLock } from './local_lock.main.ts';

export { sendDummyKeystroke };

const log = createLogger('WindowsNotifications');

export function initializeWindowsNotifications(options: {
  getMainWindow: () => BrowserWindow | undefined;
  showWindow: () => void;
  localLock?: Pick<LocalLock, 'isLocked' | 'showUnlock'>;
}): (() => void) | undefined {
  if (!OS.isWindows()) return;
  const local =
    packageJson.name === 'signal-desktop-proxy'
      ? new LocalWindowsNotifications({
          create: data => new Notification(data),
          activate: data => {
            if (options.localLock?.isLocked()) {
              options.localLock.showUnlock(() => activate(data));
              return;
            }
            activate(data);
          },
          failed: error =>
            log.error('Local Windows notification failed', error),
        })
      : undefined;
  function activate(data: WindowsNotificationData): void {
    const window = options.getMainWindow();
    if (!window || window.isDestroyed()) return;
    if (data.type !== NotificationType.IsPresenting) {
      sendDummyKeystroke();
      if (window.isMinimized()) window.restore();
      options.showWindow();
      window.focus();
    }
    window.webContents.send('windows-notifications:activate', data);
    log.info('Notification click delivered to Signal Proxy');
  }
  const notifier = local ? undefined : new Notifier(AUMID);
  if (local) {
    Notification.handleActivation(details => {
      if (details.type !== 'click') return;
      log.info('Windows notification activation received', {
        matched: local.activate(details.arguments),
      });
    });
    // Discard toasts issued by older proxy builds with the wrong activation route.
    try {
      new Notifier('org.whispersystems.signal-desktop-proxy').clearAll();
    } catch (error) {
      log.warn('Could not clear obsolete proxy notifications', error);
    }
  }

  const NOTIFICATION_ID = {
    group: 'group',
    tag: 'tag',
  };

  ipc.handle(
    'windows-notifications:show',
    (event: IpcMainInvokeEvent, data: WindowsNotificationData) => {
      if (event.sender !== options.getMainWindow()?.webContents)
        throw new Error('Only the main window may show notifications');
      try {
        // First, clear all previous notifications - we want just one
        // notification at a time
        if (local)
          local.show(
            options.localLock?.isLocked()
              ? {
                  ...data,
                  heading: 'Signal Proxy 已锁定',
                  body: '解锁后查看新消息',
                  avatarPath: undefined,
                }
              : data
          );
        else {
          notifier?.remove(NOTIFICATION_ID);
          notifier?.show(renderWindowsToast(data), NOTIFICATION_ID);
        }
      } catch (error) {
        log.error(
          `Windows Notifications: Failed to show notification: ${error.stack}`
        );
      }
    }
  );

  ipc.handle('windows-notifications:clear-all', event => {
    if (event.sender !== options.getMainWindow()?.webContents)
      throw new Error('Only the main window may clear notifications');
    try {
      local?.clear();
      notifier?.remove(NOTIFICATION_ID);
    } catch (error) {
      log.error(
        `Windows Notifications: Failed to clear notifications: ${error.stack}`
      );
    }
  });
  return () => {
    local?.clear();
    notifier?.remove(NOTIFICATION_ID);
  };
}
