// Copyright 2026 Local contributors
// SPDX-License-Identifier: AGPL-3.0-only

import { app, BrowserWindow, ipcMain, powerMonitor } from 'electron';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { LocalLockStore } from './local_lock_store.node.ts';

export class LocalLock {
  readonly #store: LocalLockStore;
  #locked = false;
  #panel?: BrowserWindow;
  #mode: 'unlock' | 'settings' = 'unlock';
  #visible = new Set<BrowserWindow>();
  #afterUnlock?: () => void;
  #lastUnlock = Date.now();
  #epoch = 0;
  #quitting = false;
  #clearNotifications?: () => void;

  constructor(
    readonly options: {
      rootDir: string;
      getMainWindow: () => BrowserWindow | undefined;
    }
  ) {
    this.#store = new LocalLockStore(
      join(app.getPath('userData'), 'local-lock.json')
    );
    app.on('browser-window-created', (_event, window) => this.#guard(window));
    app.on('before-quit', () => {
      this.#quitting = true;
    });
    ipcMain.handle('local-lock:status', event => {
      this.#requirePanel(event);
      return this.status();
    });
    ipcMain.handle('local-lock:submit', async (event, raw: unknown) => {
      this.#requirePanel(event);
      if (!raw || typeof raw !== 'object') return { error: '无效的请求。' };
      const value = raw as {
        action?: unknown;
        code?: unknown;
        newCode?: unknown;
      };
      try {
        if (typeof value.code !== 'string' || value.code.length > 128)
          throw new Error('请输入锁定码。');
        if (value.action === 'unlock' && this.#locked) {
          const epoch = this.#epoch;
          if (!(await this.#store.verify(value.code)))
            throw new Error('锁定码不正确。');
          if (epoch !== this.#epoch)
            throw new Error('电脑已再次锁定，请重新输入锁定码。');
          this.#locked = false;
          this.#lastUnlock = Date.now();
          this.#closePanel();
          for (const window of this.#visible)
            if (!window.isDestroyed()) window.show();
          this.#visible.clear();
          this.options.getMainWindow()?.show();
          this.#afterUnlock?.();
          this.#afterUnlock = undefined;
          return {};
        }
        if (
          value.action === 'configure' &&
          !this.#locked &&
          this.#mode === 'settings'
        ) {
          if (value.newCode !== null && typeof value.newCode !== 'string')
            throw new Error('无效的锁定码。');
          const epoch = this.#epoch;
          await this.#store.configure(
            value.code,
            value.newCode,
            () => !this.#locked && epoch === this.#epoch
          );
          return { saved: true, ...this.status() };
        }
        throw new Error('请先解锁。');
      } catch (error) {
        return {
          error:
            error instanceof Error ? error.message : '操作未完成，请重试。',
        };
      }
    });
  }

  status(): {
    enabled: boolean;
    locked: boolean;
    broken: boolean;
    mode: string;
    retryAfter: number;
  } {
    return {
      enabled: this.#store.enabled,
      locked: this.#locked,
      broken: this.#store.broken,
      mode: this.#mode,
      retryAfter: this.#store.retryAfter,
    };
  }

  isLocked(): boolean {
    return this.#locked;
  }
  assertUnlocked(): void {
    if (this.#locked) throw new Error('Signal Proxy 已锁定。');
  }
  setNotificationCleaner(clear: () => void): void {
    this.#clearNotifications = clear;
  }

  async initialize(): Promise<void> {
    await this.#store.load();
    this.#locked = this.#store.enabled;
    powerMonitor.on('lock-screen', () => this.lock(false));
    powerMonitor.on('suspend', () => this.lock(false));
    powerMonitor.on('unlock-screen', () => {
      if (this.#locked) this.showUnlock();
    });
    const timer = setInterval(() => {
      if (
        this.#store.enabled &&
        !this.#locked &&
        Date.now() - this.#lastUnlock >= 300000 &&
        powerMonitor.getSystemIdleTime() >= 300
      )
        this.lock(false);
    }, 5000);
    timer.unref();
    app.once('will-quit', () => clearInterval(timer));
  }

  lock(show = true): void {
    this.#epoch += 1;
    if (!this.#store.enabled) {
      if (show) this.showSettings();
      return;
    }
    this.#locked = true;
    this.#afterUnlock = undefined;
    for (const window of BrowserWindow.getAllWindows()) {
      if (window === this.#panel) continue;
      if (window.isVisible()) this.#visible.add(window);
      window.webContents.closeDevTools();
      window.hide();
    }
    this.#clearNotifications?.();
    this.#closePanel();
    if (show) this.showUnlock();
  }

  showUnlock(afterUnlock?: () => void): void {
    if (!this.#locked) {
      afterUnlock?.();
      return;
    }
    if (afterUnlock) this.#afterUnlock = afterUnlock;
    this.#show('unlock');
  }

  showSettings(): void {
    if (this.#locked) {
      this.showUnlock(() => this.showSettings());
      return;
    }
    this.#show('settings');
  }

  #requirePanel(event: Electron.IpcMainInvokeEvent): void {
    if (
      !this.#panel ||
      event.sender !== this.#panel.webContents ||
      event.senderFrame !== this.#panel.webContents.mainFrame ||
      event.senderFrame.url !==
        pathToFileURL(join(this.options.rootDir, 'local-lock.html')).href
    )
      throw new Error('Only the local lock panel may change the lock');
  }

  #closePanel(): void {
    // close() completes asynchronously; detach before opening the next panel.
    const previous = this.#panel;
    this.#panel = undefined;
    if (previous && !previous.isDestroyed()) previous.destroy();
  }

  #show(mode: 'unlock' | 'settings'): void {
    if (this.#quitting) return;
    if (this.#panel && !this.#panel.isDestroyed()) {
      this.#panel.show();
      this.#panel.focus();
      return;
    }
    this.#mode = mode;
    const window = new BrowserWindow({
      width: 440,
      height: mode === 'settings' ? 700 : 500,
      resizable: false,
      show: false,
      autoHideMenuBar: true,
      title: 'Signal Proxy · 本机锁定',
      backgroundColor: '#181b20',
      webPreferences: {
        sandbox: true,
        contextIsolation: true,
        nodeIntegration: false,
        devTools: false,
        preload: join(this.options.rootDir, 'bundles/preload/local-lock.js'),
      },
    });
    this.#panel = window;
    window.setMenu(null);
    window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    window.webContents.on('will-navigate', event => event.preventDefault());
    window.once('closed', () => {
      if (this.#panel === window) this.#panel = undefined;
    });
    window.once('ready-to-show', () => {
      window.show();
      window.focus();
    });
    void window.loadFile(join(this.options.rootDir, 'local-lock.html'));
  }

  #guard(window: BrowserWindow): void {
    for (const method of [
      'show',
      'showInactive',
      'focus',
      'restore',
    ] as const) {
      const original = window[method].bind(window);
      window[method] = () => {
        if (window !== this.#panel && this.#locked) {
          this.showUnlock();
          return;
        }
        original();
      };
    }
    window.webContents.on('before-input-event', (event, input) => {
      if (window === this.#panel) return;
      if (input.control && input.shift && input.key.toLowerCase() === 'l') {
        event.preventDefault();
        this.lock();
      } else if (this.#locked) event.preventDefault();
    });
    window.on('show', () => {
      if (window !== this.#panel && this.#locked) window.hide();
    });
  }
}
