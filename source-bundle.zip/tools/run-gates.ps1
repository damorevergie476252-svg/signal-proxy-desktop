param([Parameter(Mandatory=$true)][string]$Project)
$ErrorActionPreference='Stop'
$projectPath=(Resolve-Path -LiteralPath $Project).Path
$rootPath=Split-Path $PSScriptRoot -Parent
function Invoke-Checked([string]$Executable,[string[]]$Arguments) {
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Verification command failed: $Executable $($Arguments -join ' ')" }
}
Push-Location $projectPath
try {
    Invoke-Checked 'pnpm' @('run','check:types')
    Invoke-Checked 'node' @('--import=./scripts/browser-timers-test-environment.mjs','--import=tsx','--test','scripts/test-signal-tls-proxy.mjs','scripts/test-signal-provisioning-timeout.mjs','scripts/test-signal-document-open.mjs','scripts/test-avatar-files.mjs','scripts/test-missing-images.mjs','scripts/test-windows-notifications.mjs','scripts/test-stream-document-write.mjs')
    Invoke-Checked 'node' @('--import=tsx','--test','scripts/test-proxy-updates.mjs')
} finally { Pop-Location }
Push-Location $rootPath
try {
    foreach ($name in @('local-lock','notification','conversation-window','startup')) {
        Invoke-Checked 'node' @("build-tools/prepare-$name-test.cjs")
    }
    Invoke-Checked 'node' @('--test','build-tools/test-local-lock.cjs','build-tools/test-notification-flow.cjs','build-tools/test-conversation-send.cjs')
} finally { Pop-Location }
