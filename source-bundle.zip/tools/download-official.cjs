const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const { createHash } = require('node:crypto');
const { pipeline } = require('node:stream/promises');
const { Readable } = require('node:stream');
const project = path.resolve(process.argv[2]);
const version = process.argv[3];
const output = path.resolve(process.argv[4]);
if (!/^\d+\.\d+\.\d+$/.test(version)) throw new Error('Not a stable version');
const requireFromProject = createRequire(path.join(project, 'package.json'));
const { load, FAILSAFE_SCHEMA } = requireFromProject('js-yaml');
async function fetchChecked(url) { const response = await fetch(url); if (!response.ok) throw new Error(`Download failed: ${response.status}`); return response; }
(async () => {
  const metadata = load(await (await fetchChecked('https://updates2.signal.org/desktop/latest.yml')).text(), { schema: FAILSAFE_SCHEMA });
  if (metadata.version !== version) throw new Error('Official source and Windows release are not yet aligned; retry later');
  const files = metadata.files.filter(file => /^[A-Za-z0-9._-]+$/.test(file.url) && file.url.includes('x64') && file.url.endsWith('.exe'));
  if (files.length !== 1) throw new Error('Official x64 installer selection requires review');
  const file = files[0];
  fs.mkdirSync(path.dirname(output), { recursive: true });
  await pipeline(Readable.fromWeb((await fetchChecked('https://updates2.signal.org/desktop/' + file.url)).body), fs.createWriteStream(output));
  const hash = createHash('sha512');
  await pipeline(fs.createReadStream(output), hash);
  if (hash.digest('base64') !== file.sha512) throw new Error('Official installer hash mismatch');
  fs.writeFileSync(output + '.json', JSON.stringify({ version, fileName: file.url, sha512: file.sha512 }, null, 2));
  console.log('Verified the official Windows installer checksum.');
})().catch(error => { console.error(error); process.exitCode = 1; });
