const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const { createHash } = require('node:crypto');
const { pipeline } = require('node:stream/promises');
const project = path.resolve(process.argv[2]);
const version = process.argv[3];
const output = path.resolve(process.argv[4]);
if (!/^\d+\.\d+\.\d+$/.test(version)) throw new Error('Not a stable version');
const requireFromProject = createRequire(path.join(project, 'package.json'));
const { load, FAILSAFE_SCHEMA } = requireFromProject('js-yaml');
const got = requireFromProject('got').default;
// The official update host uses Signal's own CA. Do not use GitHub's public
// update transport here, and never disable TLS certificate verification.
const certificateAuthority = JSON.parse(fs.readFileSync(path.join(project, 'config/default.json'), 'utf8')).certificateAuthority;
const options = { https: { certificateAuthority }, retry: { limit: 3 }, timeout: { request: 120000 } };
(async () => {
  const metadata = load(await got('https://updates2.signal.org/desktop/latest.yml', options).text(), { schema: FAILSAFE_SCHEMA });
  if (metadata.version !== version) throw new Error('Official source and Windows release are not yet aligned; retry later');
  const files = metadata.files.filter(file => /^[A-Za-z0-9._-]+$/.test(file.url) && file.url.includes('x64') && file.url.endsWith('.exe'));
  if (files.length !== 1) throw new Error('Official x64 installer selection requires review');
  const file = files[0];
  fs.mkdirSync(path.dirname(output), { recursive: true });
  await pipeline(got.stream('https://updates2.signal.org/desktop/' + file.url, options), fs.createWriteStream(output));
  const hash = createHash('sha512');
  await pipeline(fs.createReadStream(output), hash);
  if (hash.digest('base64') !== file.sha512) throw new Error('Official installer hash mismatch');
  fs.writeFileSync(output + '.json', JSON.stringify({ version, fileName: file.url, sha512: file.sha512 }, null, 2));
  console.log('Verified the official Windows installer checksum.');
})().catch(error => { console.error(error); process.exitCode = 1; });
