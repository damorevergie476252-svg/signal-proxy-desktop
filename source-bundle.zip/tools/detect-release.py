from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import json
import os
import re


def fetch(repository):
    headers = {'Accept': 'application/vnd.github+json', 'User-Agent': 'signal-proxy-release-check'}
    if os.environ.get('GH_TOKEN'):
        headers['Authorization'] = 'Bearer ' + os.environ['GH_TOKEN']
    try:
        with urlopen(Request(f'https://api.github.com/repos/{repository}/releases/latest', headers=headers), timeout=45) as response:
            return json.load(response)
    except HTTPError as error:
        if error.code == 404 and repository == os.environ['GITHUB_REPOSITORY']:
            return None
        raise


official = fetch('signalapp/Signal-Desktop')
tag = official['tag_name']
if official['draft'] or official['prerelease'] or not re.fullmatch(r'v\d+\.\d+\.\d+', tag):
    raise ValueError('Expected an official stable release')
current = fetch(os.environ['GITHUB_REPOSITORY'])
already_built = bool(current and current['tag_name'].startswith('proxy-' + tag + '-adhoc.'))
needed = not already_built or os.environ.get('FORCE_BUILD', '').lower() == 'true'
with Path(os.environ['GITHUB_OUTPUT']).open('a', encoding='utf8') as stream:
    stream.write(f'tag={tag}\nversion={tag[1:]}\nneeded={str(needed).lower()}\n')
print(json.dumps({'officialVersion': tag[1:], 'buildNeeded': needed}))
