const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const project = path.resolve(process.argv[2]);
const official = path.resolve(process.argv[3]);
const expected = process.argv[4];
const requireFromProject = createRequire(path.join(project, 'package.json'));
const asar = requireFromProject('@electron/asar');
const archive = path.join(official, 'resources/app.asar');
const rawNames = new Map(asar.listPackage(archive).map(name => [name.slice(1).replaceAll('\\', '/'), name.slice(1)]));
const read = name => { if (!rawNames.has(name)) throw new Error('Official archive member missing: ' + name); return asar.extractFile(archive, rawNames.get(name)); };
if (JSON.parse(read('package.json')).version !== expected) throw new Error('Extracted installer version does not match the source');
const records = [];
for (const [name] of rawNames) {
  if (!name.startsWith('node_modules/') || !name.endsWith('.node')) continue;
  const parts = name.slice('node_modules/'.length).split('/');
  const moduleName = parts[0].startsWith('@') ? parts.slice(0, 2).join('/') : parts[0];
  const prefix = 'node_modules/' + moduleName + '/';
  const shipped = JSON.parse(read(prefix + 'package.json'));
  const targetRoot = fs.realpathSync(path.join(project, 'node_modules', moduleName));
  if (!targetRoot.startsWith(project + path.sep)) throw new Error('Native target is outside the isolated source tree');
  if (JSON.parse(fs.readFileSync(path.join(targetRoot, 'package.json'))).version !== shipped.version) throw new Error('Native dependency version mismatch: ' + moduleName);
  const target = path.resolve(targetRoot, name.slice(prefix.length));
  if (!target.startsWith(targetRoot + path.sep)) throw new Error('Unsafe native member');
  const data = read(name);
  fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, data);
  records.push({ name, version: shipped.version, sha256: crypto.createHash('sha256').update(data).digest('hex') });
}
for (const name of ['@signalapp/libsignal-client', '@signalapp/ringrtc', '@signalapp/sqlcipher', '@signalapp/windows-ucv', '@indutny/simple-windows-notifications']) {
  if (!records.some(row => row.name.startsWith('node_modules/' + name + '/'))) throw new Error('Required official native component missing: ' + name);
}
for (const [name] of rawNames) {
  if (name.startsWith('sticker-creator/dist/') && !name.endsWith('/')) {
    const target = path.resolve(project, name);
    if (!target.startsWith(project + path.sep)) throw new Error('Unsafe sticker asset');
    // Directory entries have no file bytes; the archive distinguishes them here.
    const stat = asar.statFile(archive, rawNames.get(name));
    if (stat.files) continue;
    fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, read(name));
  }
}
fs.mkdirSync(path.join(__dirname, '../work'), { recursive: true });
fs.writeFileSync(path.join(__dirname, '../work/native-components.json'), JSON.stringify(records, null, 2));
console.log(`Reused ${records.length} unchanged official native components with exact version checks.`);
