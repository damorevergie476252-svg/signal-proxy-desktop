const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const project = path.resolve(process.argv[2]);
const root = path.resolve(__dirname, '..');
// Upstream builder hooks resolve relative imports from the process directory.
process.chdir(project);
process.env.SIGNAL_ENV = 'production';
process.env.NODE_ENV = 'production';
const smoke = process.argv.includes('--smoke');
const requireFromProject = createRequire(path.join(project, 'package.json'));
const { build, Platform, Arch } = requireFromProject('electron-builder');
const packageJson = JSON.parse(fs.readFileSync(path.join(project, 'package.json')));
if (!/^\d+\.\d+\.\d+-adhoc\.\d{8}\.r\.\d+\.sgpx$/.test(packageJson.version)) throw new Error('Unexpected custom version');
const [core] = packageJson.version.split('-');
const suffix = packageJson.version.slice(core.length + 1);
const configPath = path.join(project, 'config/local-production.json');
const savedConfig = fs.readFileSync(configPath);
const config = JSON.parse(savedConfig);
if (!config.updatesEnabled || config.storageProfile !== 'Proxy-SGPX' || config.storagePath) throw new Error('Release configuration must have the custom updater and no test profile');
if (smoke) {
  const requestedProfile = process.argv.find(arg => arg.startsWith('--profile='))?.slice('--profile='.length) ?? 'smoke/profile';
  const profile = path.resolve(root, requestedProfile);
  if (!profile.startsWith(root + path.sep)) throw new Error('Test profile must stay inside the release workspace');
  config.storagePath = profile;
  fs.writeFileSync(configPath, JSON.stringify(config));
}
build({
  projectDir: project, publish: 'never',
  targets: Platform.WINDOWS.createTarget(smoke ? ['dir'] : ['nsis', 'portable'], Arch.x64),
  config: {
    directories: { output: path.join(root, smoke ? 'smoke/dist' : 'dist-proxy-fix17') },
    electronDist: path.join(project, 'node_modules/electron/dist'),
    npmRebuild: false, forceCodeSigning: false,
    extraMetadata: { environment: 'production' },
    publish: null, protocols: [], afterSign: null, afterAllArtifactBuild: null, artifactBuildCompleted: null,
    win: { artifactName: `Signal-Proxy-${core}-x64-Setup-${suffix}.` + '${ext}' },
    nsis: { oneClick: false, perMachine: false, allowToChangeInstallationDirectory: true, deleteAppDataOnUninstall: false, shortcutName: 'Signal Proxy' },
    portable: { artifactName: `Signal-Proxy-${core}-x64-Portable-${suffix}.` + '${ext}', requestExecutionLevel: 'user' },
  },
}).then(files => console.log(JSON.stringify(files)))
  .catch(error => { console.error(error); process.exitCode = 1; })
  .finally(() => { if (smoke) fs.writeFileSync(configPath, savedConfig); });
