from pathlib import Path, PurePosixPath
import json
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent.parent
project = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / 'Signal-Desktop-8.36.0-with-proxy'
manifest = json.loads((root / 'overlay.json').read_text(encoding='utf8'))
package = json.loads((project / 'package.json').read_text(encoding='utf8'))
if len(sys.argv) > 2:
    with zipfile.ZipFile(sys.argv[2]) as original:
        prefix = 'Signal-Desktop-' + package['version'].split('-')[0] + '/'
        names = {name[len(prefix):] for name in original.namelist() if name.startswith(prefix) and not name.endswith('/')}
else:
    names = set(subprocess.check_output(['git', '-C', str(root / 'upstream'), 'ls-files', '-z']).decode('utf8').split('\0')) - {''}
names.update(row['path'] for row in manifest['files'])
names.add('config/local-production.json')
if (project / '.npmrc').is_file():
    names.add('.npmrc')
output = root / 'dist-proxy-fix17' / f"Signal-Proxy-{package['version']}-source.zip"
with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name in sorted(names):
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or '\\' in name:
            raise ValueError('Unsafe source member')
        path = project.joinpath(*relative.parts)
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(project.resolve()):
            raise ValueError('Missing or unsafe source member: ' + name)
        archive.write(path, 'source/' + name)
    for folder in ['tools','build-tools','signer','vendor']:
        for path in sorted((root / folder).rglob('*')):
            if path.is_file() and 'node_modules' not in path.parts:
                archive.write(path, 'release-kit/' + path.relative_to(root).as_posix())
    for name in ['README.md','LICENSE','channel.json','overlay.json','prepare-source.py','.github/workflows/release.yml']:
        archive.write(root / name, 'release-kit/' + name)
print(json.dumps({'sourceArchive': output.name, 'sourceFiles': len(names)}))
