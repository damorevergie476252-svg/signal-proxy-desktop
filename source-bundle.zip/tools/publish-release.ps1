param([Parameter(Mandatory=$true)][string]$Artifacts)
$ErrorActionPreference='Stop'
$artifactPath=(Resolve-Path -LiteralPath $Artifacts).Path
$report=Get-Content -LiteralPath (Join-Path $artifactPath 'build-verification.json') -Raw | ConvertFrom-Json
$tag='proxy-v'+$report.version
$assets=@(Get-ChildItem -LiteralPath $artifactPath -File | Where-Object { $_.Extension -in @('.exe','.sig','.zip','.yml','.json','.blockmap') -or $_.Name -eq 'SHA256SUMS.txt' } | ForEach-Object { $_.FullName })
& gh release create $tag @assets --draft --target $env:RELEASE_COMMIT --title ('Signal Proxy '+$report.version) --notes-file (Join-Path $artifactPath 'release-notes.md')
if ($LASTEXITCODE -ne 0) { throw 'Draft release creation or asset upload failed; no release will be promoted' }
$remote=& gh release view $tag --json assets
if ($LASTEXITCODE -ne 0) { throw 'Unable to verify release assets' }
$remoteNames=@(($remote | ConvertFrom-Json).assets | ForEach-Object { $_.name })
foreach ($asset in $assets) { if ((Split-Path $asset -Leaf) -notin $remoteNames) { throw 'A release asset is missing' } }
& gh release edit $tag --draft=false --latest
if ($LASTEXITCODE -ne 0) { throw 'Unable to publish the fully uploaded release' }
Write-Output ('Published '+$tag)
