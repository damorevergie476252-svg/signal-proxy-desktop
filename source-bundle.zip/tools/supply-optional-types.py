from pathlib import Path, PurePosixPath
import hashlib
import json
import sys
import tarfile

root = Path(__file__).resolve().parent.parent
project = Path(sys.argv[1]).resolve()
target = project / 'node_modules/fs-xattr'
if not target.exists():
    archive = root / 'vendor/fs-xattr-0.4.0.tgz'
    expected = json.loads((root / 'vendor/checksums.json').read_text(encoding='utf8'))[archive.name]
    if hashlib.sha256(archive.read_bytes()).hexdigest() != expected:
        raise ValueError('Optional type package integrity mismatch')
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            name = PurePosixPath(member.name)
            if name.parts[0] != 'package' or name.is_absolute() or '..' in name.parts:
                raise ValueError('Unsafe optional type package member')
            if member.isfile():
                output = target.joinpath(*name.parts[1:])
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_bytes(stream.extractfile(member).read())
if json.loads((target / 'package.json').read_text(encoding='utf8'))['version'] != '0.4.0':
    raise ValueError('Optional type dependency changed and needs review')
