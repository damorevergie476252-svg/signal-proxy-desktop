from pathlib import Path
import json
import os
import re
import subprocess

source = Path('upstream')
package = json.loads((source / 'package.json').read_text(encoding='utf8'))
if package['version'] != os.environ['OFFICIAL_VERSION']:
    raise ValueError('Checkout does not match the selected stable release')
node = package['engines']['node']
pnpm = package['devEngines']['packageManager']['version']
if not re.fullmatch(r'\d+\.\d+\.\d+', node) or not re.fullmatch(r'\d+\.\d+\.\d+', pnpm):
    raise ValueError('Toolchain declaration changed and requires review')
epoch = subprocess.check_output(['git', '-C', str(source), 'show', '-s', '--format=%ct'], text=True).strip()
if not epoch.isdigit():
    raise ValueError('Missing official commit timestamp')
with Path(os.environ['GITHUB_OUTPUT']).open('a', encoding='utf8') as stream:
    stream.write(f'node={node}\npnpm={pnpm}\nepoch={epoch}\n')
print(json.dumps({'node': node, 'pnpm': pnpm, 'officialEpoch': epoch}))
