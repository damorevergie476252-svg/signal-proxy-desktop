$ErrorActionPreference='Stop'
$rootPath=Split-Path $PSScriptRoot -Parent
$executable=Join-Path $rootPath 'smoke\dist\win-unpacked\Signal Proxy.exe'
$profile=Join-Path $rootPath 'smoke\profile'
if (-not ([IO.Path]::GetFullPath($executable).StartsWith($rootPath+[IO.Path]::DirectorySeparatorChar))) { throw 'Invalid smoke path' }
$started=Start-Process -FilePath $executable -WindowStyle Hidden -PassThru
$ready=$false
try {
    $deadline=[DateTime]::UtcNow.AddSeconds(65)
    while ([DateTime]::UtcNow -lt $deadline) {
        $logs=@(Get-ChildItem -LiteralPath (Join-Path $profile 'logs') -Filter '*.log' -ErrorAction SilentlyContinue)
        if ($logs.Count -gt 0) {
            $content=($logs | ForEach-Object { Get-Content -LiteralPath $_.FullName -Raw -ErrorAction SilentlyContinue }) -join "`n"
            if ($content -match 'Unhandled Error|SQL initialization error|Failed to initialize SQL|Database startup error|SQLITE_NOTADB|sql.initialize was unsuccessful') { throw 'Packaged startup failed; inspect logs' }
            $windowReady=$content -match 'Main window is ready|main window is ready'
            $databaseReady=$content -match 'MainSQL: (getKnownConversationAttachments: Done processing|finishPageMessages)'
            if ($windowReady -and $databaseReady) { $ready=$true; break }
        }
        if ($started.HasExited) { throw "Smoke process exited: $($started.ExitCode)" }
        Start-Sleep -Milliseconds 500
        $started.Refresh()
    }
    if (-not $ready) { throw 'The isolated packaged window did not become ready in time' }
    $report=@{startupPassed=$true;profileIsolated=$true;noUserAccountUsed=$true}
    [IO.File]::WriteAllText((Join-Path $rootPath 'dist-proxy-fix17\startup-verification.json'),($report | ConvertTo-Json),[Text.UTF8Encoding]::new($false))
    Write-Output 'Isolated packaged application startup passed.'
} finally {
    foreach ($processInfo in @(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -eq $executable })) {
        $process=Get-Process -Id $processInfo.ProcessId -ErrorAction SilentlyContinue
        if ($process -and $process.Path -eq $executable) { $process.Kill($true) }
    }
}
