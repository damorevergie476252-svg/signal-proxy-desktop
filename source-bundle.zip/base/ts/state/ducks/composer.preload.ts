// Copyright 2021 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only

import path from 'node:path';
import lodash from 'lodash';
import { v7 as generateUuid } from 'uuid';

import type { ReadonlyDeep } from 'type-fest';
import type {
  AddLinkPreviewActionType,
  RemoveLinkPreviewActionType,
} from './linkPreviews.preload.ts';
import type {
  AttachmentType,
  AttachmentDraftType,
  InMemoryAttachmentDraftType,
} from '../../types/Attachment.std.ts';
import {
  isImageAttachment,
  isVideoAttachment,
} from '../../util/Attachment.std.ts';
import { writeNewAttachmentData } from '../../util/migrations.preload.ts';
import { getExistingAttachmentDataForReuse } from '../../util/attachments/deduplicateAttachment.preload.ts';
import { migrateDataToFileSystem } from '../../util/attachments/migrateDataToFilesystem.std.ts';
import { isViewOnceEligible } from '../../util/viewOnceEligibility.std.ts';
import { DataReader, DataWriter } from '../../sql/Client.preload.ts';
import type { BoundActionCreatorsMapObject } from '../../hooks/useBoundActions.std.ts';
import { TranscodingTargetQuality } from '../../types/transcoding.std.ts';
import type { DraftBodyRanges } from '../../types/BodyRange.std.ts';
import type { LinkPreviewDraftType } from '../../types/LinkPreview.std.ts';
import type {
  PinMessageData,
  ReadonlyMessageAttributesType,
} from '../../model-types.std.ts';
import { noopAction, type NoopActionType } from './noop.std.ts';
import type { ShowToastActionType } from './toast.preload.ts';
import { createLogger } from '../../logging/log.std.ts';
import * as Errors from '../../types/errors.std.ts';
import type { PollCreateType } from '../../types/Polls.dom.ts';
import { enqueuePollCreateForSend } from '../../util/enqueuePollCreateForSend.dom.ts';
import { enqueueSharedContactForSend } from '../../util/enqueueSharedContactForSend.preload.ts';
import type { ShareContactType } from '../../util/shareContact.std.ts';
import {
  ADD_PREVIEW as ADD_LINK_PREVIEW,
  REMOVE_PREVIEW as REMOVE_LINK_PREVIEW,
} from './linkPreviews.preload.ts';
import { LinkPreviewSourceType } from '../../types/LinkPreview.std.ts';
import type { AciString } from '../../types/ServiceId.std.ts';
import { completeRecording, getIsRecording } from './audioRecorder.preload.ts';
import { SHOW_TOAST, showToast } from './toast.preload.ts';
import type { AnyToast } from '../../types/Toast.dom.tsx';
import { ToastType } from '../../types/Toast.dom.tsx';
import { SafetyNumberChangeSource } from '../../types/SafetyNumberChangeSource.std.ts';
import { assignWithNoUnnecessaryAllocation } from '../../util/assignWithNoUnnecessaryAllocation.std.ts';
import { blockSendUntilConversationsAreVerified } from '../../util/blockSendUntilConversationsAreVerified.dom.ts';
import { clearConversationDraftAttachments } from '../../util/clearConversationDraftAttachments.preload.ts';
import { deleteDraftAttachment } from '../../util/deleteDraftAttachment.preload.ts';
import {
  getLinkPreviewsForSend,
  hasLinkPreviewLoaded,
  maybeGrabLinkPreview,
  removeLinkPreview,
  resetLinkPreview,
  suspendLinkPreviews,
} from '../../services/LinkPreview.preload.ts';
import {
  canSendInHighQuality,
  getAttachmentSizeLimit,
  getRenderDetailsForLimit,
  isAttachmentTooLarge,
} from '../../types/AttachmentSize.std.ts';
import { getValue as getRemoteConfigValue } from '../../RemoteConfig.dom.ts';
import { getRecipientsByConversation } from '../../util/getRecipientsByConversation.dom.ts';
import { getMaxVideoDuration } from '../../util/getTranscodingOptions.preload.ts';
import { processAttachment } from '../../util/processAttachment.preload.ts';
import { hasDraftAttachments } from '../../util/hasDraftAttachments.std.ts';
import { isFileDangerous } from '../../util/isFileDangerous.std.ts';
import { stringToMIMEType } from '../../types/MIME.std.ts';
import { isNotNil } from '../../util/isNotNil.std.ts';
import { replaceIndex } from '../../util/replaceIndex.std.ts';
import { promoteDraftAttachment } from '../../util/promoteDraftAttachment.preload.ts';
import { resolveDraftAttachmentOnDisk } from '../../util/resolveDraftAttachmentOnDisk.preload.ts';
import { shouldShowInvalidMessageToast } from '../../util/shouldShowInvalidMessageToast.preload.ts';
import { writeDraftAttachment } from '../../util/writeDraftAttachment.preload.ts';
import { getMessageById } from '../../messages/getMessageById.preload.ts';
import { canReply, isNormalBubble } from '../selectors/message.preload.ts';
import { getAuthorId } from '../../messages/sources.preload.ts';
import { getConversationSelector } from '../selectors/conversations.dom.ts';
import { enqueueReactionForSend } from '../../reactions/enqueueReactionForSend.preload.ts';
import { enqueuePollTerminateForSend } from '../../polls/enqueuePollTerminateForSend.preload.ts';
import { useBoundActions } from '../../hooks/useBoundActions.std.ts';
import {
  CONVERSATION_UNLOADED,
  scrollToMessage,
} from './conversations.preload.ts';
import type {
  ConversationUnloadedActionType,
  TargetedConversationChangedActionType,
  ScrollToMessageActionType,
} from './conversations.preload.ts';
import { longRunningTaskWrapper } from '../../util/longRunningTaskWrapper.dom.tsx';
import { drop } from '../../util/drop.std.ts';
import { strictAssert } from '../../util/assert.std.ts';
import { makeQuote } from '../../util/makeQuote.preload.ts';
import { sendEditedMessage as doSendEditedMessage } from '../../util/sendEditedMessage.preload.ts';
import { Sound, SoundType } from '../../util/Sound.std.ts';
import {
  isImageTypeSupported,
  isVideoTypeSupported,
} from '../../util/GoogleChrome.std.ts';
import { getPlaintextHashForInMemoryAttachment } from '../../AttachmentCrypto.node.ts';
import type {
  AsyncStateThunk,
  StateDispatch,
  SyncStateThunk,
} from '../types.std.ts';
import { itemStorage } from '../../textsecure/Storage.preload.ts';
import {
  getActivePanel,
  getSelectedConversationId,
} from '../selectors/nav.std.ts';
import { isPoll } from '../../messages/helpers.std.ts';
import type { Emoji } from '../../axo/emoji.std.ts';
import { isFeaturedEnabledNoRedux } from '../../util/isFeatureEnabled.dom.ts';

const { debounce, isEqual } = lodash;

const log = createLogger('composer');

// State
// oxlint-disable-next-line signal-desktop/enforce-type-alias-readonlydeep
type ComposerStateByConversationType = {
  attachments: ReadonlyArray<AttachmentDraftType>;
  focusCounter: number;
  disabledCounter: number;
  isViewOnce: boolean;
  linkPreviewLoading: boolean;
  linkPreviewResult?: LinkPreviewDraftType;
  quotedMessage?: QuotedMessageForComposerType;
  sendCounter: number;
  shouldSendHighQualityAttachments?: boolean;
};

export type QuotedMessageForComposerType = ReadonlyDeep<{
  conversationId: ReadonlyMessageAttributesType['conversationId'];
  quote: ReadonlyMessageAttributesType['quote'] & {
    messageId?: string;
  };
}>;

// oxlint-disable-next-line signal-desktop/enforce-type-alias-readonlydeep
export type ComposerStateType = {
  conversations: Record<string, ComposerStateByConversationType>;
};

function getEmptyComposerState(): ComposerStateByConversationType {
  return {
    attachments: [],
    focusCounter: 0,
    disabledCounter: 0,
    isViewOnce: false,
    linkPreviewLoading: false,
    sendCounter: 0,
  };
}

export function getComposerStateForConversation(
  composer: ComposerStateType,
  conversationId: string
): ComposerStateByConversationType {
  return composer.conversations[conversationId] ?? getEmptyComposerState();
}

// Actions

const ADD_PENDING_ATTACHMENT = 'composer/ADD_PENDING_ATTACHMENT';
const INCREMENT_SEND_COUNTER = 'composer/INCREMENT_SEND_COUNTER';
const REPLACE_ATTACHMENTS = 'composer/REPLACE_ATTACHMENTS';
const RESET_COMPOSER = 'composer/RESET_COMPOSER';
export const SET_FOCUS = 'composer/SET_FOCUS';
const SET_HIGH_QUALITY_SETTING = 'composer/SET_HIGH_QUALITY_SETTING';
const SET_QUOTED_MESSAGE = 'composer/SET_QUOTED_MESSAGE';
const SET_VIEW_ONCE = 'composer/SET_VIEW_ONCE';
const UPDATE_COMPOSER_DISABLED = 'composer/UPDATE_COMPOSER_DISABLED';

type AddPendingAttachmentActionType = ReadonlyDeep<{
  type: typeof ADD_PENDING_ATTACHMENT;
  payload: {
    conversationId: string;
    attachment: AttachmentDraftType;
  };
}>;

export type IncrementSendActionType = ReadonlyDeep<{
  type: typeof INCREMENT_SEND_COUNTER;
  payload: {
    conversationId: string;
  };
}>;

// oxlint-disable-next-line signal-desktop/enforce-type-alias-readonlydeep
export type ReplaceAttachmentsActionType = {
  type: typeof REPLACE_ATTACHMENTS;
  payload: {
    conversationId: string;
    attachments: ReadonlyArray<AttachmentDraftType>;
  };
};

export type ResetComposerActionType = ReadonlyDeep<{
  type: typeof RESET_COMPOSER;
  payload: {
    conversationId: string;
  };
}>;

type UpdateComposerDisabledActionType = ReadonlyDeep<{
  type: typeof UPDATE_COMPOSER_DISABLED;
  payload: {
    conversationId: string;
    value: boolean;
  };
}>;

export type SetFocusActionType = ReadonlyDeep<{
  type: typeof SET_FOCUS;
  payload: {
    conversationId: string;
  };
}>;

type SetHighQualitySettingActionType = ReadonlyDeep<{
  type: typeof SET_HIGH_QUALITY_SETTING;
  payload: {
    conversationId: string;
    value: boolean;
  };
}>;

// oxlint-disable-next-line signal-desktop/enforce-type-alias-readonlydeep
export type SetQuotedMessageActionType = {
  type: typeof SET_QUOTED_MESSAGE;
  payload: {
    conversationId: string;
    quotedMessage?: QuotedMessageForComposerType;
  };
};

export type SetViewOnceActionType = ReadonlyDeep<{
  type: typeof SET_VIEW_ONCE;
  payload: {
    conversationId: string;
    value: boolean;
  };
}>;

// oxlint-disable-next-line signal-desktop/enforce-type-alias-readonlydeep
type ComposerActionType =
  | AddLinkPreviewActionType
  | AddPendingAttachmentActionType
  | ConversationUnloadedActionType
  | IncrementSendActionType
  | RemoveLinkPreviewActionType
  | ReplaceAttachmentsActionType
  | ResetComposerActionType
  | TargetedConversationChangedActionType
  | UpdateComposerDisabledActionType
  | SetFocusActionType
  | SetHighQualitySettingActionType
  | SetQuotedMessageActionType
  | SetViewOnceActionType;

// Action Creators

export const actions = {
  addAttachment,
  addPendingAttachment,
  cancelJoinRequest,
  endPoll,
  incrementSendCounter,
  onClearDraft,
  onClearAttachments,
  onCloseLinkPreview,
  onEditorStateChange,
  onTextTooLong,
  processAttachments,
  reactToMessage,
  removeAttachment,
  replaceAttachments,
  resetComposer,
  saveDraftRecordingIfNeeded,
  scrollToPinnedMessage,
  scrollToPollMessage,
  scrollToQuotedMessage,
  sendEditedMessage,
  sendMultiMediaMessage,
  sendPoll,
  sendStickerMessage,
  setComposerFocus,
  setMediaQualitySetting,
  setQuoteByMessageId,
  setQuotedMessage,
  setViewOnce,
  shareContact,
  updateComposerDisabled,
};

function incrementSendCounter(conversationId: string): IncrementSendActionType {
  return {
    type: INCREMENT_SEND_COUNTER,
    payload: {
      conversationId,
    },
  };
}

export const useComposerActions = (): BoundActionCreatorsMapObject<
  typeof actions
> => useBoundActions(actions);

function onClearDraft(conversationId: string): SyncStateThunk<NoopActionType> {
  return dispatch => {
    const conversation = window.ConversationController.get(conversationId);
    if (!conversation) {
      throw new Error('onClearDraft: No conversation found');
    }

    conversation.set({
      draft: '',
      draftBodyRanges: [],
      quotedMessageId: null,
    });

    dispatch(onClearAttachments(conversation.id));
  };
}

function onClearAttachments(conversationId: string): NoopActionType {
  const conversation = window.ConversationController.get(conversationId);
  if (!conversation) {
    throw new Error('onClearAttachments: No conversation found');
  }

  void clearConversationDraftAttachments(
    conversation.id,
    conversation.get('draftAttachments')
  );

  return noopAction('onClearAttachments');
}

function cancelJoinRequest(conversationId: string): NoopActionType {
  const conversation = window.ConversationController.get(conversationId);
  if (!conversation) {
    throw new Error('cancelJoinRequest: No conversation found');
  }

  void longRunningTaskWrapper({
    idForLogging: conversation.idForLogging(),
    name: 'cancelJoinRequest',
    task: async () => conversation.cancelJoinRequest(),
  });

  return noopAction('cancelJoinRequest');
}

function onCloseLinkPreview(conversationId: string): NoopActionType {
  suspendLinkPreviews();
  removeLinkPreview(conversationId);

  return noopAction('onCloseLinkPreview');
}

function onTextTooLong(): ShowToastActionType {
  return {
    type: SHOW_TOAST,
    payload: {
      toastType: ToastType.MessageBodyTooLong,
    },
  };
}

function scrollToQuotedMessage({
  authorId,
  conversationId,
  sentAt,
}: Readonly<{
  authorId: string;
  conversationId: string;
  sentAt: number;
}>): AsyncStateThunk<ShowToastActionType | ScrollToMessageActionType> {
  return async (dispatch, getState) => {
    const messages = await DataReader.getMessagesBySentAt(sentAt);
    const message = messages.find(item =>
      Boolean(
        item.conversationId === conversationId &&
        authorId &&
        getAuthorId(item) === authorId
      )
    );

    if (!message) {
      dispatch({
        type: SHOW_TOAST,
        payload: {
          toastType: ToastType.OriginalMessageNotFound,
        },
      });
      return;
    }

    if (getSelectedConversationId(getState()) !== conversationId) {
      return;
    }

    void dispatch(scrollToMessage(conversationId, message.id));
  };
}

function scrollToPinnedMessage(
  pinMessage: PinMessageData
): AsyncStateThunk<ShowToastActionType | ScrollToMessageActionType> {
  return async (dispatch, getState) => {
    const ourAci = itemStorage.user.getCheckedAci();

    const pinnedMessage = await DataReader.getMessageByAuthorAciAndSentAt(
      ourAci,
      pinMessage.targetAuthorAci,
      pinMessage.targetSentTimestamp,
      { includeEdits: true }
    );

    if (!pinnedMessage) {
      dispatch(
        showToast({
          toastType: ToastType.PinnedMessageNotFound,
        })
      );
      return;
    }

    const selectedConversationId = getSelectedConversationId(getState());

    if (selectedConversationId !== pinnedMessage.conversationId) {
      return;
    }

    void dispatch(
      scrollToMessage(pinnedMessage.conversationId, pinnedMessage.id)
    );
  };
}

function scrollToPollMessage(
  pollAuthorAci: AciString,
  pollTimestamp: number,
  conversationId: string
): AsyncStateThunk<ShowToastActionType | ScrollToMessageActionType> {
  return async (dispatch, getState) => {
    const ourAci = itemStorage.user.getCheckedAci();

    const pollMessage = await DataReader.getMessageByAuthorAciAndSentAt(
      ourAci,
      pollAuthorAci,
      pollTimestamp,
      { includeEdits: true }
    );

    if (!pollMessage || !isPoll(pollMessage)) {
      dispatch({
        type: SHOW_TOAST,
        payload: {
          toastType: ToastType.PollNotFound,
        },
      });
      return;
    }

    if (getSelectedConversationId(getState()) !== conversationId) {
      return;
    }

    void dispatch(scrollToMessage(conversationId, pollMessage.id));
  };
}

export function saveDraftRecordingIfNeeded(
  conversationId: string
): SyncStateThunk {
  return (dispatch, getState) => {
    const state = getState();

    if (!getIsRecording(state.audioRecorder) || !conversationId) {
      return;
    }

    void dispatch(
      completeRecording(conversationId, attachment => {
        dispatch(
          addPendingAttachment(conversationId, { ...attachment, pending: true })
        );
        void dispatch(addAttachment(conversationId, attachment));

        const conversation = window.ConversationController.get(conversationId);
        if (!conversation) {
          throw new Error('saveDraftRecordingIfNeeded: No conversation found');
        }

        drop(conversation.updateLastMessage());
      })
    );
  };
}

// oxlint-disable-next-line signal-desktop/enforce-type-alias-readonlydeep
type WithPreSendChecksOptions = Readonly<{
  message?: string;
  voiceNoteAttachment?: InMemoryAttachmentDraftType;
  draftAttachments?: ReadonlyArray<AttachmentDraftType>;
}>;

async function withPreSendChecks(
  conversationId: string,
  options: WithPreSendChecksOptions,
  dispatch: StateDispatch<
    UpdateComposerDisabledActionType | ShowToastActionType
  >,
  body: () => Promise<void>
): Promise<void> {
  const conversation = window.ConversationController.get(conversationId);
  if (!conversation) {
    throw new Error('withPreSendChecks: No conversation found');
  }

  const sendStart = Date.now();
  const recipientsByConversation = getRecipientsByConversation([
    conversation.attributes,
  ]);

  const { message, voiceNoteAttachment } = options;
  const draftAttachments =
    options.draftAttachments ?? conversation.attributes.draftAttachments;

  try {
    dispatch(updateComposerDisabled(conversationId, true));

    try {
      const sendAnyway = await blockSendUntilConversationsAreVerified(
        recipientsByConversation,
        SafetyNumberChangeSource.MessageSend
      );
      if (!sendAnyway) {
        return;
      }
    } catch (error) {
      log.error(
        'withPreSendChecks block until verified error:',
        Errors.toLogFormat(error)
      );
      return;
    }

    const toast = shouldShowInvalidMessageToast(conversation.attributes);
    if (toast != null) {
      dispatch({
        type: SHOW_TOAST,
        payload: toast,
      });
      return;
    }

    if (
      !message?.length &&
      !hasDraftAttachments(draftAttachments, {
        includePending: false,
      }) &&
      !voiceNoteAttachment
    ) {
      return;
    }

    const sendDelta = Date.now() - sendStart;
    log.info(`withPreSendChecks: Send pre-checks took ${sendDelta}ms`);

    await body();
  } finally {
    dispatch(updateComposerDisabled(conversationId, false));
  }

  conversation.clearTypingTimers();
}

function sendEditedMessage(
  conversationId: string,
  options: WithPreSendChecksOptions & {
    bodyRanges?: DraftBodyRanges;
    targetMessageId: string;
    quoteAuthorAci?: AciString;
    quoteSentAt?: number;
  }
): AsyncStateThunk<
  | UpdateComposerDisabledActionType
  | ShowToastActionType
  | IncrementSendActionType
> {
  return async dispatch => {
    const conversation = window.ConversationController.get(conversationId);
    if (!conversation) {
      throw new Error('sendEditedMessage: No conversation found');
    }

    const {
      message = '',
      bodyRanges,
      quoteSentAt,
      quoteAuthorAci,
      targetMessageId,
    } = options;

    await withPreSendChecks(conversationId, options, dispatch, async () => {
      try {
        await doSendEditedMessage(conversationId, {
          body: message,
          bodyRanges,
          preview: await getLinkPreviewsForSend(message),
          quoteAuthorAci,
          quoteSentAt,
          targetMessageId,
        });
        dispatch(incrementSendCounter(conversationId));
      } catch (error) {
        log.error('sendEditedMessage', Errors.toLogFormat(error));
        if (error.toastType) {
          dispatch({
            type: SHOW_TOAST,
            payload: {
              toastType: error.toastType,
            },
          });
        }
      }
    });
  };
}

function sendMultiMediaMessage(
  conversationId: string,
  options: WithPreSendChecksOptions & {
    bodyRanges?: DraftBodyRanges;
    draftAttachments?: ReadonlyArray<AttachmentDraftType>;
    isViewOnce?: boolean;
    timestamp?: number;
  }
): AsyncStateThunk<
  | IncrementSendActionType
  | NoopActionType
  | ResetComposerActionType
  | UpdateComposerDisabledActionType
  | SetQuotedMessageActionType
  | ShowToastActionType
> {
  return async (dispatch, getState) => {
    const conversation = window.ConversationController.get(conversationId);
    if (!conversation) {
      throw new Error('sendMultiMediaMessage: No conversation found');
    }

    const {
      draftAttachments,
      isViewOnce,
      timestamp = Date.now(),
      voiceNoteAttachment,
    } = options;

    const { message = '', bodyRanges } = isViewOnce ? {} : options;

    const state = getState();

    const maxHighQualityVideoDuration = getMaxVideoDuration(
      TranscodingTargetQuality.High
    );

    const canSendInHQ = canSendInHighQuality(draftAttachments ?? [], {
      getRemoteConfigValue,
      maxHighQualityVideoDuration,
    });

    await withPreSendChecks(conversationId, options, dispatch, async () => {
      let attachments: Array<AttachmentType> = [];
      if (voiceNoteAttachment) {
        strictAssert(
          !voiceNoteAttachment.pending,
          'Voice note is still pending'
        );
        const {
          data,
          // oxlint-disable-next-line typescript/no-unused-vars
          screenshotData: _screenshotData,
          ...rest
        } = voiceNoteAttachment;
        const onDisk = await migrateDataToFileSystem(rest, data, {
          writeNewAttachmentData,
          getExistingAttachmentDataForReuse,
          getPlaintextHashForInMemoryAttachment,
        });
        attachments = [onDisk];
      } else if (draftAttachments) {
        attachments = (
          await Promise.all(draftAttachments.map(promoteDraftAttachment))
        ).filter(isNotNil);
      }

      const conversationComposerState = getComposerStateForConversation(
        state.composer,
        conversationId
      );

      const quote = conversationComposerState.quotedMessage?.quote;

      const shouldSendHighQualityAttachments = window.reduxStore
        ? conversationComposerState.shouldSendHighQualityAttachments
        : undefined;

      const sendHQImages =
        canSendInHQ &&
        (shouldSendHighQualityAttachments !== undefined
          ? shouldSendHighQualityAttachments
          : state.items['sent-media-quality'] === 'high');

      try {
        await conversation.enqueueMessageForSend(
          {
            body: message,
            attachments,
            quote,
            preview: await getLinkPreviewsForSend(message),
            bodyRanges,
            isViewOnce,
          },
          {
            sendHQImages,
            timestamp,
            // We rely on enqueueMessageForSend to call these within redux's batch
            extraReduxActions: () => {
              conversation.setMarkedUnread(false);
              resetLinkPreview(conversationId);
              drop(
                clearConversationDraftAttachments(
                  conversationId,
                  draftAttachments
                )
              );
              void dispatch(setQuoteByMessageId(conversationId, undefined));
              dispatch(incrementSendCounter(conversationId));

              if (state.items.audioMessage) {
                drop(new Sound({ soundType: SoundType.Whoosh }).play());
              }
            },
          }
        );
      } catch (error) {
        log.error(
          'Error pulling attached files before send',
          Errors.toLogFormat(error)
        );
      }
    });
  };
}

function sendStickerMessage(
  conversationId: string,
  options: {
    packId: string;
    stickerId: number;
  }
): AsyncStateThunk<
  | NoopActionType
  | ShowToastActionType
  | IncrementSendActionType
  | SetQuotedMessageActionType
> {
  return async (dispatch, getState) => {
    const conversation = window.ConversationController.get(conversationId);
    if (!conversation) {
      throw new Error('sendStickerMessage: No conversation found');
    }

    const recipientsByConversation = getRecipientsByConversation([
      conversation.attributes,
    ]);

    try {
      const sendAnyway = await blockSendUntilConversationsAreVerified(
        recipientsByConversation,
        SafetyNumberChangeSource.MessageSend
      );
      if (!sendAnyway) {
        return;
      }

      const toast = shouldShowInvalidMessageToast(conversation.attributes);
      if (toast != null) {
        dispatch({
          type: SHOW_TOAST,
          payload: toast,
        });
        return;
      }

      const isStickerReplySendEnabled = isFeaturedEnabledNoRedux({
        betaKey: 'desktop.stickerReply.send.beta',
        prodKey: 'desktop.stickerReply.send.prod',
      });

      let sendStickerMessageOptions;
      if (isStickerReplySendEnabled) {
        const state = getState();
        const conversationComposerState = getComposerStateForConversation(
          state.composer,
          conversationId
        );
        const quote = conversationComposerState.quotedMessage?.quote;

        const draft = conversation.get('draft');
        const isDraftPresent =
          (draft != null && draft.length > 0) ||
          conversationComposerState.attachments.length > 0;

        sendStickerMessageOptions = {
          quote,
          extraReduxActions: isDraftPresent
            ? undefined
            : () => {
                void dispatch(setQuoteByMessageId(conversationId, undefined));
              },
        };
      } else {
        sendStickerMessageOptions = undefined;
      }

      const { packId, stickerId } = options;
      drop(
        conversation.sendStickerMessage(
          packId,
          stickerId,
          sendStickerMessageOptions
        )
      );
    } catch (error) {
      log.error('clickSend error:', Errors.toLogFormat(error));
    }

    dispatch(noopAction('sendStickerMessage'));
  };
}

function sendPoll(
  conversationId: string,
  poll: PollCreateType
): AsyncStateThunk<NoopActionType | ShowToastActionType> {
  return async dispatch => {
    const conversation = window.ConversationController.get(conversationId);
    if (!conversation) {
      throw new Error('sendPoll: No conversation found');
    }

    const recipientsByConversation = getRecipientsByConversation([
      conversation.attributes,
    ]);

    try {
      const sendAnyway = await blockSendUntilConversationsAreVerified(
        recipientsByConversation,
        SafetyNumberChangeSource.MessageSend
      );
      if (!sendAnyway) {
        return;
      }

      const toast = shouldShowInvalidMessageToast(conversation.attributes);
      if (toast != null) {
        dispatch({
          type: SHOW_TOAST,
          payload: toast,
        });
        return;
      }

      await enqueuePollCreateForSend(conversation, poll);
    } catch (error) {
      log.error('sendPoll error:', Errors.toLogFormat(error));
    }

    dispatch(noopAction('sendPoll'));
  };
}

function shareContact(
  conversationId: string,
  contact: ShareContactType
): AsyncStateThunk<NoopActionType | ShowToastActionType> {
  return async dispatch => {
    const conversation = window.ConversationController.get(conversationId);
    if (!conversation) {
      throw new Error('shareContact: No conversation found');
    }

    const recipientsByConversation = getRecipientsByConversation([
      conversation.attributes,
    ]);

    try {
      const sendAnyway = await blockSendUntilConversationsAreVerified(
        recipientsByConversation,
        SafetyNumberChangeSource.MessageSend
      );
      if (!sendAnyway) {
        return;
      }

      const toast = shouldShowInvalidMessageToast(conversation.attributes);
      if (toast != null) {
        dispatch({
          type: SHOW_TOAST,
          payload: toast,
        });
        return;
      }

      await enqueueSharedContactForSend(conversation, contact);
    } catch (error) {
      log.error('shareContact error:', Errors.toLogFormat(error));
    }

    dispatch(noopAction('shareContact'));
  };
}

// Not cool that we have to pull from ConversationModel here
// but if the current selected conversation isn't the one that we're operating
// on then we won't be able to grab attachments from state so we resort to the
// next in-memory store.
function getAttachmentsFromConversationModel(
  conversationId: string
): ReadonlyArray<AttachmentDraftType> {
  const conversation = window.ConversationController.get(conversationId);
  return conversation?.get('draftAttachments') || [];
}

export function setQuoteByMessageId(
  conversationId: string,
  messageId: string | undefined
): AsyncStateThunk<SetQuotedMessageActionType> {
  return async (dispatch, getState) => {
    const conversation = window.ConversationController.get(conversationId);
    if (!conversation) {
      throw new Error('setQuoteByMessageId: No conversation found');
    }

    const activePanel = getActivePanel(getState());
    if (activePanel != null && messageId != null) {
      // Reset the conversation panels and scroll to the message
      // in case we're inside of a conversation panel like pinned messages
      void dispatch(scrollToMessage(conversationId, messageId));
    }

    const draftEditMessage = conversation.get('draftEditMessage');
    // We can remove quotes, but we can't add them
    if (draftEditMessage && messageId) {
      return;
    }
    if (draftEditMessage && draftEditMessage.quote) {
      conversation.set({
        draftEditMessage: {
          ...draftEditMessage,
          quote: undefined,
        },
      });
      void dispatch(setComposerFocus(conversation.id));
      return;
    }

    const message = messageId ? await getMessageById(messageId) : undefined;
    const state = getState();
    if (
      !message ||
      !isNormalBubble(message.attributes) ||
      !canReply(
        message.attributes,
        window.ConversationController.getOurConversationIdOrThrow(),
        getConversationSelector(state)
      )
    ) {
      dispatch(setQuotedMessage(conversationId, undefined));
      conversation.set({
        quotedMessageId: undefined,
      });
      await DataWriter.updateConversation(conversation.attributes);
      return;
    }

    const existing = conversation.get('quotedMessageId');
    if (existing !== messageId) {
      const now = Date.now();
      let activeAt = conversation.get('active_at');
      let timestamp = conversation.get('timestamp');

      if (!activeAt && messageId) {
        activeAt = now;
        timestamp = now;
      }

      conversation.set({
        active_at: activeAt,
        draftChanged: true,
        quotedMessageId: messageId,
        timestamp,
      });

      await DataWriter.updateConversation(conversation.attributes);
    }

    const quote = await makeQuote(message.attributes);

    // In case the conversation changed while we were about to set the quote
    if (getSelectedConversationId(getState()) !== conversationId) {
      return;
    }

    dispatch(
      setQuotedMessage(conversationId, {
        conversationId,
        quote,
      })
    );
    dispatch(disableViewOnceIfIneligible(conversationId));

    void dispatch(setComposerFocus(conversation.id));
  };
}

function addAttachment(
  conversationId: string,
  attachment: InMemoryAttachmentDraftType
): AsyncStateThunk<ReplaceAttachmentsActionType> {
  return async dispatch => {
    // We do async operations first so multiple in-process addAttachments don't stomp on
    //   each other.
    const onDisk = await writeDraftAttachment(attachment);
    await dispatch(addDraftAttachment(conversationId, onDisk));
  };
}

function addDraftAttachment(
  conversationId: string,
  attachment: AttachmentDraftType
): AsyncStateThunk<ReplaceAttachmentsActionType> {
  return async (dispatch, getState) => {
    const state = getState();

    const isSelectedConversation =
      getSelectedConversationId(state) === conversationId;

    const conversationComposerState = getComposerStateForConversation(
      state.composer,
      conversationId
    );

    const draftAttachments = isSelectedConversation
      ? conversationComposerState.attachments
      : getAttachmentsFromConversationModel(conversationId);

    // We expect there to either be a pending draft attachment or an existing
    // attachment that we'll be replacing.
    const hasDraftAttachmentPending = draftAttachments.some(
      draftAttachment => draftAttachment.clientUuid === attachment.clientUuid
    );

    // User has canceled the draft so we don't need to continue processing
    if (!hasDraftAttachmentPending) {
      await deleteDraftAttachment(attachment);
      return;
    }

    // Remove any pending attachments that were transcoding
    const index = draftAttachments.findIndex(
      draftAttachment => draftAttachment.clientUuid === attachment.clientUuid
    );
    let nextAttachments = draftAttachments;
    if (index < 0) {
      log.warn(
        `addAttachment: Failed to find pending attachment with path ${attachment.path}`
      );
      nextAttachments = [...draftAttachments, attachment];
    } else {
      nextAttachments = replaceIndex(draftAttachments, index, attachment);
    }

    dispatch(replaceAttachments(conversationId, nextAttachments));

    const conversation = window.ConversationController.get(conversationId);
    if (conversation) {
      conversation.set({
        draftAttachments: nextAttachments,
        draftChanged: true,
      });

      // if the conversation has already unloaded
      if (!isSelectedConversation) {
        const now = Date.now();
        const activeAt = conversation.get('active_at') || now;
        conversation.set({
          active_at: activeAt,
          draftChanged: false,
          draftTimestamp: now,
        });
      }

      await DataWriter.updateConversation(conversation.attributes);
    }
  };
}

function addPendingAttachment(
  conversationId: string,
  pendingAttachment: AttachmentDraftType
): SyncStateThunk<ReplaceAttachmentsActionType> {
  return (dispatch, getState) => {
    const state = getState();

    const isSelectedConversation =
      getSelectedConversationId(state) === conversationId;

    const conversationComposerState = getComposerStateForConversation(
      state.composer,
      conversationId
    );

    const draftAttachments = isSelectedConversation
      ? conversationComposerState.attachments
      : getAttachmentsFromConversationModel(conversationId);

    const nextAttachments = [...draftAttachments, pendingAttachment];

    dispatch({
      type: REPLACE_ATTACHMENTS,
      payload: {
        conversationId,
        attachments: nextAttachments,
      },
    });

    const conversation = window.ConversationController.get(conversationId);
    if (conversation) {
      conversation.set({
        draftAttachments: nextAttachments,
        draftChanged: true,
      });
      drop(DataWriter.updateConversation(conversation.attributes));
    }
  };
}

export function setComposerFocus(
  conversationId: string
): AsyncStateThunk<SetFocusActionType> {
  return async (dispatch, getState) => {
    if (getSelectedConversationId(getState()) !== conversationId) {
      return;
    }

    dispatch({
      type: SET_FOCUS,
      payload: {
        conversationId,
      },
    });
  };
}

function onEditorStateChange({
  bodyRanges,
  caretLocation,
  conversationId,
  messageText,
  sendCounter,
}: {
  bodyRanges: DraftBodyRanges;
  caretLocation?: number;
  conversationId: string | undefined;
  messageText: string;
  sendCounter: number;
}): SyncStateThunk<NoopActionType> {
  return (dispatch, getState) => {
    if (!conversationId) {
      throw new Error(
        'onEditorStateChange: Got falsey conversationId, needs local override'
      );
    }

    const conversation = window.ConversationController.get(conversationId);
    if (!conversation) {
      throw new Error('onEditorStateChange: Unable to find conversation');
    }

    const state = getState().composer.conversations[conversationId];
    if (!state) {
      return;
    }

    if (state.sendCounter !== sendCounter) {
      log.warn(
        `onEditorStateChange: Got update for conversation ${conversation.idForLogging()}`,
        `but sendCounter doesnt match (old: ${state.sendCounter}, new: ${sendCounter})`
      );
      return;
    }

    debouncedSaveDraft(conversationId, messageText, bodyRanges);

    // If we have attachments, don't add link preview
    if (
      hasDraftAttachments(conversation.attributes.draftAttachments, {
        includePending: true,
      }) ||
      Boolean(conversation.attributes.draftEditMessage?.attachmentThumbnail)
    ) {
      return;
    }

    maybeGrabLinkPreview(messageText, LinkPreviewSourceType.Composer, {
      caretLocation,
      conversationId,
    });

    dispatch(noopAction('onEditorStateChange'));
  };
}

function processAttachments({
  conversationId,
  files,
  flags,
}: {
  conversationId: string;
  files: ReadonlyArray<File>;
  flags: number | null;
}): AsyncStateThunk<
  NoopActionType | ShowToastActionType | UpdateComposerDisabledActionType
> {
  return async (dispatch, getState) => {
    if (!files.length) {
      return;
    }

    // If the call came from a conversation we are no longer in we do not
    // update the state.
    if (getSelectedConversationId(getState()) !== conversationId) {
      return;
    }

    const conversation = window.ConversationController.get(conversationId);
    if (!conversation) {
      throw new Error('processAttachments: Unable to find conv');
    }

    const draftEditMessage = conversation.get('draftEditMessage');
    if (draftEditMessage) {
      return;
    }

    const { audioRecorder } = getState();

    if (getIsRecording(audioRecorder)) {
      return;
    }

    if (hasLinkPreviewLoaded()) {
      removeLinkPreview(conversationId);
    }

    let toastToShow: AnyToast | undefined;

    const nextDraftAttachments = (
      conversation.get('draftAttachments') || []
    ).slice();
    const filesToProcess: Array<{
      file: File;
      pendingAttachment: AttachmentDraftType;
    }> = [];
    for (const file of files) {
      const processingResult = preProcessAttachment(file, nextDraftAttachments);
      if (processingResult != null) {
        toastToShow = processingResult;
      } else {
        const pendingAttachment = getPendingAttachment(file);
        if (pendingAttachment) {
          dispatch(addPendingAttachment(conversationId, pendingAttachment));
          filesToProcess.push({ file, pendingAttachment });
          // we keep a running count of the draft attachments so we can show a
          // toast in case we add too many attachments at once
          nextDraftAttachments.push(pendingAttachment);
        }
      }
    }

    dispatch(updateComposerDisabled(conversationId, true));

    try {
      await Promise.all(
        filesToProcess.map(async ({ file, pendingAttachment }) => {
          try {
            const attachment = await processAttachment(file, {
              generateScreenshot: true,
              flags,
              clientUuid: pendingAttachment.clientUuid,
            });
            if (!attachment) {
              void dispatch(
                removeAttachment(conversationId, pendingAttachment)
              );
              return;
            }
            void dispatch(addDraftAttachment(conversationId, attachment));
          } catch (err) {
            log.error(
              'handleAttachmentsProcessing: failed to process attachment:',
              Errors.toLogFormat(err)
            );
            void dispatch(removeAttachment(conversationId, pendingAttachment));
            toastToShow = { toastType: ToastType.UnableToLoadAttachment };
          }
        })
      );
    } finally {
      dispatch(updateComposerDisabled(conversationId, false));
    }

    if (toastToShow) {
      dispatch({
        type: SHOW_TOAST,
        payload: toastToShow,
      });

      return;
    }

    dispatch(noopAction('processAttachments'));
  };
}

function preProcessAttachment(
  file: File,
  draftAttachments: Array<AttachmentDraftType>
): AnyToast | undefined {
  if (!file) {
    return;
  }

  if (isFileDangerous(file.name)) {
    return { toastType: ToastType.DangerousFileType };
  }

  if (draftAttachments.length >= 32) {
    return { toastType: ToastType.MaxAttachments };
  }

  const haveNonImageOrVideo = draftAttachments.some(
    (attachment: AttachmentDraftType) => {
      return !isImageAttachment(attachment) && !isVideoAttachment(attachment);
    }
  );
  // You can't add another attachment if you already have a non-image staged
  if (haveNonImageOrVideo) {
    return { toastType: ToastType.UnsupportedMultiAttachment };
  }

  const fileType = stringToMIMEType(file.type);
  const imageOrVideo =
    isImageTypeSupported(fileType) || isVideoTypeSupported(fileType);

  // You can't add a non-image attachment if you already have attachments staged
  if (!imageOrVideo && draftAttachments.length > 0) {
    return { toastType: ToastType.CannotMixMultiAndNonMultiAttachments };
  }

  // Let video be transcoded to smaller size before rejecting it here
  if (!isVideoTypeSupported(fileType)) {
    // Putting this after everything else because the other checks are more
    // important to show to the user.
    const sizeLimit = getAttachmentSizeLimit({
      contentType: fileType,
      getRemoteConfigValue,
    });

    if (
      isAttachmentTooLarge({
        plaintextSize: file.size,
        ciphertextLimit: sizeLimit,
      })
    ) {
      return {
        toastType: isVideoAttachment({ contentType: fileType })
          ? ToastType.VideoFileSize
          : ToastType.FileSize,
        parameters: getRenderDetailsForLimit(sizeLimit),
      };
    }
  }

  return undefined;
}

function getPendingAttachment(file: File): AttachmentDraftType | undefined {
  if (!file) {
    return;
  }

  const fileType = stringToMIMEType(file.type);
  const { name: fileName } = path.parse(file.name);

  return {
    contentType: fileType,
    clientUuid: generateUuid(),
    fileName,
    size: file.size,
    path: file.name,
    pending: true,
  };
}

function removeAttachment(
  conversationId: string,
  draft: AttachmentDraftType
): AsyncStateThunk<ReplaceAttachmentsActionType> {
  return async (dispatch, getState) => {
    const state = getState();

    const { attachments } = getComposerStateForConversation(
      state.composer,
      conversationId
    );

    const targetAttachmentIndex = attachments.findIndex(attachment => {
      return (
        attachment.clientUuid != null &&
        attachment.clientUuid === draft.clientUuid
      );
    });
    if (targetAttachmentIndex === -1) {
      return;
    }

    const targetAttachment = attachments[targetAttachmentIndex];
    strictAssert(targetAttachment, 'Missing targetAttachment');

    const nextAttachments = attachments
      .slice(0, targetAttachmentIndex)
      .concat(attachments.slice(targetAttachmentIndex + 1));

    const conversation = window.ConversationController.get(conversationId);
    if (conversation) {
      conversation.set({
        draftAttachments: nextAttachments,
        draftChanged: true,
      });
      await DataWriter.updateConversation(conversation.attributes);
    }

    dispatch(replaceAttachments(conversationId, nextAttachments));

    if (
      targetAttachment.path &&
      targetAttachment.fileName !== targetAttachment.path
    ) {
      await deleteDraftAttachment(targetAttachment);
    }
  };
}

export function replaceAttachments(
  conversationId: string,
  attachments: ReadonlyArray<AttachmentDraftType>
): SyncStateThunk<
  ReplaceAttachmentsActionType | SetViewOnceActionType | ShowToastActionType
> {
  return (dispatch, getState) => {
    // If the call came from a conversation we are no longer in we do not
    // update the state.
    if (getSelectedConversationId(getState()) !== conversationId) {
      return;
    }

    if (hasDraftAttachments(attachments, { includePending: true })) {
      removeLinkPreview(conversationId);
    }

    dispatch({
      type: REPLACE_ATTACHMENTS,
      payload: {
        conversationId,
        attachments: attachments.map(resolveDraftAttachmentOnDisk),
      },
    });
    void dispatch(setComposerFocus(conversationId));
    dispatch(disableViewOnceIfIneligible(conversationId));
  };
}

function reactToMessage(
  messageId: string,
  reaction: { emoji: Emoji.Variant; remove: boolean }
): AsyncStateThunk<NoopActionType | ShowToastActionType> {
  return async dispatch => {
    const { emoji, remove } = reaction;
    try {
      await enqueueReactionForSend({
        messageId,
        emoji,
        remove,
      });
      dispatch(noopAction('reactToMessage'));
    } catch (error) {
      log.error(
        'reactToMessage: Error sending reaction',
        error,
        messageId,
        reaction
      );
      dispatch({
        type: SHOW_TOAST,
        payload: {
          toastType: ToastType.ReactionFailed,
        },
      });
    }
  };
}

function endPoll(
  messageId: string
): AsyncStateThunk<NoopActionType | ShowToastActionType> {
  return async dispatch => {
    try {
      await enqueuePollTerminateForSend({ messageId });
      dispatch(noopAction('endPoll'));
    } catch (error) {
      log.error('endPoll: Error sending poll terminate', error, messageId);
      dispatch({
        type: SHOW_TOAST,
        payload: {
          toastType: ToastType.Error,
        },
      });
    }
  };
}

export function resetComposer(conversationId: string): ResetComposerActionType {
  return {
    type: RESET_COMPOSER,
    payload: {
      conversationId,
    },
  };
}
const debouncedSaveDraft = debounce(saveDraft, 100);

function saveDraft(
  conversationId: string,
  messageText: string,
  bodyRanges: DraftBodyRanges
) {
  const conversation = window.ConversationController.get(conversationId);
  if (!conversation) {
    throw new Error('saveDraft: Unable to find conversation');
  }

  const trimmed =
    messageText && messageText.length > 0 ? messageText.trim() : '';

  if (conversation.get('draft') && (!messageText || trimmed.length === 0)) {
    conversation.set({
      draft: null,
      draftChanged: true,
      draftBodyRanges: [],
    });
    drop(DataWriter.updateConversation(conversation.attributes));
    return;
  }

  if (
    messageText !== conversation.get('draft') ||
    !isEqual(bodyRanges, conversation.get('draftBodyRanges'))
  ) {
    const now = Date.now();
    let activeAt = conversation.get('active_at');
    let timestamp = conversation.get('timestamp');

    if (!activeAt) {
      activeAt = now;
      timestamp = now;
    }

    if (messageText.length && conversation.throttledBumpTyping) {
      conversation.throttledBumpTyping();
    }

    conversation.set({
      active_at: activeAt,
      draft: messageText,
      draftBodyRanges: bodyRanges,
      draftChanged: true,
      timestamp,
    });
    drop(DataWriter.updateConversation(conversation.attributes));
  }
}

function updateComposerDisabled(
  conversationId: string,
  value: boolean
): UpdateComposerDisabledActionType {
  return {
    type: UPDATE_COMPOSER_DISABLED,
    payload: {
      conversationId,
      value,
    },
  };
}

function setMediaQualitySetting(
  conversationId: string,
  value: boolean
): SetHighQualitySettingActionType {
  return {
    type: SET_HIGH_QUALITY_SETTING,
    payload: {
      conversationId,
      value,
    },
  };
}

function setQuotedMessage(
  conversationId: string,
  quotedMessage?: QuotedMessageForComposerType
): SetQuotedMessageActionType {
  return {
    type: SET_QUOTED_MESSAGE,
    payload: {
      conversationId,
      quotedMessage,
    },
  };
}

export function setViewOnce({
  conversationId,
  value,
  toastNotify,
}: {
  conversationId: string;
  value: boolean;
  toastNotify: boolean;
}): AsyncStateThunk<SetViewOnceActionType | ShowToastActionType> {
  return async (dispatch, getState) => {
    const composerState = getComposerStateForConversation(
      getState().composer,
      conversationId
    );
    const nextValue =
      value &&
      isViewOnceEligible(
        composerState.attachments,
        Boolean(composerState.quotedMessage)
      );

    if (composerState.isViewOnce !== nextValue) {
      dispatch({
        type: SET_VIEW_ONCE,
        payload: {
          conversationId,
          value: nextValue,
        },
      });

      if (toastNotify) {
        dispatch(
          showToast({
            toastType: nextValue
              ? ToastType.ViewOnceEnabled
              : ToastType.ViewOnceDisabled,
          })
        );
      }
    }

    const conversation = window.ConversationController.get(conversationId);
    if (conversation && conversation.get('draftIsViewOnce') !== nextValue) {
      conversation.set({
        draftIsViewOnce: nextValue,
        draftChanged: true,
      });
      await DataWriter.updateConversation(conversation.attributes);
    }
  };
}

function disableViewOnceIfIneligible(
  conversationId: string,
  toastNotify = true
): SyncStateThunk<SetViewOnceActionType | ShowToastActionType> {
  return (dispatch, getState) => {
    const composerState = getComposerStateForConversation(
      getState().composer,
      conversationId
    );
    if (
      composerState.isViewOnce &&
      !isViewOnceEligible(
        composerState.attachments,
        Boolean(composerState.quotedMessage)
      )
    ) {
      void dispatch(
        setViewOnce({
          conversationId,
          value: false,
          toastNotify,
        })
      );
    }
  };
}

// Reducer

export function getEmptyState(): ComposerStateType {
  return {
    conversations: {},
  };
}

function updateComposerState(
  state: Readonly<ComposerStateType>,
  action: Readonly<ComposerActionType>,
  getNextComposerState: (
    prevState: ComposerStateByConversationType
  ) => Partial<ComposerStateByConversationType>
): ComposerStateType {
  const { conversationId } = action.payload;

  strictAssert(
    conversationId,
    'updateComposerState: no conversationId provided'
  );

  const prevComposerState = getComposerStateForConversation(
    state,
    conversationId
  );

  const nextComposerStateForConversation = assignWithNoUnnecessaryAllocation(
    prevComposerState,
    getNextComposerState(prevComposerState)
  );

  return assignWithNoUnnecessaryAllocation(state, {
    conversations: assignWithNoUnnecessaryAllocation(state.conversations, {
      [conversationId]: nextComposerStateForConversation,
    }),
  });
}

export function reducer(
  state: Readonly<ComposerStateType> = getEmptyState(),
  action: Readonly<ComposerActionType>
): ComposerStateType {
  if (action.type === CONVERSATION_UNLOADED) {
    const nextConversations: Record<string, ComposerStateByConversationType> =
      {};
    for (const [conversationId, conversation] of Object.entries(
      state.conversations
    )) {
      nextConversations[conversationId] = conversation;
    }

    return {
      ...state,
      conversations: nextConversations,
    };
  }

  if (action.type === RESET_COMPOSER) {
    return updateComposerState(state, action, () => ({}));
  }

  if (action.type === REPLACE_ATTACHMENTS) {
    const { attachments } = action.payload;

    return updateComposerState(state, action, () => ({
      attachments,
      ...(attachments.length
        ? {}
        : { shouldSendHighQualityAttachments: undefined }),
    }));
  }

  if (action.type === INCREMENT_SEND_COUNTER) {
    return updateComposerState(state, action, prevState => ({
      sendCounter: prevState.sendCounter + 1,
    }));
  }

  if (action.type === SET_FOCUS) {
    return updateComposerState(state, action, prevState => ({
      focusCounter: prevState.focusCounter + 1,
    }));
  }

  if (action.type === SET_HIGH_QUALITY_SETTING) {
    return updateComposerState(state, action, () => ({
      shouldSendHighQualityAttachments: action.payload.value,
    }));
  }

  if (action.type === SET_QUOTED_MESSAGE) {
    const { quotedMessage } = action.payload;
    return updateComposerState(state, action, () => ({
      quotedMessage,
    }));
  }

  if (action.type === ADD_LINK_PREVIEW) {
    if (action.payload.source !== LinkPreviewSourceType.Composer) {
      return state;
    }

    return updateComposerState(state, action, () => ({
      linkPreviewLoading: true,
      linkPreviewResult: action.payload.linkPreview,
    }));
  }

  if (action.type === REMOVE_LINK_PREVIEW && action.payload.conversationId) {
    return updateComposerState(state, action, () => ({
      linkPreviewLoading: false,
      linkPreviewResult: undefined,
    }));
  }

  if (action.type === ADD_PENDING_ATTACHMENT) {
    return updateComposerState(state, action, prevState => ({
      attachments: [...prevState.attachments, action.payload.attachment],
    }));
  }

  if (action.type === SET_VIEW_ONCE) {
    return updateComposerState(state, action, () => ({
      isViewOnce: action.payload.value,
    }));
  }

  if (action.type === UPDATE_COMPOSER_DISABLED) {
    return updateComposerState(state, action, oldState => ({
      disabledCounter:
        oldState.disabledCounter + (action.payload.value ? 1 : -1),
    }));
  }

  return state;
}
