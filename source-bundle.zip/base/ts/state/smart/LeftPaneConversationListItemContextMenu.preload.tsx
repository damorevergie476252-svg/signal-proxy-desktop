// Copyright 2025 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only

import type { FC } from 'react';
import { memo, useCallback } from 'react';
import { useSelector } from 'react-redux';
import { getIntl } from '../selectors/user.std.ts';
import { getConversationByIdSelector } from '../selectors/conversations.dom.ts';
import type { ChatFolderToggleChat } from '../../components/leftPane/LeftPaneConversationListItemContextMenu.dom.tsx';
import { LeftPaneConversationListItemContextMenu } from '../../components/leftPane/LeftPaneConversationListItemContextMenu.dom.tsx';
import { strictAssert } from '../../util/assert.std.ts';
import type { RenderConversationListItemContextMenuProps } from '../../components/conversationList/BaseConversationListItem.dom.tsx';
import { useConversationsActions } from '../ducks/conversations.preload.ts';
import {
  getCurrentChatFolders,
  getSelectedChatFolder,
} from '../selectors/chatFolders.std.ts';
import { useChatFolderActions } from '../ducks/chatFolders.preload.ts';
import { useNavActions } from '../ducks/nav.std.ts';
import { NavTab, SettingsPage } from '../../types/Nav.std.ts';
import type { ChatFolderParams } from '../../types/ChatFolder.std.ts';
import { getSelectedLocation } from '../selectors/nav.std.ts';
import { getIsActivelySearching } from '../selectors/search.preload.ts';

export const SmartLeftPaneConversationListItemContextMenu: FC<RenderConversationListItemContextMenuProps> =
  memo(function SmartLeftPaneConversationListItemContextMenu(props) {
    const i18n = useSelector(getIntl);
    const conversationByIdSelector = useSelector(getConversationByIdSelector);
    const location = useSelector(getSelectedLocation);
    const isActivelySearching = useSelector(getIsActivelySearching);
    const selectedChatFolder = useSelector(getSelectedChatFolder);
    const currentChatFolders = useSelector(getCurrentChatFolders);

    const {
      onMarkUnread,
      markConversationRead,
      setPinned,
      onArchive,
      onMoveToInbox,
      deleteConversation,
      setMuteExpiration,
    } = useConversationsActions();
    const { updateChatFolderToggleChat } = useChatFolderActions();
    const { changeLocation } = useNavActions();

    const conversation = conversationByIdSelector(props.conversationId);
    strictAssert(conversation, 'Missing conversation');

    const handlePin = useCallback(
      (conversationId: string) => {
        setPinned(conversationId, true);
      },
      [setPinned]
    );

    const handleUnpin = useCallback(
      (conversationId: string) => {
        setPinned(conversationId, false);
      },
      [setPinned]
    );

    const handleChatFolderOpenCreatePage = useCallback(
      (initChatFolderParams: ChatFolderParams) => {
        void changeLocation({
          tab: NavTab.Settings,
          details: {
            page: SettingsPage.EditChatFolder,
            chatFolderId: null,
            initChatFolderParams,
            previousLocation: location,
          },
        });
      },
      [changeLocation, location]
    );

    const handleChatFolderToggleChat: ChatFolderToggleChat = useCallback(
      (chatFolderId, conversationId, toggle) => {
        void updateChatFolderToggleChat(
          chatFolderId,
          conversationId,
          toggle,
          true
        );
      },
      [updateChatFolderToggleChat]
    );

    return (
      <LeftPaneConversationListItemContextMenu
        i18n={i18n}
        conversation={conversation}
        selectedChatFolder={selectedChatFolder}
        currentChatFolders={currentChatFolders}
        isActivelySearching={isActivelySearching}
        onMarkUnread={onMarkUnread}
        onMarkRead={markConversationRead}
        onPin={handlePin}
        onUnpin={handleUnpin}
        onUpdateMute={setMuteExpiration}
        onArchive={onArchive}
        onUnarchive={onMoveToInbox}
        onDelete={deleteConversation}
        onChatFolderOpenCreatePage={handleChatFolderOpenCreatePage}
        onChatFolderToggleChat={handleChatFolderToggleChat}
      >
        {props.children}
      </LeftPaneConversationListItemContextMenu>
    );
  });
