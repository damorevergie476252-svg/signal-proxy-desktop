const test=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const handlers=new Map(),created=[],calls=[];
class FakeNotification extends EventEmitter {static handleActivation(callback){globalThis.activationCallback=callback;}constructor(options){super();this.options=options;created.push(this);}show(){}close(){}}
globalThis.notificationTest={ipc:{handle:(name,handler)=>handlers.set(name,handler)},Notification:FakeNotification,Notifier:class {remove(){}clearAll(){calls.push('clear-obsolete-proxy-toasts');}show(){throw new Error('Proxy notifications must not launch sgnl URLs');}},sendDummyKeystroke:()=>calls.push('foreground-permission')};
const {initializeWindowsNotifications}=require('../notification-regression/windows-notifications.cjs');
const type={Message:'Message',Reaction:'Reaction',IncomingGroupCall:'IncomingGroupCall',IncomingCall:'IncomingCall',IsPresenting:'IsPresenting'};
globalThis.notificationProducerBindings={NotificationType:type};
const {Producer}=require(process.env.SIGNAL_NOTIFICATION_NEGATIVE==='1'?'../notification-regression/producer-old.cjs':'../notification-regression/producer.cjs');
const target={conversationId:'chat-b',messageId:'message-b',storyId:undefined};
const data={heading:'Local test',body:'Synthetic body',token:'opaque',type:type.Message,target};
test('the actual renderer producer sends captured chat/message data along with the toast',()=>{
 const sent=[];globalThis.window={IPC:{clearAllWindowsNotifications:async()=>{},showWindowsNotification:async value=>sent.push(value)}};
 const producer=new Producer();producer.rawNotify({conversationId:'chat-b',messageId:'message-b',body:'fixture',title:'fixture',sentAt:1,silent:true,type:type.Message});
 assert.deepEqual(sent[0].target,target);
});
if(process.env.SIGNAL_NOTIFICATION_NEGATIVE!=='1'){
 function fixture(){calls.length=0;created.length=0;let minimized=true,destroyed=false;const contents={send:(channel,value)=>calls.push([channel,value])};const window={webContents:contents,isDestroyed:()=>destroyed,isMinimized:()=>minimized,restore:()=>{minimized=false;calls.push('restore');},focus:()=>calls.push('focus')};initializeWindowsNotifications({getMainWindow:()=>window,showWindow:()=>calls.push('show-window')});return {window,contents,destroy:()=>{destroyed=true;}};}
 test('a native toast click restores the correct application and delivers the original chat and message',()=>{
  const f=fixture();handlers.get('windows-notifications:show')({sender:f.contents},data);created[0].emit('click');
  assert.deepEqual(calls.slice(-4),['restore','show-window','focus',['windows-notifications:activate',data]]);
 });
 test('the registered Action Center callback restores the chat even without an instance click event',()=>{
  const f=fixture();handlers.get('windows-notifications:show')({sender:f.contents},data);
  assert.equal(typeof globalThis.activationCallback,'function');globalThis.activationCallback({type:'click',arguments:data.token});
  assert.deepEqual(calls.slice(-4),['restore','show-window','focus',['windows-notifications:activate',data]]);
  created[0].emit('click');globalThis.activationCallback({type:'click',arguments:data.token});
  assert.equal(calls.filter(item=>Array.isArray(item)).length,1);
 });
 test('global activation ignores unrelated tokens, action kinds and cleared notifications',()=>{
  const f=fixture();handlers.get('windows-notifications:show')({sender:f.contents},data);
  for(const details of [{type:'click',arguments:'unrelated'},{type:'action',arguments:data.token},{type:'reply',arguments:data.token}])globalThis.activationCallback(details);
  handlers.get('windows-notifications:clear-all')({sender:f.contents});globalThis.activationCallback({type:'click',arguments:data.token});
  assert.ok(!calls.some(item=>Array.isArray(item)));
 });
 test('clearing tokens while waking the main window cannot lose the captured destination',()=>{
  const f=fixture();let token;initializeWindowsNotifications({getMainWindow:()=>f.window,showWindow:()=>{token=undefined;}});token='old';
  handlers.get('windows-notifications:show')({sender:f.contents},data);created[0].emit('click');assert.equal(token,undefined);
  assert.deepEqual(calls.at(-1),['windows-notifications:activate',data]);
 });
 test('untrusted or detached renderers cannot show or clear account notifications',()=>{
  fixture();assert.throws(()=>handlers.get('windows-notifications:show')({sender:{}},data),/Only the main window/);
  assert.throws(()=>handlers.get('windows-notifications:clear-all')({sender:{}}),/Only the main window/);
 });
 test('a closed account window cannot receive a delayed notification click',()=>{
  const f=fixture();handlers.get('windows-notifications:show')({sender:f.contents},data);f.destroy();created[0].emit('click');assert.ok(!calls.some(item=>Array.isArray(item)));
 });
 test('presentation controls do not bring another window to the front',()=>{
  const f=fixture();const presenting={...data,type:type.IsPresenting};handlers.get('windows-notifications:show')({sender:f.contents},presenting);created[0].emit('click');
  assert.ok(!calls.includes('restore'));assert.ok(!calls.includes('show-window'));assert.deepEqual(calls.at(-1),['windows-notifications:activate',presenting]);
 });
 test('locked notifications hide content and defer chat navigation until verified unlock',()=>{
  const f=fixture();let locked=true,after;initializeWindowsNotifications({getMainWindow:()=>f.window,showWindow:()=>calls.push('show-window'),localLock:{isLocked:()=>locked,showUnlock:callback=>{after=callback;}}});
  handlers.get('windows-notifications:show')({sender:f.contents},{...data,avatarPath:'private-avatar'});
  assert.equal(created[0].options.title,'Signal Proxy 已锁定');assert.ok(!created[0].options.toastXml.includes('Synthetic body'));assert.ok(!created[0].options.toastXml.includes('private-avatar'));
  created[0].emit('click');assert.ok(!calls.some(item=>Array.isArray(item)));assert.equal(typeof after,'function');locked=false;after();assert.deepEqual(calls.at(-1),['windows-notifications:activate',{...data,heading:'Signal Proxy 已锁定',body:'解锁后查看新消息',avatarPath:undefined}]);
 });
}
