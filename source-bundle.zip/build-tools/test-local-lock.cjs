const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),{EventEmitter}=require('node:events'),{pathToFileURL}=require('node:url');
const base=path.resolve(__dirname,'..'),root=path.join(base,'local-lock-regression');
const {LocalLockStore}=require('../local-lock-regression/store.cjs');
async function fresh(){const dir=await fs.mkdtemp(path.join(root,'fixture-'));let now=Date.now();const store=new LocalLockStore(path.join(dir,'local-lock.json'),()=>now);await store.load();return {dir,store,advance:n=>{now+=n;}};}
test('first run is opt-in and stores a salted verifier rather than the passcode',async()=>{
 const f=await fresh();assert.equal(f.store.enabled,false);await f.store.configure('','local-fixture-code');
 const raw=await fs.readFile(f.store.file,'utf8');assert.ok(!raw.includes('local-fixture-code'));assert.equal(f.store.enabled,true);assert.equal(await f.store.verify('local-fixture-code'),true);
});
test('incorrect code never unlocks; retries and cooldown persist across restart',async()=>{
 const f=await fresh();await f.store.configure('','123456');for(let i=0;i<5;i++){assert.equal(await f.store.verify('wrong'),false);f.advance(1100);}
 const again=new LocalLockStore(f.store.file,()=>Date.now());await again.load();assert.ok(again.retryAfter>0);await assert.rejects(again.verify('123456'),/等待/);
});
test('changing or disabling a code requires the current code and survives reopening',async()=>{
 const f=await fresh();await f.store.configure('','123456');await assert.rejects(f.store.configure('bad','654321'),/不正确/);f.advance(1100);
 await f.store.configure('123456','654321');assert.equal(await f.store.verify('123456'),false);f.advance(1100);assert.equal(await f.store.verify('654321'),true);
 await assert.rejects(f.store.configure('bad',null),/不正确/);f.advance(1100);await f.store.configure('654321',null);const again=new LocalLockStore(f.store.file);await again.load();assert.equal(again.enabled,false);
});
test('malformed configuration fails closed and is preserved',async()=>{
 const f=await fresh();await fs.writeFile(f.store.file,'broken');const again=new LocalLockStore(f.store.file);await again.load();assert.equal(again.enabled,true);assert.equal(again.broken,true);await assert.rejects(again.configure('',null),/无法读取/);assert.equal(await fs.readFile(f.store.file,'utf8'),'broken');
});
test('parallel attempts and short codes are rejected',async()=>{
 const f=await fresh();await assert.rejects(f.store.configure('','12345'),/6–128/);await f.store.configure('','123456');const first=f.store.verify('123456');await assert.rejects(f.store.verify('123456'),/稍候/);assert.equal(await first,true);
});
test('an interrupted configuration or disable retains the previous verifier',async()=>{
 const f=await fresh();await f.store.configure('','123456');await assert.rejects(f.store.configure('123456',null,()=>false),/已锁定/);assert.equal(await f.store.verify('123456'),true);
 let checks=0;await assert.rejects(f.store.configure('123456','654321',()=>++checks===1),/已锁定/);assert.equal(await f.store.verify('123456'),true);
});

async function fixture(enabled=true){
 const f=await fresh();if(enabled)await f.store.configure('','123456');
 const app=new EventEmitter(),powerMonitor=new EventEmitter(),handlers=new Map(),windows=[];let idle=0,interval,clock=Date.now();
 app.getPath=()=>f.dir;class Window extends EventEmitter{
  constructor(options={}){super();this.options=options;this.visible=false;this.destroyed=false;this.webContents=new EventEmitter();this.webContents.mainFrame={url:pathToFileURL(path.join(root,'local-lock.html')).href};this.webContents.closeDevTools=()=>{};this.webContents.setWindowOpenHandler=()=>{};windows.push(this);app.emit('browser-window-created',{},this);}
  static getAllWindows(){return windows.filter(w=>!w.destroyed);}
  show(){this.visible=true;}showInactive(){this.visible=true;}focus(){}restore(){this.visible=true;}hide(){this.visible=false;}isVisible(){return this.visible;}isDestroyed(){return this.destroyed;}setMenu(){}loadFile(){this.emit('ready-to-show');return Promise.resolve();}close(){setImmediate(()=>this.destroy());}destroy(){this.destroyed=true;this.visible=false;this.emit('closed');}
 }
 const oldInterval=global.setInterval,oldNow=Date.now;global.setInterval=fn=>{interval=fn;return {unref(){}}};Date.now=()=>clock;
 globalThis.lockTest={app,BrowserWindow:Window,ipcMain:{handle:(name,handler)=>handlers.set(name,handler)},powerMonitor:Object.assign(powerMonitor,{getSystemIdleTime:()=>idle})};
 delete require.cache[require.resolve('../local-lock-regression/local-lock.cjs')];const {LocalLock}=require('../local-lock-regression/local-lock.cjs');
 let main;const lock=new LocalLock({rootDir:root,getMainWindow:()=>main});await lock.initialize();main=new Window();
 function panel(){return windows.filter(w=>!w.destroyed&&w.options.title==='Signal Proxy · 本机锁定').at(-1);}
 const event=()=>({sender:panel().webContents,senderFrame:panel().webContents.mainFrame});
 return {lock,main,Window,powerMonitor,handlers,windows,panel,event,advance:n=>{clock+=n;},tick:n=>{idle=n;interval();},cleanup:()=>{global.setInterval=oldInterval;Date.now=oldNow;}};
}
test('configured startup blocks showing main window and secondary windows until correct unlock',async()=>{
 const f=await fixture();try{f.main.show();assert.equal(f.main.isVisible(),false);assert.ok(f.panel());const child=new f.Window();child.showInactive();assert.equal(child.isVisible(),false);
 const result=await f.handlers.get('local-lock:submit')(f.event(),{action:'unlock',code:'123456'});assert.equal(result.error,undefined);assert.equal(f.lock.isLocked(),false);assert.equal(f.main.isVisible(),true);
 }finally{f.cleanup();}
});
test('manual lock hides every visible app window and restores them after verification',async()=>{
 const f=await fixture();try{f.lock.showUnlock();await f.handlers.get('local-lock:submit')(f.event(),{action:'unlock',code:'123456'});const child=new f.Window();child.show();let cleared=0;f.lock.setNotificationCleaner(()=>cleared++);f.lock.lock();assert.equal(f.main.isVisible(),false);assert.equal(child.isVisible(),false);assert.equal(cleared,1);assert.throws(()=>f.lock.assertUnlocked(),/已锁定/);await f.handlers.get('local-lock:submit')(f.event(),{action:'unlock',code:'123456'});assert.equal(child.isVisible(),true);
 }finally{f.cleanup();}
});
test('five minutes of idle and Windows lock screen require unlocking again',async()=>{
 const f=await fixture();try{f.lock.showUnlock();await f.handlers.get('local-lock:submit')(f.event(),{action:'unlock',code:'123456'});f.advance(300001);f.tick(299);assert.equal(f.lock.isLocked(),false);f.tick(300);assert.equal(f.lock.isLocked(),true);f.lock.showUnlock();await f.handlers.get('local-lock:submit')(f.event(),{action:'unlock',code:'123456'});f.powerMonitor.emit('lock-screen');assert.equal(f.lock.isLocked(),true);
 }finally{f.cleanup();}
});
test('foreign renderers and subframes cannot inspect or mutate lock credentials',async()=>{
 const f=await fixture();try{f.lock.showUnlock();assert.throws(()=>f.handlers.get('local-lock:status')({sender:{},senderFrame:{}}),/Only/);await assert.rejects(f.handlers.get('local-lock:submit')({sender:f.panel().webContents,senderFrame:{url:'file:///untrusted'}},{action:'unlock',code:'123456'}),/Only/);
 }finally{f.cleanup();}
});
test('notification navigation is deferred until unlocking and discarded on a new lock',async()=>{
 const f=await fixture();try{let calls=0;f.lock.showUnlock(()=>calls++);assert.equal(calls,0);await f.handlers.get('local-lock:submit')(f.event(),{action:'unlock',code:'123456'});assert.equal(calls,1);f.lock.lock();f.lock.showUnlock(()=>calls++);f.powerMonitor.emit('lock-screen');f.lock.showUnlock();await f.handlers.get('local-lock:submit')(f.event(),{action:'unlock',code:'123456'});assert.equal(calls,1);
 }finally{f.cleanup();}
});
test('a new Windows lock during verification cannot be bypassed by an in-flight correct code',async()=>{
 const f=await fixture();try{f.lock.showUnlock();const pending=f.handlers.get('local-lock:submit')(f.event(),{action:'unlock',code:'123456'});f.powerMonitor.emit('lock-screen');const result=await pending;assert.match(result.error,/再次锁定/);assert.equal(f.lock.isLocked(),true);
 }finally{f.cleanup();}
});
test('disabled lock keeps the app visible and idle/OS events do not enable it',async()=>{
 const f=await fixture(false);try{f.main.show();f.tick(900);f.powerMonitor.emit('lock-screen');assert.equal(f.lock.isLocked(),false);assert.equal(f.main.isVisible(),true);
 }finally{f.cleanup();}
});
