const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module'),{pathToFileURL}=require('node:url');
const base=path.resolve(__dirname,'..'),work=path.join(base,'Signal-Desktop-8.36.0-with-proxy'),out=path.join(base,'startup-regression');
const fromProject=createRequire(path.join(work,'package.json'));
fs.mkdirSync(out,{recursive:true});
(async()=>{
 const {rolldown}=await import(pathToFileURL(fromProject.resolve('rolldown')).href);
 const mocks={
  electron:'export const app=globalThis.startupTest.app;',
  '../ts/util/packageJson.main.ts':'export const packageJson=globalThis.startupTest.manifest;',
  '../ts/logging/log.std.ts':'export const createLogger=()=>({info(){}});',
  './global_errors.main.ts':'export const addHandler=()=>{};',
 };
 for(const old of [false,true]){
  const input=path.join(old?path.join(base,'backups/before-startup-repair-20261029'):work,'app/startup_config.main.ts');
  const bundle=await rolldown({input,platform:'node',plugins:[{name:'startup-native-boundaries',resolveId(id,importer){if(importer?.endsWith('startup_config.main.ts')&&mocks[id])return '\0mock:'+id;},load(id){if(id.startsWith('\0mock:'))return mocks[id.slice(6)];}}]});
  await bundle.write({file:path.join(out,old?'startup-old.cjs':'startup.cjs'),format:'cjs'});await bundle.close();
 }
})().catch(error=>{console.error(error);process.exitCode=1;});
