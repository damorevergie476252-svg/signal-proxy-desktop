// Exercise actual 8.36 send/precheck bodies against synthetic local queue boundaries.
const assert = require('node:assert/strict');
const { test } = require('node:test');
const { randomUUID } = require('node:crypto');
let verified, blocked, accepted, enqueueCalls, toasts, shown, subscriptions;
let processedCalls, promotionCalls, deletedPaths, draftBytes, promotedBytes;
let failPromotion, failEnqueue, failCleanup;
const attrs = { id: 'chat-a', type: 'private', draft: 'main draft stays', draftAttachments: [{ fileName: 'existing.txt', path: 'drafts/main-existing' }] };
const mainDrafts = structuredClone(attrs.draftAttachments);
const state = { globalModals: {} };
const conversation = {
  attributes: attrs,
  get: key => attrs[key],
  clearTypingTimers() {},
  enqueueMessageForSend: async (payload, options) => {
    enqueueCalls.push({ payload, options });
    if (failEnqueue) throw new Error('Synthetic queue failure');
    return { id: 'sent-message', conversationId: attrs.id, ...payload };
  },
};
globalThis.window = {
  ConversationController: { get: id => id === 'chat-a' ? conversation : undefined },
  IPC: { showWindow: () => shown++ },
  reduxActions: { toast: { showToast: value => toasts.push(value) } },
  reduxStore: {
    getState: () => state,
    dispatch: action => action,
    subscribe: listener => { subscriptions++; window.onStateChange = listener; return () => subscriptions--; },
  },
};
globalThis.sendTestBindings = {
  strictAssert: (value, message) => assert.ok(value, message),
  shouldShowInvalidMessageToast: () => blocked ? { toastType: 'Blocked' } : undefined,
  isConversationAccepted: () => accepted,
  areWeAdmin: () => false,
  generateUuid: randomUUID,
  processAttachment: async (file, options) => {
    assert.equal(typeof options.clientUuid, 'string');
    assert.ok(options.clientUuid.length > 0);
    assert.ok(!processedCalls.some(call => call.clientUuid === options.clientUuid));
    processedCalls.push(options);
    const draftPath = `drafts/detached-${options.clientUuid}`;
    draftBytes.set(draftPath, new Uint8Array(await file.arrayBuffer()));
    draftBytes.set(`${draftPath}-screenshot`, new Uint8Array([9]));
    return { contentType: file.type, clientUuid: options.clientUuid, pending: false, size: file.size, path: draftPath, fileName: file.name, screenshot: { path: `${draftPath}-screenshot` } };
  },
  promoteDraftAttachment: async draft => {
    promotionCalls.push(draft);
    assert.ok(draftBytes.has(draft.path));
    if (failPromotion) return undefined;
    const attachmentPath = `attachments/${draft.clientUuid}`;
    promotedBytes.set(attachmentPath, draftBytes.get(draft.path));
    return { ...draft, path: attachmentPath, localKey: 'synthetic-key', version: 2 };
  },
  deleteDraftAttachment: async draft => {
    assert.ok(!mainDrafts.some(existing => existing.path === draft.path), 'Must not delete main-window drafts');
    deletedPaths.push(draft.path);
    if (failCleanup) throw new Error('Synthetic cleanup failure');
    draftBytes.delete(draft.path);
  },
  getRecipientsByConversation: () => ({ 'chat-a': { serviceIds: ['recipient'] } }),
  blockSendUntilConversationsAreVerified: async () => { if (state.globalModals.safetyNumberChangedBlockingData) window.onStateChange(); return verified; },
  updateComposerDisabled: (id, value) => ({ id, value }),
  hasDraftAttachments: attachments => attachments.some(item => !item.pending),
  log: { info() {}, error() {}, warn() {} }, Errors: { toLogFormat: String }, SafetyNumberChangeSource: { MessageSend: 'message' },
  isFileDangerous: name => /\.exe$/i.test(name),
  stringToMIMEType: type => type,
  isImageAttachment: attachment => attachment.contentType.startsWith('image/'),
  isVideoAttachment: attachment => attachment.contentType.startsWith('video/'),
  isImageTypeSupported: type => type.startsWith('image/'),
  isVideoTypeSupported: type => type.startsWith('video/'),
  getAttachmentSizeLimit: () => 1024,
  getRemoteConfigValue() {},
  isAttachmentTooLarge: ({ plaintextSize, ciphertextLimit }) => plaintextSize > ciphertextLimit,
  ToastType: new Proxy({}, { get: (_target, name) => name }), getRenderDetailsForLimit: () => ({}), SHOW_TOAST: 'toast',
};
const { sendDetachedConversationMessage: send } = require('../conversation-window-regression/send-functions.cjs');
function reset() {
  verified = true; blocked = false; accepted = true; enqueueCalls = []; toasts = []; shown = 0; subscriptions = 0;
  processedCalls = []; promotionCalls = []; deletedPaths = []; draftBytes = new Map(); promotedBytes = new Map();
  failPromotion = false; failEnqueue = false; failCleanup = false; state.globalModals = {}; delete attrs.announcementsOnly;
  assert.equal(attrs.draft, 'main draft stays'); assert.deepEqual(attrs.draftAttachments, mainDrafts);
}
const note = { name: 'note.txt', type: 'text/plain', data: new Uint8Array([65, 66]) };
const image = { name: 'image.png', type: 'image/png', data: new Uint8Array([1, 2, 3]) };

test('text routes to the selected conversation queue and preserves the main draft', async () => {
  reset(); const result = await send('chat-a', 'hello', []);
  assert.equal(result.id, 'sent-message'); assert.equal(enqueueCalls.length, 1); assert.equal(enqueueCalls[0].payload.body, 'hello');
  assert.equal(enqueueCalls[0].options.dontClearDraft, true); assert.equal(attrs.draft, 'main draft stays'); assert.deepEqual(attrs.draftAttachments, mainDrafts); assert.equal(subscriptions, 0);
});
test('attachment-only send promotes a unique on-disk draft before queue admission', async () => {
  reset(); await send('chat-a', '', [note]); const attachment = enqueueCalls[0].payload.attachments[0];
  assert.equal(processedCalls.length, 1); assert.equal(promotionCalls.length, 1); assert.match(attachment.path, /^attachments\//);
  assert.equal(attachment.clientUuid, processedCalls[0].clientUuid); assert.deepEqual([...promotedBytes.get(attachment.path)], [65, 66]);
  assert.equal(attachment.fileName, 'note.txt'); assert.equal('data' in attachment, false); assert.equal(enqueueCalls[0].options.dontClearDraft, true);
  assert.equal(deletedPaths.length, 2); assert.equal(draftBytes.size, 0); assert.deepEqual(attrs.draftAttachments, mainDrafts);
});
test('canceling the original safety precheck prevents queue admission', async () => {
  reset(); verified = false; assert.equal(await send('chat-a', 'hello', []), undefined); assert.equal(enqueueCalls.length, 0); assert.equal(subscriptions, 0);
});
test('blocked and unaccepted chats do not enqueue messages', async () => {
  reset(); blocked = true; await assert.rejects(() => send('chat-a', 'hello', [])); assert.equal(enqueueCalls.length, 0);
  blocked = false; accepted = false; await assert.rejects(() => send('chat-a', 'hello', [])); assert.equal(enqueueCalls.length, 0);
});
test('safety confirmation is revealed in the main window and no send occurs on cancel', async () => {
  reset(); verified = false; state.globalModals.safetyNumberChangedBlockingData = {}; await send('chat-a', 'hello', []);
  assert.equal(shown, 1); assert.equal(enqueueCalls.length, 0); assert.equal(subscriptions, 0);
});
test('dangerous files and over-limit files fail before queue admission', async () => {
  reset(); await assert.rejects(() => send('chat-a', '', [{ name: 'a.exe', type: 'application/octet-stream', data: new Uint8Array([1]) }]));
  await assert.rejects(() => send('chat-a', '', [{ name: 'large.txt', type: 'text/plain', data: new Uint8Array(1025) }]));
  assert.equal(enqueueCalls.length, 0); assert.equal(processedCalls.length, 0);
});
test('empty messages and unknown conversations are not sent', async () => {
  reset(); assert.equal(await send('chat-a', '', []), undefined); assert.equal(enqueueCalls.length, 0); await assert.rejects(() => send('missing', 'hello', []));
});
test('announcement-only groups retain their existing admission rules', async () => {
  reset(); attrs.announcementsOnly = true; await assert.rejects(() => send('chat-a', 'hello', [])); assert.equal(enqueueCalls.length, 0); delete attrs.announcementsOnly;
});
test('canceling a send cleans only detached drafts and never promotes them', async () => {
  reset(); verified = false; assert.equal(await send('chat-a', '', [note]), undefined);
  assert.equal(enqueueCalls.length, 0); assert.equal(promotionCalls.length, 0); assert.equal(draftBytes.size, 0); assert.equal(deletedPaths.length, 2);
  assert.deepEqual(attrs.draftAttachments, mainDrafts);
});
test('a missing promoted attachment prevents sending and cleans its source draft', async () => {
  reset(); failPromotion = true; await assert.rejects(() => send('chat-a', '', [note]), /promote detached attachment/);
  assert.equal(enqueueCalls.length, 0); assert.equal(draftBytes.size, 0); assert.equal(subscriptions, 0);
});
test('rejecting a later attachment still cleans earlier processed drafts', async () => {
  reset(); await assert.rejects(() => send('chat-a', '', [image, { name: 'a.exe', type: 'application/octet-stream', data: new Uint8Array([1]) }]));
  assert.equal(processedCalls.length, 1); assert.equal(enqueueCalls.length, 0); assert.equal(promotionCalls.length, 0); assert.equal(draftBytes.size, 0);
});
test('a queue failure propagates while detached drafts and subscriptions are cleaned', async () => {
  reset(); failEnqueue = true; await assert.rejects(() => send('chat-a', '', [note]), /Synthetic queue failure/);
  assert.equal(enqueueCalls.length, 1); assert.equal(draftBytes.size, 0); assert.equal(subscriptions, 0); assert.deepEqual(attrs.draftAttachments, mainDrafts);
});
test('cleanup failure does not falsely report that an admitted message was not sent', async () => {
  reset(); failCleanup = true; const result = await send('chat-a', '', [note]);
  assert.equal(result.id, 'sent-message'); assert.equal(enqueueCalls.length, 1); assert.equal(subscriptions, 0); assert.deepEqual(attrs.draftAttachments, mainDrafts);
});
