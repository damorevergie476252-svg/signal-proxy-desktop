// Compile the real renderer/service with local account and database boundaries.
const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const { pathToFileURL } = require('node:url');
const base = path.resolve(__dirname, '..');
const work = path.join(base, 'Signal-Desktop-8.36.0-with-proxy');
const fromProject = createRequire(path.join(work, 'package.json'));
const harness = path.join(base, 'conversation-window-regression');
const replacements = {
  '../sql/Client.preload.ts': 'export const DataReader=window.testBackend.reader;',
  '../util/getNotificationTextForMessage.preload.ts': 'export const getNotificationTextForMessage=m=>m.body??"system message";',
  '../messages/sources.preload.ts': 'export const getAuthorId=m=>m.source??"author";',
  '../messages/getMessageById.preload.ts': 'export const getMessageById=async id=>window.testBackend.getMessage(id);',
  '../util/migrations.preload.ts': 'export const readAttachmentData=async a=>new Uint8Array([1,2,3]); export const doesAttachmentExist=async path=>path!=="missing-image.png";',
  '../util/isConversationAccepted.preload.ts': 'export const isConversationAccepted=c=>!c.unaccepted;',
  '../util/shouldShowInvalidMessageToast.preload.ts': 'export const shouldShowInvalidMessageToast=c=>c.blocked?{toastType:"Blocked"}:undefined;',
  '../util/areWeAdmin.preload.ts': 'export const areWeAdmin=c=>!!c.admin;',
  '../state/ducks/composer.preload.ts': 'export const sendDetachedConversationMessage=(id,body,files)=>window.testBackend.send(id,body,files);',
  '../util/avatarUtils.preload.ts': 'export const getLocalAvatarUrl=c=>c?.testAvatarUrl;',
};
async function main() {
  fs.mkdirSync(harness, { recursive: true });
  const { rolldown } = await import(pathToFileURL(fromProject.resolve('rolldown')).href);
  if (!process.argv.includes('--send-only')) {
  let source = fs.readFileSync(path.join(__dirname, 'test-conversation-window-preload.cjs'), 'utf8');
  for (const name of ['react', 'react-dom/client', 'react-dom']) source = source.replaceAll(`fromProject('${name}')`, `require(${JSON.stringify(fromProject.resolve(name))})`);
  for (const name of ['ts/environment.std.ts', 'ts/services/detachedConversations.preload.ts', 'ts/services/detachedConversationUpdates.std.ts', 'ts/components/leftPane/LeftPaneConversationListItemContextMenu.dom.tsx', 'ts/types/CurrentChatFolders.std.ts']) {
    source = source.replace(`fromProject(path.join(work,'${name}'))`, `require(${JSON.stringify(path.join(work, name))})`);
  }
  fs.writeFileSync(path.join(harness, 'entry.cjs'), source);
  for (const negative of [false, true]) {
    const bundle = await rolldown({
      input: path.join(harness, 'entry.cjs'), platform: 'node', external: ['electron'],
      plugins: [{ name: 'synthetic-account-boundaries', resolveId(id, importer) {
        if (importer?.endsWith('detachedConversations.preload.ts') && replacements[id]) return '\0test:' + id;
      }, load(id) { if (id.startsWith('\0test:')) return replacements[id.slice(6)]; },
      transform(code, id) {
        if (negative && id.endsWith('LeftPaneConversationListItemContextMenu.dom.tsx')) return code.replace('props.onOpenInNewWindow && (', 'false && (');
      } }],
      transform: { jsx: 'react-jsx', define: { 'process.env.NODE_ENV': '"test"', 'process.env.IS_BUNDLED': 'true' } },
    });
    await bundle.write({ file: path.join(harness, negative ? 'preload-negative.cjs' : 'preload.cjs'), format: 'cjs' });
    await bundle.close();
  }
  fs.writeFileSync(path.join(harness, 'index.html'), '<html><body><div id="root"></div></body></html>');
  }
  // Test the actual sending functions, keeping their bodies unchanged and replacing external services.
  const composer = fs.readFileSync(path.join(work, 'ts/state/ducks/composer.preload.ts'), 'utf8');
  const chunks = [
    composer.slice(composer.indexOf('async function withPreSendChecks('), composer.indexOf('function sendEditedMessage(')),
    composer.slice(composer.indexOf('export async function sendDetachedConversationMessage('), composer.indexOf('function sendMultiMediaMessage(')),
    composer.slice(composer.indexOf('function preProcessAttachment('), composer.indexOf('function getPendingAttachment(')),
  ];
  const entry = `const {strictAssert,shouldShowInvalidMessageToast,isConversationAccepted,areWeAdmin,processAttachment,promoteDraftAttachment,deleteDraftAttachment,generateUuid,getRecipientsByConversation,blockSendUntilConversationsAreVerified,updateComposerDisabled,hasDraftAttachments,log,Errors,SafetyNumberChangeSource,isFileDangerous,stringToMIMEType,isImageAttachment,isVideoAttachment,isImageTypeSupported,isVideoTypeSupported,getAttachmentSizeLimit,getRemoteConfigValue,isAttachmentTooLarge,ToastType,getRenderDetailsForLimit,SHOW_TOAST}=globalThis.sendTestBindings;\n` + chunks.join('\n');
  const sendEntry = path.join(harness, 'send-entry.ts');
  const testEntry = process.env.SIGNAL_DETACHED_SEND_NEGATIVE === '1'
    ? entry.replace('await promoteDraftAttachment(draft)', 'await Promise.resolve(draft)')
    : entry;
  fs.writeFileSync(sendEntry, testEntry);
  const sendBundle = await rolldown({ input: sendEntry, platform: 'node' });
  await sendBundle.write({ file: path.join(harness, 'send-functions.cjs'), format: 'cjs' });
  await sendBundle.close();
}
main().catch(error => { console.error(error); process.exitCode = 1; });
