const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module'),{pathToFileURL}=require('node:url');
const base=path.resolve(__dirname,'..'),work=path.join(base,'Signal-Desktop-8.36.0-with-proxy'),out=path.join(base,'notification-regression');
const fromProject=createRequire(path.join(work,'package.json'));
const centerNegative=process.env.SIGNAL_NOTIFICATION_CENTER_NEGATIVE==='1';
const beforeCenter=path.join(base,'backups/before-action-center-repair-20261029');
fs.mkdirSync(out,{recursive:true});
const mocks={
 'electron':'export const ipcMain=globalThis.notificationTest.ipc;export const Notification=globalThis.notificationTest.Notification;',
 '@indutny/simple-windows-notifications':'export const Notifier=globalThis.notificationTest.Notifier;export const sendDummyKeystroke=globalThis.notificationTest.sendDummyKeystroke;',
 '../ts/logging/log.std.ts':'export const createLogger=()=>({info(...args){globalThis.notificationTest.log?.("info",args);},warn(...args){globalThis.notificationTest.log?.("warn",args);},error(...args){globalThis.notificationTest.log?.("error",args);}});',
 './startup_config.main.ts':'export const AUMID="local.signal.notification.test";',
 '../ts/util/os/osMain.node.ts':'export default {isWindows:()=>true};',
 '../ts/util/packageJson.main.ts':'export const packageJson={name:"signal-desktop-proxy"};',
};
(async()=>{
 const {rolldown}=await import(pathToFileURL(fromProject.resolve('rolldown')).href);
 const bundle=await rolldown({input:path.join(work,'app/WindowsNotifications.main.ts'),platform:'node',plugins:[{name:'notification-native-boundaries',resolveId(id,importer){if(importer?.endsWith('WindowsNotifications.main.ts')&&mocks[id])return '\0mock:'+id;},load(id){if(id.startsWith('\0mock:'))return mocks[id.slice(6)];if(centerNegative&&['WindowsNotifications.main.ts','localWindowsNotifications.main.ts'].includes(path.basename(id)))return fs.readFileSync(path.join(beforeCenter,'app',path.basename(id)),'utf8');}}]});
 await bundle.write({file:path.join(out,'windows-notifications.cjs'),format:'cjs'});await bundle.close();
 const nativeMocks={...mocks};delete nativeMocks.electron;
 const native=await rolldown({input:path.join(work,'app/WindowsNotifications.main.ts'),platform:'node',external:['electron'],plugins:[{name:'synthetic-notification-account',resolveId(id,importer){if(importer?.endsWith('WindowsNotifications.main.ts')&&nativeMocks[id])return '\0mock:'+id;},load(id){if(id.startsWith('\0mock:'))return nativeMocks[id.slice(6)];}}]});
 await native.write({file:path.join(out,'windows-notifications-native.cjs'),format:'cjs'});await native.close();
 const dispatch=await rolldown({input:path.join(work,'ts/util/dispatchWindowsNotification.std.ts'),platform:'node'});await dispatch.write({file:path.join(out,'dispatch.cjs'),format:'cjs'});await dispatch.close();
 const ts=fromProject('typescript');
 const source=fs.readFileSync(path.join(work,'ts/services/notifications.preload.ts'),'utf8');
 const ast=ts.createSourceFile('producer.ts',source,ts.ScriptTarget.Latest,true);
 let raw,close;function visit(node){if(ts.isMethodDeclaration(node)){if(node.name.getText(ast)==='rawNotify')raw=node.body.getText(ast);if(node.name.getText(ast)==='#closeLastShown')close=node.body.getText(ast);}ts.forEachChild(node,visit);}visit(ast);if(!raw||!close)throw new Error('Current notification producer methods not found');
 for(const negative of [false,true]){
  const file=path.join(out,negative?'producer-old.ts':'producer.ts');
  const body=negative?raw.replace('target: { conversationId, messageId, storyId },',''):raw;
  if(negative&&body===raw)throw new Error('Producer negative control failed to remove target');
  fs.writeFileSync(file,`const {NotificationType}=globalThis.notificationProducerBindings;const OS={isWindows:()=>true},log={info(){}},drop=x=>x,SHOWN_EVENT='shown';export class Producer{#lastShown;#shouldClearLastShown=false;#tokenData;emit(){} _createToken(target){return 'opaque';}#closeLastShown()${close} rawNotify(data:any)${body}}`);
  const producer=await rolldown({input:file,platform:'node'});await producer.write({file:path.join(out,negative?'producer-old.cjs':'producer.cjs'),format:'cjs'});await producer.close();
 }

})().catch(error=>{console.error(error);process.exitCode=1;});
