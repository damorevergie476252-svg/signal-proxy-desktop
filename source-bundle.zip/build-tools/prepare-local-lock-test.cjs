const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module'),{pathToFileURL}=require('node:url');
const base=path.resolve(__dirname,'..'),work=path.join(base,'Signal-Desktop-8.36.0-with-proxy'),out=path.join(base,'local-lock-regression');
const fromProject=createRequire(path.join(work,'package.json'));
fs.mkdirSync(out,{recursive:true});
(async()=>{
 const {rolldown}=await import(pathToFileURL(fromProject.resolve('rolldown')).href);
 for(const native of [false,true]){
  const bundle=await rolldown({input:path.join(work,'app/local_lock.main.ts'),platform:'node',external:native?['electron']:[],plugins:native?[]:[{name:'local-lock-electron-boundary',resolveId(id){if(id==='electron')return '\0mock:electron';},load(id){if(id==='\0mock:electron')return 'export const {app,BrowserWindow,ipcMain,powerMonitor}=globalThis.lockTest;';if(process.env.SIGNAL_LOCK_NEGATIVE==='1'&&id.endsWith('local_lock.main.ts'))return fs.readFileSync(id,'utf8').replace('this.#locked = this.#store.enabled;', 'this.#locked = false;');}}]});
  await bundle.write({file:path.join(out,native?'local-lock-native.cjs':'local-lock.cjs'),format:'cjs'});await bundle.close();
 }
 const store=await rolldown({input:path.join(work,'app/local_lock_store.node.ts'),platform:'node'});await store.write({file:path.join(out,'store.cjs'),format:'cjs'});await store.close();
})().catch(error=>{console.error(error);process.exitCode=1;});
