const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),{createRequire}=require('node:module');
const base=path.resolve(__dirname,'..'),work=path.join(base,'Signal-Desktop-8.36.0-with-proxy');
const fromProject=createRequire(path.join(work,'package.json')),asar=fromProject('@electron/asar');
const negative=process.env.SIGNAL_STARTUP_NEGATIVE==='1';
const selected=process.env.SIGNAL_TEST_FIX;
if(selected&&!/^\d+$/.test(selected))throw new Error('Invalid test build');
const archive=path.join(base,selected?'dist-proxy-fix'+selected:fs.existsSync(path.join(base,'dist-proxy-fix13/win-unpacked/resources/app.asar'))?'dist-proxy-fix13':'dist-proxy-fix12','win-unpacked/resources/app.asar');
const packaged=JSON.parse(asar.extractFile(archive,'package.json'));
const source=JSON.parse(fs.readFileSync(path.join(work,'package.json'),'utf8'));
const modulePath=path.join(base,'startup-regression',negative?'startup-old.cjs':'startup.cjs');
function load(manifest){const ids=[];globalThis.startupTest={manifest,app:{setAppUserModelId:id=>ids.push(id)}};delete require.cache[require.resolve(modulePath)];const module=require(modulePath);return {id:module.AUMID,ids};}
test('the actual shipped manifest can initialize the Windows notification identity without build metadata',()=>{
 assert.equal(packaged.build,undefined,'Must test the stripped, shipped manifest');
 const result=load(packaged);assert.equal(result.id,source.build.appId);assert.deepEqual(result.ids,[source.build.appId]);
});
if(!negative){
 test('development and packaged builds use the same proxy notification identity',()=>assert.equal(load(source).id,load(packaged).id));
 test('the original Signal identity remains independent',()=>assert.equal(load({name:'signal-desktop'}).id,'org.whispersystems.signal-desktop'));
}
