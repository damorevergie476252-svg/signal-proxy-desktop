# Signal Proxy Desktop

这是 Signal Desktop 的非官方定制项目，与 Signal 官方没有隶属关系。Windows x64 版本保留 TLS 代理、独立聊天窗口、常用文档直接打开、图片复制、头像修复及可选本机锁定码。

## 安装与更新

安装包在本项目的 [Releases](https://github.com/damorevergie476252-svg/signal-proxy-desktop/releases) 页面。首次接入更新通道需要安装一次本项目新版，之后在“帮助 → 检查更新…”中更新。便携版使用同一份资料，但需手动替换便携程序。

升级前正常退出旧版并备份 `%APPDATA%\Signal-Proxy-SGPX`，再覆盖安装原目录。应用 ID 和资料目录保持一致。不要使用旧版打开已被新版迁移的数据库。

## 发布流程

GitHub Actions 每天检查两次官方稳定版，也可在 Actions 中手动运行。以官方标签源码为基线，三方合并本项目的定制改动，使用该版本锁定的 Node、pnpm 和依赖构建。原生组件只重用同版本、通过 Windows 签名及校验和验证的官方安装包中的文件。

合并冲突、类型检查、功能测试、安装包保护检查或隔离启动失败时，停止发布。官方的大幅调整仍可能需要人工维护，因此不保证每个未来版本都立即兼容。

签名任务独立于构建任务，客户端验证定制安装包的 SHA-512 和专用签名。公开仓库只有公钥；签名私钥保存在仓库 Actions secret `SIGNAL_PROXY_UPDATE_PRIVATE_KEY` 中。不要把私钥提交到源码。

本项目不上传或收集账号数据库、聊天记录、附件、锁定码及个人运行日志。测试使用合成数据和隔离资料目录；真实账号升级结果仍需安装后确认。

## 源码与许可

`base/` 保存修改所依据的官方 8.36.0 文件，`ours/` 保存相应定制文件。`prepare-source.py` 从新的官方源码生成定制工作树，遇到不兼容变更会明确失败。完整可构建源码随每个成功发行版提供 source.zip。

Signal Desktop 及这些修改遵循 AGPL-3.0-only，见 [LICENSE](LICENSE)。官方源码：[signalapp/Signal-Desktop](https://github.com/signalapp/Signal-Desktop)。
